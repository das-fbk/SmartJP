/**
 */
package newTravelPlanner.provider;

import java.util.Collection;
import java.util.List;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.SmartPlannerParameters;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link newTravelPlanner.SmartPlannerParameters} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class SmartPlannerParametersItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParametersItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addSppNamePropertyDescriptor(object);
			addMaxWalkDistancePropertyDescriptor(object);
			addMaxTotalWalkDistancePropertyDescriptor(object);
			addExtraTransportPropertyDescriptor(object);
			addMaxChangesPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Spp Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSppNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_SmartPlannerParameters_sppName_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_SmartPlannerParameters_sppName_feature",
								"_UI_SmartPlannerParameters_type"),
						NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS__SPP_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Max Walk Distance feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxWalkDistancePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_SmartPlannerParameters_maxWalkDistance_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_SmartPlannerParameters_maxWalkDistance_feature",
						"_UI_SmartPlannerParameters_type"),
				NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE, true, false, false,
				ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Max Total Walk Distance feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxTotalWalkDistancePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_SmartPlannerParameters_maxTotalWalkDistance_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_SmartPlannerParameters_maxTotalWalkDistance_feature", "_UI_SmartPlannerParameters_type"),
				NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE, true, false, false,
				ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Extra Transport feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addExtraTransportPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_SmartPlannerParameters_extraTransport_feature"),
						getString("_UI_PropertyDescriptor_description",
								"_UI_SmartPlannerParameters_extraTransport_feature", "_UI_SmartPlannerParameters_type"),
						NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Max Changes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxChangesPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_SmartPlannerParameters_maxChanges_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_SmartPlannerParameters_maxChanges_feature",
								"_UI_SmartPlannerParameters_type"),
						NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS__MAX_CHANGES, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns SmartPlannerParameters.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/SmartPlannerParameters"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((SmartPlannerParameters) object).getSppName();
		return label == null || label.length() == 0 ? getString("_UI_SmartPlannerParameters_type")
				: getString("_UI_SmartPlannerParameters_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(SmartPlannerParameters.class)) {
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME:
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE:
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE:
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT:
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return NewTravelPlannerEditPlugin.INSTANCE;
	}

}
