/**
 */
package mobilityResources.provider;

import java.util.Collection;
import java.util.List;

import mobilityResources.Fare_attribute;
import mobilityResources.MobilityResourcesPackage;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link mobilityResources.Fare_attribute} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class Fare_attributeItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_attributeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addFare_idPropertyDescriptor(object);
			addPricePropertyDescriptor(object);
			addCurrency_typePropertyDescriptor(object);
			addPayment_methodPropertyDescriptor(object);
			addTransfersPropertyDescriptor(object);
			addTransfer_durationPropertyDescriptor(object);
			addAgency_idPropertyDescriptor(object);
			addFare_rulesPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Fare id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addFare_idPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Fare_attribute_fare_id_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_fare_id_feature",
								"_UI_Fare_attribute_type"),
						MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__FARE_ID, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Price feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPricePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Fare_attribute_price_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_price_feature",
								"_UI_Fare_attribute_type"),
						MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__PRICE, true, false, false,
						ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Currency type feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCurrency_typePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Fare_attribute_currency_type_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_currency_type_feature",
						"_UI_Fare_attribute_type"),
				MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__CURRENCY_TYPE, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Payment method feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPayment_methodPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Fare_attribute_payment_method_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_payment_method_feature",
						"_UI_Fare_attribute_type"),
				MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__PAYMENT_METHOD, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Transfers feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTransfersPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Fare_attribute_transfers_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_transfers_feature",
								"_UI_Fare_attribute_type"),
						MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__TRANSFERS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Transfer duration feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTransfer_durationPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Fare_attribute_transfer_duration_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_transfer_duration_feature",
						"_UI_Fare_attribute_type"),
				MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__TRANSFER_DURATION, true, false, false,
				ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Agency id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAgency_idPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Fare_attribute_agency_id_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_agency_id_feature",
								"_UI_Fare_attribute_type"),
						MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__AGENCY_ID, true, false, true, null, null,
						null));
	}

	/**
	 * This adds a property descriptor for the Fare rules feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addFare_rulesPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Fare_attribute_fare_rules_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Fare_attribute_fare_rules_feature",
						"_UI_Fare_attribute_type"),
				MobilityResourcesPackage.Literals.FARE_ATTRIBUTE__FARE_RULES, true, false, true, null, null, null));
	}

	/**
	 * This returns Fare_attribute.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Fare_attribute"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Fare_attribute) object).getFare_id();
		return label == null || label.length() == 0 ? getString("_UI_Fare_attribute_type")
				: getString("_UI_Fare_attribute_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Fare_attribute.class)) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID:
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE:
		case MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE:
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD:
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS:
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return MobilityResourcesEditPlugin.INSTANCE;
	}

}
