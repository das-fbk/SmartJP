/**
 */
package mobilityResources.provider;

import java.util.Collection;
import java.util.List;

import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Stop_time;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link mobilityResources.Stop_time} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class Stop_timeItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_timeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addArrival_timePropertyDescriptor(object);
			addDeparture_timePropertyDescriptor(object);
			addStopPropertyDescriptor(object);
			addStop_sequencePropertyDescriptor(object);
			addStop_headsignPropertyDescriptor(object);
			addPickup_typePropertyDescriptor(object);
			addDrop_off_typePropertyDescriptor(object);
			addShape_dist_traveledPropertyDescriptor(object);
			addTimepointPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Arrival time feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addArrival_timePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_arrival_time_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_arrival_time_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__ARRIVAL_TIME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Departure time feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDeparture_timePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_departure_time_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_departure_time_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__DEPARTURE_TIME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Stop feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addStopPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_stop_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_stop_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__STOP, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Stop sequence feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addStop_sequencePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_stop_sequence_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_stop_sequence_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__STOP_SEQUENCE, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Stop headsign feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addStop_headsignPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_stop_headsign_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_stop_headsign_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__STOP_HEADSIGN, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Pickup type feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPickup_typePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_pickup_type_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_pickup_type_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__PICKUP_TYPE, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Drop off type feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDrop_off_typePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_drop_off_type_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_drop_off_type_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__DROP_OFF_TYPE, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Shape dist traveled feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addShape_dist_traveledPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_shape_dist_traveled_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_shape_dist_traveled_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__SHAPE_DIST_TRAVELED, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Timepoint feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTimepointPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Stop_time_timepoint_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Stop_time_timepoint_feature",
								"_UI_Stop_time_type"),
						MobilityResourcesPackage.Literals.STOP_TIME__TIMEPOINT, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns Stop_time.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Stop_time"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Stop_time) object).getArrival_time();
		return label == null || label.length() == 0 ? getString("_UI_Stop_time_type")
				: getString("_UI_Stop_time_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Stop_time.class)) {
		case MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME:
		case MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME:
		case MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE:
		case MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN:
		case MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE:
		case MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE:
		case MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED:
		case MobilityResourcesPackage.STOP_TIME__TIMEPOINT:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return MobilityResourcesEditPlugin.INSTANCE;
	}

}
