/**
 */
package mobilityResources.provider;

import java.util.Collection;
import java.util.List;

import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Trip;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link mobilityResources.Trip} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TripItemProvider extends MobilityResourceItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addRoutePropertyDescriptor(object);
			addServicePropertyDescriptor(object);
			addHeadsignPropertyDescriptor(object);
			addDirection_idPropertyDescriptor(object);
			addBlockPropertyDescriptor(object);
			addWheelchair_accessiblePropertyDescriptor(object);
			addBikes_allowedPropertyDescriptor(object);
			addService_datesPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Route feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRoutePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_route_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_route_feature", "_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__ROUTE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Service feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addServicePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_service_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_service_feature", "_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__SERVICE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Headsign feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addHeadsignPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_headsign_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_headsign_feature", "_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__HEADSIGN, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Direction id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDirection_idPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_direction_id_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_direction_id_feature",
								"_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__DIRECTION_ID, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Block feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addBlockPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_block_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_block_feature", "_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__BLOCK, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Wheelchair accessible feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWheelchair_accessiblePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_wheelchair_accessible_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_wheelchair_accessible_feature",
								"_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__WHEELCHAIR_ACCESSIBLE, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Bikes allowed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addBikes_allowedPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_bikes_allowed_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_bikes_allowed_feature",
								"_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__BIKES_ALLOWED, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Service dates feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addService_datesPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Trip_service_dates_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Trip_service_dates_feature",
								"_UI_Trip_type"),
						MobilityResourcesPackage.Literals.TRIP__SERVICE_DATES, true, false, true, null, null, null));
	}

	/**
	 * This returns Trip.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Trip"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Trip) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Trip_type")
				: getString("_UI_Trip_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Trip.class)) {
		case MobilityResourcesPackage.TRIP__HEADSIGN:
		case MobilityResourcesPackage.TRIP__DIRECTION_ID:
		case MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE:
		case MobilityResourcesPackage.TRIP__BIKES_ALLOWED:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
