/**
 */
package mapNotes.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mapNotes.MapNotesFactory;
import mapNotes.TripDescriptor;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Trip Descriptor</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TripDescriptorTest extends TestCase {

	/**
	 * The fixture for this Trip Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripDescriptor fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TripDescriptorTest.class);
	}

	/**
	 * Constructs a new Trip Descriptor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Trip Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(TripDescriptor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Trip Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripDescriptor getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MapNotesFactory.eINSTANCE.createTripDescriptor());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TripDescriptorTest
