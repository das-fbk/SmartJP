/**
 */
package mapNotes.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mapNotes.MapNotesFactory;
import mapNotes.StopTimeUpdate;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Stop Time Update</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class StopTimeUpdateTest extends TestCase {

	/**
	 * The fixture for this Stop Time Update test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopTimeUpdate fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(StopTimeUpdateTest.class);
	}

	/**
	 * Constructs a new Stop Time Update test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeUpdateTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Stop Time Update test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(StopTimeUpdate fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Stop Time Update test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopTimeUpdate getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MapNotesFactory.eINSTANCE.createStopTimeUpdate());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //StopTimeUpdateTest
