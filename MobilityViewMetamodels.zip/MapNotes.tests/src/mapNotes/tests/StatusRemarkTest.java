/**
 */
package mapNotes.tests;

import junit.framework.TestCase;

import mapNotes.StatusRemark;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Status Remark</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class StatusRemarkTest extends TestCase {

	/**
	 * The fixture for this Status Remark test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StatusRemark fixture = null;

	/**
	 * Constructs a new Status Remark test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StatusRemarkTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Status Remark test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(StatusRemark fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Status Remark test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StatusRemark getFixture() {
		return fixture;
	}

} //StatusRemarkTest
