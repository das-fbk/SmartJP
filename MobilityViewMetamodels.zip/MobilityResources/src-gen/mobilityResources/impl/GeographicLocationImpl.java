/**
 */
package mobilityResources.impl;

import mobilityResources.BikeSharing;
import mobilityResources.GeographicLocation;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Parking;

import mobilityResources.Stop;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Geographic Location</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.GeographicLocationImpl#getLon <em>Lon</em>}</li>
 *   <li>{@link mobilityResources.impl.GeographicLocationImpl#getLat <em>Lat</em>}</li>
 *   <li>{@link mobilityResources.impl.GeographicLocationImpl#getBikesharing <em>Bikesharing</em>}</li>
 *   <li>{@link mobilityResources.impl.GeographicLocationImpl#getParking <em>Parking</em>}</li>
 *   <li>{@link mobilityResources.impl.GeographicLocationImpl#getStop <em>Stop</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GeographicLocationImpl extends MinimalEObjectImpl.Container implements GeographicLocation {
	/**
	 * The default value of the '{@link #getLon() <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLon()
	 * @generated
	 * @ordered
	 */
	protected static final String LON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLon() <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLon()
	 * @generated
	 * @ordered
	 */
	protected String lon = LON_EDEFAULT;

	/**
	 * The default value of the '{@link #getLat() <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLat()
	 * @generated
	 * @ordered
	 */
	protected static final String LAT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLat() <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLat()
	 * @generated
	 * @ordered
	 */
	protected String lat = LAT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBikesharing() <em>Bikesharing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBikesharing()
	 * @generated
	 * @ordered
	 */
	protected BikeSharing bikesharing;

	/**
	 * The cached value of the '{@link #getParking() <em>Parking</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParking()
	 * @generated
	 * @ordered
	 */
	protected Parking parking;

	/**
	 * The cached value of the '{@link #getStop() <em>Stop</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop()
	 * @generated
	 * @ordered
	 */
	protected Stop stop;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GeographicLocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.GEOGRAPHIC_LOCATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLon() {
		return lon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLon(String newLon) {
		String oldLon = lon;
		lon = newLon;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LON,
					oldLon, lon));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLat() {
		return lat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLat(String newLat) {
		String oldLat = lat;
		lat = newLat;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LAT,
					oldLat, lat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BikeSharing getBikesharing() {
		if (bikesharing != null && bikesharing.eIsProxy()) {
			InternalEObject oldBikesharing = (InternalEObject) bikesharing;
			bikesharing = (BikeSharing) eResolveProxy(oldBikesharing);
			if (bikesharing != oldBikesharing) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, oldBikesharing, bikesharing));
			}
		}
		return bikesharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BikeSharing basicGetBikesharing() {
		return bikesharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBikesharing(BikeSharing newBikesharing, NotificationChain msgs) {
		BikeSharing oldBikesharing = bikesharing;
		bikesharing = newBikesharing;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, oldBikesharing, newBikesharing);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBikesharing(BikeSharing newBikesharing) {
		if (newBikesharing != bikesharing) {
			NotificationChain msgs = null;
			if (bikesharing != null)
				msgs = ((InternalEObject) bikesharing).eInverseRemove(this,
						MobilityResourcesPackage.BIKE_SHARING__POSITION, BikeSharing.class, msgs);
			if (newBikesharing != null)
				msgs = ((InternalEObject) newBikesharing).eInverseAdd(this,
						MobilityResourcesPackage.BIKE_SHARING__POSITION, BikeSharing.class, msgs);
			msgs = basicSetBikesharing(newBikesharing, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, newBikesharing, newBikesharing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parking getParking() {
		if (parking != null && parking.eIsProxy()) {
			InternalEObject oldParking = (InternalEObject) parking;
			parking = (Parking) eResolveProxy(oldParking);
			if (parking != oldParking) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING, oldParking, parking));
			}
		}
		return parking;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parking basicGetParking() {
		return parking;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetParking(Parking newParking, NotificationChain msgs) {
		Parking oldParking = parking;
		parking = newParking;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING, oldParking, newParking);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParking(Parking newParking) {
		if (newParking != parking) {
			NotificationChain msgs = null;
			if (parking != null)
				msgs = ((InternalEObject) parking).eInverseRemove(this, MobilityResourcesPackage.PARKING__POSITION,
						Parking.class, msgs);
			if (newParking != null)
				msgs = ((InternalEObject) newParking).eInverseAdd(this, MobilityResourcesPackage.PARKING__POSITION,
						Parking.class, msgs);
			msgs = basicSetParking(newParking, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING,
					newParking, newParking));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop getStop() {
		if (stop != null && stop.eIsProxy()) {
			InternalEObject oldStop = (InternalEObject) stop;
			stop = (Stop) eResolveProxy(oldStop);
			if (stop != oldStop) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP, oldStop, stop));
			}
		}
		return stop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop basicGetStop() {
		return stop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStop(Stop newStop, NotificationChain msgs) {
		Stop oldStop = stop;
		stop = newStop;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP, oldStop, newStop);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop(Stop newStop) {
		if (newStop != stop) {
			NotificationChain msgs = null;
			if (stop != null)
				msgs = ((InternalEObject) stop).eInverseRemove(this, MobilityResourcesPackage.STOP__STOP_LOCATION,
						Stop.class, msgs);
			if (newStop != null)
				msgs = ((InternalEObject) newStop).eInverseAdd(this, MobilityResourcesPackage.STOP__STOP_LOCATION,
						Stop.class, msgs);
			msgs = basicSetStop(newStop, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP,
					newStop, newStop));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			if (bikesharing != null)
				msgs = ((InternalEObject) bikesharing).eInverseRemove(this,
						MobilityResourcesPackage.BIKE_SHARING__POSITION, BikeSharing.class, msgs);
			return basicSetBikesharing((BikeSharing) otherEnd, msgs);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			if (parking != null)
				msgs = ((InternalEObject) parking).eInverseRemove(this, MobilityResourcesPackage.PARKING__POSITION,
						Parking.class, msgs);
			return basicSetParking((Parking) otherEnd, msgs);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			if (stop != null)
				msgs = ((InternalEObject) stop).eInverseRemove(this, MobilityResourcesPackage.STOP__STOP_LOCATION,
						Stop.class, msgs);
			return basicSetStop((Stop) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			return basicSetBikesharing(null, msgs);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			return basicSetParking(null, msgs);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			return basicSetStop(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LON:
			return getLon();
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LAT:
			return getLat();
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			if (resolve)
				return getBikesharing();
			return basicGetBikesharing();
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			if (resolve)
				return getParking();
			return basicGetParking();
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			if (resolve)
				return getStop();
			return basicGetStop();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LON:
			setLon((String) newValue);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LAT:
			setLat((String) newValue);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			setBikesharing((BikeSharing) newValue);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			setParking((Parking) newValue);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			setStop((Stop) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LON:
			setLon(LON_EDEFAULT);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LAT:
			setLat(LAT_EDEFAULT);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			setBikesharing((BikeSharing) null);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			setParking((Parking) null);
			return;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			setStop((Stop) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LON:
			return LON_EDEFAULT == null ? lon != null : !LON_EDEFAULT.equals(lon);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__LAT:
			return LAT_EDEFAULT == null ? lat != null : !LAT_EDEFAULT.equals(lat);
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING:
			return bikesharing != null;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__PARKING:
			return parking != null;
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP:
			return stop != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (lon: ");
		result.append(lon);
		result.append(", lat: ");
		result.append(lat);
		result.append(')');
		return result.toString();
	}

} //GeographicLocationImpl
