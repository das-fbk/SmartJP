/**
 */
package mobilityResources.impl;

import java.util.Collection;

import mobilityResources.Agency;
import mobilityResources.Calendar;
import mobilityResources.Calendar_date;
import mobilityResources.Fare_attribute;
import mobilityResources.Fare_rule;
import mobilityResources.GeographicLocation;
import mobilityResources.MobilityResource;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.MobilitySupport;

import mobilityResources.Stop_time;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mobility Support</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getCity <em>City</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getMobilityresources <em>Mobilityresources</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getGeographicLocations <em>Geographic Locations</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getAgency <em>Agency</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getStop_times <em>Stop times</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getCalendar <em>Calendar</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getCalendar_dates <em>Calendar dates</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getFares <em>Fares</em>}</li>
 *   <li>{@link mobilityResources.impl.MobilitySupportImpl#getFare_zones <em>Fare zones</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MobilitySupportImpl extends MinimalEObjectImpl.Container implements MobilitySupport {
	/**
	 * The default value of the '{@link #getCity() <em>City</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCity()
	 * @generated
	 * @ordered
	 */
	protected static final String CITY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCity() <em>City</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCity()
	 * @generated
	 * @ordered
	 */
	protected String city = CITY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMobilityresources() <em>Mobilityresources</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMobilityresources()
	 * @generated
	 * @ordered
	 */
	protected EList<MobilityResource> mobilityresources;

	/**
	 * The cached value of the '{@link #getGeographicLocations() <em>Geographic Locations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeographicLocations()
	 * @generated
	 * @ordered
	 */
	protected EList<GeographicLocation> geographicLocations;

	/**
	 * The cached value of the '{@link #getAgency() <em>Agency</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgency()
	 * @generated
	 * @ordered
	 */
	protected EList<Agency> agency;

	/**
	 * The cached value of the '{@link #getStop_times() <em>Stop times</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_times()
	 * @generated
	 * @ordered
	 */
	protected EList<Stop_time> stop_times;

	/**
	 * The cached value of the '{@link #getCalendar() <em>Calendar</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCalendar()
	 * @generated
	 * @ordered
	 */
	protected EList<Calendar> calendar;

	/**
	 * The cached value of the '{@link #getCalendar_dates() <em>Calendar dates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCalendar_dates()
	 * @generated
	 * @ordered
	 */
	protected EList<Calendar_date> calendar_dates;

	/**
	 * The cached value of the '{@link #getFares() <em>Fares</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFares()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_attribute> fares;

	/**
	 * The cached value of the '{@link #getFare_zones() <em>Fare zones</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare_zones()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_rule> fare_zones;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MobilitySupportImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.MOBILITY_SUPPORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCity() {
		return city;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCity(String newCity) {
		String oldCity = city;
		city = newCity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.MOBILITY_SUPPORT__CITY,
					oldCity, city));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MobilityResource> getMobilityresources() {
		if (mobilityresources == null) {
			mobilityresources = new EObjectContainmentEList<MobilityResource>(MobilityResource.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES);
		}
		return mobilityresources;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GeographicLocation> getGeographicLocations() {
		if (geographicLocations == null) {
			geographicLocations = new EObjectContainmentEList<GeographicLocation>(GeographicLocation.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS);
		}
		return geographicLocations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Agency> getAgency() {
		if (agency == null) {
			agency = new EObjectContainmentEList<Agency>(Agency.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY);
		}
		return agency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Stop_time> getStop_times() {
		if (stop_times == null) {
			stop_times = new EObjectContainmentEList<Stop_time>(Stop_time.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES);
		}
		return stop_times;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Calendar> getCalendar() {
		if (calendar == null) {
			calendar = new EObjectContainmentEList<Calendar>(Calendar.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR);
		}
		return calendar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Calendar_date> getCalendar_dates() {
		if (calendar_dates == null) {
			calendar_dates = new EObjectContainmentEList<Calendar_date>(Calendar_date.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES);
		}
		return calendar_dates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_attribute> getFares() {
		if (fares == null) {
			fares = new EObjectContainmentEList<Fare_attribute>(Fare_attribute.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__FARES);
		}
		return fares;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_rule> getFare_zones() {
		if (fare_zones == null) {
			fare_zones = new EObjectContainmentEList<Fare_rule>(Fare_rule.class, this,
					MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES);
		}
		return fare_zones;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES:
			return ((InternalEList<?>) getMobilityresources()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS:
			return ((InternalEList<?>) getGeographicLocations()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY:
			return ((InternalEList<?>) getAgency()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES:
			return ((InternalEList<?>) getStop_times()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR:
			return ((InternalEList<?>) getCalendar()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES:
			return ((InternalEList<?>) getCalendar_dates()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARES:
			return ((InternalEList<?>) getFares()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES:
			return ((InternalEList<?>) getFare_zones()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CITY:
			return getCity();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES:
			return getMobilityresources();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS:
			return getGeographicLocations();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY:
			return getAgency();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES:
			return getStop_times();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR:
			return getCalendar();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES:
			return getCalendar_dates();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARES:
			return getFares();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES:
			return getFare_zones();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CITY:
			setCity((String) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES:
			getMobilityresources().clear();
			getMobilityresources().addAll((Collection<? extends MobilityResource>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS:
			getGeographicLocations().clear();
			getGeographicLocations().addAll((Collection<? extends GeographicLocation>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY:
			getAgency().clear();
			getAgency().addAll((Collection<? extends Agency>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES:
			getStop_times().clear();
			getStop_times().addAll((Collection<? extends Stop_time>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR:
			getCalendar().clear();
			getCalendar().addAll((Collection<? extends Calendar>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES:
			getCalendar_dates().clear();
			getCalendar_dates().addAll((Collection<? extends Calendar_date>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARES:
			getFares().clear();
			getFares().addAll((Collection<? extends Fare_attribute>) newValue);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES:
			getFare_zones().clear();
			getFare_zones().addAll((Collection<? extends Fare_rule>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CITY:
			setCity(CITY_EDEFAULT);
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES:
			getMobilityresources().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS:
			getGeographicLocations().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY:
			getAgency().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES:
			getStop_times().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR:
			getCalendar().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES:
			getCalendar_dates().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARES:
			getFares().clear();
			return;
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES:
			getFare_zones().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CITY:
			return CITY_EDEFAULT == null ? city != null : !CITY_EDEFAULT.equals(city);
		case MobilityResourcesPackage.MOBILITY_SUPPORT__MOBILITYRESOURCES:
			return mobilityresources != null && !mobilityresources.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS:
			return geographicLocations != null && !geographicLocations.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__AGENCY:
			return agency != null && !agency.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__STOP_TIMES:
			return stop_times != null && !stop_times.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR:
			return calendar != null && !calendar.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__CALENDAR_DATES:
			return calendar_dates != null && !calendar_dates.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARES:
			return fares != null && !fares.isEmpty();
		case MobilityResourcesPackage.MOBILITY_SUPPORT__FARE_ZONES:
			return fare_zones != null && !fare_zones.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (city: ");
		result.append(city);
		result.append(')');
		return result.toString();
	}

} //MobilitySupportImpl
