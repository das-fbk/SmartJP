/**
 */
package mapNotes.impl;

import java.util.Collection;

import mapNotes.Alert;
import mapNotes.MapNotesPackage;
import mapNotes.TransitRemark;
import mapNotes.TripUpdate;
import mapNotes.Vehicle;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transit Remark</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.TransitRemarkImpl#getId <em>Id</em>}</li>
 *   <li>{@link mapNotes.impl.TransitRemarkImpl#isIsDeleted <em>Is Deleted</em>}</li>
 *   <li>{@link mapNotes.impl.TransitRemarkImpl#getTripupdates <em>Tripupdates</em>}</li>
 *   <li>{@link mapNotes.impl.TransitRemarkImpl#getVehicles <em>Vehicles</em>}</li>
 *   <li>{@link mapNotes.impl.TransitRemarkImpl#getAlerts <em>Alerts</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TransitRemarkImpl extends StatusRemarkImpl implements TransitRemark {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsDeleted() <em>Is Deleted</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsDeleted()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_DELETED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsDeleted() <em>Is Deleted</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsDeleted()
	 * @generated
	 * @ordered
	 */
	protected boolean isDeleted = IS_DELETED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTripupdates() <em>Tripupdates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripupdates()
	 * @generated
	 * @ordered
	 */
	protected EList<TripUpdate> tripupdates;

	/**
	 * The cached value of the '{@link #getVehicles() <em>Vehicles</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicles()
	 * @generated
	 * @ordered
	 */
	protected EList<Vehicle> vehicles;

	/**
	 * The cached value of the '{@link #getAlerts() <em>Alerts</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAlerts()
	 * @generated
	 * @ordered
	 */
	protected EList<Alert> alerts;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransitRemarkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.TRANSIT_REMARK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRANSIT_REMARK__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsDeleted() {
		return isDeleted;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsDeleted(boolean newIsDeleted) {
		boolean oldIsDeleted = isDeleted;
		isDeleted = newIsDeleted;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRANSIT_REMARK__IS_DELETED, oldIsDeleted, isDeleted));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TripUpdate> getTripupdates() {
		if (tripupdates == null) {
			tripupdates = new EObjectContainmentEList<TripUpdate>(TripUpdate.class, this, MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES);
		}
		return tripupdates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Vehicle> getVehicles() {
		if (vehicles == null) {
			vehicles = new EObjectContainmentEList<Vehicle>(Vehicle.class, this, MapNotesPackage.TRANSIT_REMARK__VEHICLES);
		}
		return vehicles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Alert> getAlerts() {
		if (alerts == null) {
			alerts = new EObjectContainmentEList<Alert>(Alert.class, this, MapNotesPackage.TRANSIT_REMARK__ALERTS);
		}
		return alerts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES:
				return ((InternalEList<?>)getTripupdates()).basicRemove(otherEnd, msgs);
			case MapNotesPackage.TRANSIT_REMARK__VEHICLES:
				return ((InternalEList<?>)getVehicles()).basicRemove(otherEnd, msgs);
			case MapNotesPackage.TRANSIT_REMARK__ALERTS:
				return ((InternalEList<?>)getAlerts()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.TRANSIT_REMARK__ID:
				return getId();
			case MapNotesPackage.TRANSIT_REMARK__IS_DELETED:
				return isIsDeleted();
			case MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES:
				return getTripupdates();
			case MapNotesPackage.TRANSIT_REMARK__VEHICLES:
				return getVehicles();
			case MapNotesPackage.TRANSIT_REMARK__ALERTS:
				return getAlerts();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.TRANSIT_REMARK__ID:
				setId((String)newValue);
				return;
			case MapNotesPackage.TRANSIT_REMARK__IS_DELETED:
				setIsDeleted((Boolean)newValue);
				return;
			case MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES:
				getTripupdates().clear();
				getTripupdates().addAll((Collection<? extends TripUpdate>)newValue);
				return;
			case MapNotesPackage.TRANSIT_REMARK__VEHICLES:
				getVehicles().clear();
				getVehicles().addAll((Collection<? extends Vehicle>)newValue);
				return;
			case MapNotesPackage.TRANSIT_REMARK__ALERTS:
				getAlerts().clear();
				getAlerts().addAll((Collection<? extends Alert>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRANSIT_REMARK__ID:
				setId(ID_EDEFAULT);
				return;
			case MapNotesPackage.TRANSIT_REMARK__IS_DELETED:
				setIsDeleted(IS_DELETED_EDEFAULT);
				return;
			case MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES:
				getTripupdates().clear();
				return;
			case MapNotesPackage.TRANSIT_REMARK__VEHICLES:
				getVehicles().clear();
				return;
			case MapNotesPackage.TRANSIT_REMARK__ALERTS:
				getAlerts().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRANSIT_REMARK__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case MapNotesPackage.TRANSIT_REMARK__IS_DELETED:
				return isDeleted != IS_DELETED_EDEFAULT;
			case MapNotesPackage.TRANSIT_REMARK__TRIPUPDATES:
				return tripupdates != null && !tripupdates.isEmpty();
			case MapNotesPackage.TRANSIT_REMARK__VEHICLES:
				return vehicles != null && !vehicles.isEmpty();
			case MapNotesPackage.TRANSIT_REMARK__ALERTS:
				return alerts != null && !alerts.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", isDeleted: ");
		result.append(isDeleted);
		result.append(')');
		return result.toString();
	}

} //TransitRemarkImpl
