/**
 */
package mapNotes.impl;

import java.math.BigInteger;

import mapNotes.CongestionLevel;
import mapNotes.MapNotesPackage;
import mapNotes.OccupancyStatus;
import mapNotes.Position;
import mapNotes.TripDescriptor;
import mapNotes.Vehicle;
import mapNotes.VehicleDescriptor;
import mapNotes.VehicleStopStatus;

import mobilityResources.Stop;
import mobilityResources.Stop_time;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Vehicle</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.VehicleImpl#getVehicledescriptor <em>Vehicledescriptor</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getTripdescriptor <em>Tripdescriptor</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getCurrent_stop_sequence <em>Current stop sequence</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getCurrent_status <em>Current status</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getTimestamp <em>Timestamp</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getCongestion_level <em>Congestion level</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getOccupancyStatus <em>Occupancy Status</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleImpl#getPosition <em>Position</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VehicleImpl extends MinimalEObjectImpl.Container implements Vehicle {
	/**
	 * The cached value of the '{@link #getVehicledescriptor() <em>Vehicledescriptor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicledescriptor()
	 * @generated
	 * @ordered
	 */
	protected VehicleDescriptor vehicledescriptor;

	/**
	 * The cached value of the '{@link #getTripdescriptor() <em>Tripdescriptor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripdescriptor()
	 * @generated
	 * @ordered
	 */
	protected TripDescriptor tripdescriptor;

	/**
	 * The cached value of the '{@link #getCurrent_stop_sequence() <em>Current stop sequence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrent_stop_sequence()
	 * @generated
	 * @ordered
	 */
	protected Stop_time current_stop_sequence;

	/**
	 * The cached value of the '{@link #getStop_id() <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_id()
	 * @generated
	 * @ordered
	 */
	protected Stop stop_id;

	/**
	 * The default value of the '{@link #getCurrent_status() <em>Current status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrent_status()
	 * @generated
	 * @ordered
	 */
	protected static final VehicleStopStatus CURRENT_STATUS_EDEFAULT = VehicleStopStatus.INCOMING_AT;

	/**
	 * The cached value of the '{@link #getCurrent_status() <em>Current status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrent_status()
	 * @generated
	 * @ordered
	 */
	protected VehicleStopStatus current_status = CURRENT_STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getTimestamp() <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimestamp()
	 * @generated
	 * @ordered
	 */
	protected static final BigInteger TIMESTAMP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTimestamp() <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimestamp()
	 * @generated
	 * @ordered
	 */
	protected BigInteger timestamp = TIMESTAMP_EDEFAULT;

	/**
	 * The default value of the '{@link #getCongestion_level() <em>Congestion level</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCongestion_level()
	 * @generated
	 * @ordered
	 */
	protected static final CongestionLevel CONGESTION_LEVEL_EDEFAULT = CongestionLevel.UNKNOWN_CONGESTION_LEVEL;

	/**
	 * The cached value of the '{@link #getCongestion_level() <em>Congestion level</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCongestion_level()
	 * @generated
	 * @ordered
	 */
	protected CongestionLevel congestion_level = CONGESTION_LEVEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getOccupancyStatus() <em>Occupancy Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOccupancyStatus()
	 * @generated
	 * @ordered
	 */
	protected static final OccupancyStatus OCCUPANCY_STATUS_EDEFAULT = OccupancyStatus.EMPTY;

	/**
	 * The cached value of the '{@link #getOccupancyStatus() <em>Occupancy Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOccupancyStatus()
	 * @generated
	 * @ordered
	 */
	protected OccupancyStatus occupancyStatus = OCCUPANCY_STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPosition() <em>Position</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPosition()
	 * @generated
	 * @ordered
	 */
	protected Position position;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.VEHICLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleDescriptor getVehicledescriptor() {
		return vehicledescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVehicledescriptor(VehicleDescriptor newVehicledescriptor, NotificationChain msgs) {
		VehicleDescriptor oldVehicledescriptor = vehicledescriptor;
		vehicledescriptor = newVehicledescriptor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR, oldVehicledescriptor, newVehicledescriptor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVehicledescriptor(VehicleDescriptor newVehicledescriptor) {
		if (newVehicledescriptor != vehicledescriptor) {
			NotificationChain msgs = null;
			if (vehicledescriptor != null)
				msgs = ((InternalEObject)vehicledescriptor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR, null, msgs);
			if (newVehicledescriptor != null)
				msgs = ((InternalEObject)newVehicledescriptor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR, null, msgs);
			msgs = basicSetVehicledescriptor(newVehicledescriptor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR, newVehicledescriptor, newVehicledescriptor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor getTripdescriptor() {
		if (tripdescriptor != null && tripdescriptor.eIsProxy()) {
			InternalEObject oldTripdescriptor = (InternalEObject)tripdescriptor;
			tripdescriptor = (TripDescriptor)eResolveProxy(oldTripdescriptor);
			if (tripdescriptor != oldTripdescriptor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.VEHICLE__TRIPDESCRIPTOR, oldTripdescriptor, tripdescriptor));
			}
		}
		return tripdescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor basicGetTripdescriptor() {
		return tripdescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTripdescriptor(TripDescriptor newTripdescriptor) {
		TripDescriptor oldTripdescriptor = tripdescriptor;
		tripdescriptor = newTripdescriptor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__TRIPDESCRIPTOR, oldTripdescriptor, tripdescriptor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_time getCurrent_stop_sequence() {
		if (current_stop_sequence != null && current_stop_sequence.eIsProxy()) {
			InternalEObject oldCurrent_stop_sequence = (InternalEObject)current_stop_sequence;
			current_stop_sequence = (Stop_time)eResolveProxy(oldCurrent_stop_sequence);
			if (current_stop_sequence != oldCurrent_stop_sequence) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE, oldCurrent_stop_sequence, current_stop_sequence));
			}
		}
		return current_stop_sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_time basicGetCurrent_stop_sequence() {
		return current_stop_sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCurrent_stop_sequence(Stop_time newCurrent_stop_sequence) {
		Stop_time oldCurrent_stop_sequence = current_stop_sequence;
		current_stop_sequence = newCurrent_stop_sequence;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE, oldCurrent_stop_sequence, current_stop_sequence));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop getStop_id() {
		if (stop_id != null && stop_id.eIsProxy()) {
			InternalEObject oldStop_id = (InternalEObject)stop_id;
			stop_id = (Stop)eResolveProxy(oldStop_id);
			if (stop_id != oldStop_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.VEHICLE__STOP_ID, oldStop_id, stop_id));
			}
		}
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop basicGetStop_id() {
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_id(Stop newStop_id) {
		Stop oldStop_id = stop_id;
		stop_id = newStop_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__STOP_ID, oldStop_id, stop_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleStopStatus getCurrent_status() {
		return current_status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCurrent_status(VehicleStopStatus newCurrent_status) {
		VehicleStopStatus oldCurrent_status = current_status;
		current_status = newCurrent_status == null ? CURRENT_STATUS_EDEFAULT : newCurrent_status;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__CURRENT_STATUS, oldCurrent_status, current_status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigInteger getTimestamp() {
		return timestamp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimestamp(BigInteger newTimestamp) {
		BigInteger oldTimestamp = timestamp;
		timestamp = newTimestamp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__TIMESTAMP, oldTimestamp, timestamp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CongestionLevel getCongestion_level() {
		return congestion_level;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCongestion_level(CongestionLevel newCongestion_level) {
		CongestionLevel oldCongestion_level = congestion_level;
		congestion_level = newCongestion_level == null ? CONGESTION_LEVEL_EDEFAULT : newCongestion_level;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__CONGESTION_LEVEL, oldCongestion_level, congestion_level));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OccupancyStatus getOccupancyStatus() {
		return occupancyStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOccupancyStatus(OccupancyStatus newOccupancyStatus) {
		OccupancyStatus oldOccupancyStatus = occupancyStatus;
		occupancyStatus = newOccupancyStatus == null ? OCCUPANCY_STATUS_EDEFAULT : newOccupancyStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__OCCUPANCY_STATUS, oldOccupancyStatus, occupancyStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Position getPosition() {
		return position;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPosition(Position newPosition, NotificationChain msgs) {
		Position oldPosition = position;
		position = newPosition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__POSITION, oldPosition, newPosition);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPosition(Position newPosition) {
		if (newPosition != position) {
			NotificationChain msgs = null;
			if (position != null)
				msgs = ((InternalEObject)position).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.VEHICLE__POSITION, null, msgs);
			if (newPosition != null)
				msgs = ((InternalEObject)newPosition).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.VEHICLE__POSITION, null, msgs);
			msgs = basicSetPosition(newPosition, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE__POSITION, newPosition, newPosition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR:
				return basicSetVehicledescriptor(null, msgs);
			case MapNotesPackage.VEHICLE__POSITION:
				return basicSetPosition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR:
				return getVehicledescriptor();
			case MapNotesPackage.VEHICLE__TRIPDESCRIPTOR:
				if (resolve) return getTripdescriptor();
				return basicGetTripdescriptor();
			case MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE:
				if (resolve) return getCurrent_stop_sequence();
				return basicGetCurrent_stop_sequence();
			case MapNotesPackage.VEHICLE__STOP_ID:
				if (resolve) return getStop_id();
				return basicGetStop_id();
			case MapNotesPackage.VEHICLE__CURRENT_STATUS:
				return getCurrent_status();
			case MapNotesPackage.VEHICLE__TIMESTAMP:
				return getTimestamp();
			case MapNotesPackage.VEHICLE__CONGESTION_LEVEL:
				return getCongestion_level();
			case MapNotesPackage.VEHICLE__OCCUPANCY_STATUS:
				return getOccupancyStatus();
			case MapNotesPackage.VEHICLE__POSITION:
				return getPosition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR:
				setVehicledescriptor((VehicleDescriptor)newValue);
				return;
			case MapNotesPackage.VEHICLE__TRIPDESCRIPTOR:
				setTripdescriptor((TripDescriptor)newValue);
				return;
			case MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE:
				setCurrent_stop_sequence((Stop_time)newValue);
				return;
			case MapNotesPackage.VEHICLE__STOP_ID:
				setStop_id((Stop)newValue);
				return;
			case MapNotesPackage.VEHICLE__CURRENT_STATUS:
				setCurrent_status((VehicleStopStatus)newValue);
				return;
			case MapNotesPackage.VEHICLE__TIMESTAMP:
				setTimestamp((BigInteger)newValue);
				return;
			case MapNotesPackage.VEHICLE__CONGESTION_LEVEL:
				setCongestion_level((CongestionLevel)newValue);
				return;
			case MapNotesPackage.VEHICLE__OCCUPANCY_STATUS:
				setOccupancyStatus((OccupancyStatus)newValue);
				return;
			case MapNotesPackage.VEHICLE__POSITION:
				setPosition((Position)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR:
				setVehicledescriptor((VehicleDescriptor)null);
				return;
			case MapNotesPackage.VEHICLE__TRIPDESCRIPTOR:
				setTripdescriptor((TripDescriptor)null);
				return;
			case MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE:
				setCurrent_stop_sequence((Stop_time)null);
				return;
			case MapNotesPackage.VEHICLE__STOP_ID:
				setStop_id((Stop)null);
				return;
			case MapNotesPackage.VEHICLE__CURRENT_STATUS:
				setCurrent_status(CURRENT_STATUS_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE__TIMESTAMP:
				setTimestamp(TIMESTAMP_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE__CONGESTION_LEVEL:
				setCongestion_level(CONGESTION_LEVEL_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE__OCCUPANCY_STATUS:
				setOccupancyStatus(OCCUPANCY_STATUS_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE__POSITION:
				setPosition((Position)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE__VEHICLEDESCRIPTOR:
				return vehicledescriptor != null;
			case MapNotesPackage.VEHICLE__TRIPDESCRIPTOR:
				return tripdescriptor != null;
			case MapNotesPackage.VEHICLE__CURRENT_STOP_SEQUENCE:
				return current_stop_sequence != null;
			case MapNotesPackage.VEHICLE__STOP_ID:
				return stop_id != null;
			case MapNotesPackage.VEHICLE__CURRENT_STATUS:
				return current_status != CURRENT_STATUS_EDEFAULT;
			case MapNotesPackage.VEHICLE__TIMESTAMP:
				return TIMESTAMP_EDEFAULT == null ? timestamp != null : !TIMESTAMP_EDEFAULT.equals(timestamp);
			case MapNotesPackage.VEHICLE__CONGESTION_LEVEL:
				return congestion_level != CONGESTION_LEVEL_EDEFAULT;
			case MapNotesPackage.VEHICLE__OCCUPANCY_STATUS:
				return occupancyStatus != OCCUPANCY_STATUS_EDEFAULT;
			case MapNotesPackage.VEHICLE__POSITION:
				return position != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (current_status: ");
		result.append(current_status);
		result.append(", timestamp: ");
		result.append(timestamp);
		result.append(", congestion_level: ");
		result.append(congestion_level);
		result.append(", occupancyStatus: ");
		result.append(occupancyStatus);
		result.append(')');
		return result.toString();
	}

} //VehicleImpl
