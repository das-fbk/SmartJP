/**
 */
package mapNotes.impl;

import java.math.BigInteger;

import java.util.Collection;

import mapNotes.MapNotesPackage;
import mapNotes.StopTimeUpdate;
import mapNotes.TripDescriptor;
import mapNotes.TripUpdate;
import mapNotes.VehicleDescriptor;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trip Update</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.TripUpdateImpl#getTimestamp <em>Timestamp</em>}</li>
 *   <li>{@link mapNotes.impl.TripUpdateImpl#getDelay <em>Delay</em>}</li>
 *   <li>{@link mapNotes.impl.TripUpdateImpl#getTripdescriptor <em>Tripdescriptor</em>}</li>
 *   <li>{@link mapNotes.impl.TripUpdateImpl#getVehicledescriptor <em>Vehicledescriptor</em>}</li>
 *   <li>{@link mapNotes.impl.TripUpdateImpl#getStop_time_updates <em>Stop time updates</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TripUpdateImpl extends MinimalEObjectImpl.Container implements TripUpdate {
	/**
	 * The default value of the '{@link #getTimestamp() <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimestamp()
	 * @generated
	 * @ordered
	 */
	protected static final BigInteger TIMESTAMP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTimestamp() <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimestamp()
	 * @generated
	 * @ordered
	 */
	protected BigInteger timestamp = TIMESTAMP_EDEFAULT;

	/**
	 * The default value of the '{@link #getDelay() <em>Delay</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelay()
	 * @generated
	 * @ordered
	 */
	protected static final int DELAY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDelay() <em>Delay</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDelay()
	 * @generated
	 * @ordered
	 */
	protected int delay = DELAY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTripdescriptor() <em>Tripdescriptor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripdescriptor()
	 * @generated
	 * @ordered
	 */
	protected TripDescriptor tripdescriptor;

	/**
	 * The cached value of the '{@link #getVehicledescriptor() <em>Vehicledescriptor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVehicledescriptor()
	 * @generated
	 * @ordered
	 */
	protected VehicleDescriptor vehicledescriptor;

	/**
	 * The cached value of the '{@link #getStop_time_updates() <em>Stop time updates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_time_updates()
	 * @generated
	 * @ordered
	 */
	protected EList<StopTimeUpdate> stop_time_updates;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripUpdateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.TRIP_UPDATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigInteger getTimestamp() {
		return timestamp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimestamp(BigInteger newTimestamp) {
		BigInteger oldTimestamp = timestamp;
		timestamp = newTimestamp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_UPDATE__TIMESTAMP, oldTimestamp, timestamp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDelay() {
		return delay;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDelay(int newDelay) {
		int oldDelay = delay;
		delay = newDelay;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_UPDATE__DELAY, oldDelay, delay));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor getTripdescriptor() {
		return tripdescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTripdescriptor(TripDescriptor newTripdescriptor, NotificationChain msgs) {
		TripDescriptor oldTripdescriptor = tripdescriptor;
		tripdescriptor = newTripdescriptor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR, oldTripdescriptor, newTripdescriptor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTripdescriptor(TripDescriptor newTripdescriptor) {
		if (newTripdescriptor != tripdescriptor) {
			NotificationChain msgs = null;
			if (tripdescriptor != null)
				msgs = ((InternalEObject)tripdescriptor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR, null, msgs);
			if (newTripdescriptor != null)
				msgs = ((InternalEObject)newTripdescriptor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR, null, msgs);
			msgs = basicSetTripdescriptor(newTripdescriptor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR, newTripdescriptor, newTripdescriptor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleDescriptor getVehicledescriptor() {
		if (vehicledescriptor != null && vehicledescriptor.eIsProxy()) {
			InternalEObject oldVehicledescriptor = (InternalEObject)vehicledescriptor;
			vehicledescriptor = (VehicleDescriptor)eResolveProxy(oldVehicledescriptor);
			if (vehicledescriptor != oldVehicledescriptor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR, oldVehicledescriptor, vehicledescriptor));
			}
		}
		return vehicledescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleDescriptor basicGetVehicledescriptor() {
		return vehicledescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVehicledescriptor(VehicleDescriptor newVehicledescriptor) {
		VehicleDescriptor oldVehicledescriptor = vehicledescriptor;
		vehicledescriptor = newVehicledescriptor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR, oldVehicledescriptor, vehicledescriptor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StopTimeUpdate> getStop_time_updates() {
		if (stop_time_updates == null) {
			stop_time_updates = new EObjectContainmentEList<StopTimeUpdate>(StopTimeUpdate.class, this, MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES);
		}
		return stop_time_updates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR:
				return basicSetTripdescriptor(null, msgs);
			case MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES:
				return ((InternalEList<?>)getStop_time_updates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.TRIP_UPDATE__TIMESTAMP:
				return getTimestamp();
			case MapNotesPackage.TRIP_UPDATE__DELAY:
				return getDelay();
			case MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR:
				return getTripdescriptor();
			case MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR:
				if (resolve) return getVehicledescriptor();
				return basicGetVehicledescriptor();
			case MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES:
				return getStop_time_updates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.TRIP_UPDATE__TIMESTAMP:
				setTimestamp((BigInteger)newValue);
				return;
			case MapNotesPackage.TRIP_UPDATE__DELAY:
				setDelay((Integer)newValue);
				return;
			case MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR:
				setTripdescriptor((TripDescriptor)newValue);
				return;
			case MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR:
				setVehicledescriptor((VehicleDescriptor)newValue);
				return;
			case MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES:
				getStop_time_updates().clear();
				getStop_time_updates().addAll((Collection<? extends StopTimeUpdate>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRIP_UPDATE__TIMESTAMP:
				setTimestamp(TIMESTAMP_EDEFAULT);
				return;
			case MapNotesPackage.TRIP_UPDATE__DELAY:
				setDelay(DELAY_EDEFAULT);
				return;
			case MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR:
				setTripdescriptor((TripDescriptor)null);
				return;
			case MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR:
				setVehicledescriptor((VehicleDescriptor)null);
				return;
			case MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES:
				getStop_time_updates().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRIP_UPDATE__TIMESTAMP:
				return TIMESTAMP_EDEFAULT == null ? timestamp != null : !TIMESTAMP_EDEFAULT.equals(timestamp);
			case MapNotesPackage.TRIP_UPDATE__DELAY:
				return delay != DELAY_EDEFAULT;
			case MapNotesPackage.TRIP_UPDATE__TRIPDESCRIPTOR:
				return tripdescriptor != null;
			case MapNotesPackage.TRIP_UPDATE__VEHICLEDESCRIPTOR:
				return vehicledescriptor != null;
			case MapNotesPackage.TRIP_UPDATE__STOP_TIME_UPDATES:
				return stop_time_updates != null && !stop_time_updates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (timestamp: ");
		result.append(timestamp);
		result.append(", delay: ");
		result.append(delay);
		result.append(')');
		return result.toString();
	}

} //TripUpdateImpl
