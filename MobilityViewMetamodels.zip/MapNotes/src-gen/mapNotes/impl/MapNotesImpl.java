/**
 */
package mapNotes.impl;

import java.util.Collection;
import java.util.Date;

import mapNotes.MapNotes;
import mapNotes.MapNotesPackage;
import mapNotes.StatusRemark;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Map Notes</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.MapNotesImpl#getCityName <em>City Name</em>}</li>
 *   <li>{@link mapNotes.impl.MapNotesImpl#getLastUpdate <em>Last Update</em>}</li>
 *   <li>{@link mapNotes.impl.MapNotesImpl#getStatusRemarks <em>Status Remarks</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MapNotesImpl extends MinimalEObjectImpl.Container implements MapNotes {
	/**
	 * The default value of the '{@link #getCityName() <em>City Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityName()
	 * @generated
	 * @ordered
	 */
	protected static final String CITY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCityName() <em>City Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityName()
	 * @generated
	 * @ordered
	 */
	protected String cityName = CITY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getLastUpdate() <em>Last Update</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastUpdate()
	 * @generated
	 * @ordered
	 */
	protected static final Date LAST_UPDATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLastUpdate() <em>Last Update</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLastUpdate()
	 * @generated
	 * @ordered
	 */
	protected Date lastUpdate = LAST_UPDATE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStatusRemarks() <em>Status Remarks</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatusRemarks()
	 * @generated
	 * @ordered
	 */
	protected EList<StatusRemark> statusRemarks;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MapNotesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.MAP_NOTES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCityName(String newCityName) {
		String oldCityName = cityName;
		cityName = newCityName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.MAP_NOTES__CITY_NAME, oldCityName, cityName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getLastUpdate() {
		return lastUpdate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLastUpdate(Date newLastUpdate) {
		Date oldLastUpdate = lastUpdate;
		lastUpdate = newLastUpdate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.MAP_NOTES__LAST_UPDATE, oldLastUpdate, lastUpdate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StatusRemark> getStatusRemarks() {
		if (statusRemarks == null) {
			statusRemarks = new EObjectContainmentEList<StatusRemark>(StatusRemark.class, this, MapNotesPackage.MAP_NOTES__STATUS_REMARKS);
		}
		return statusRemarks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.MAP_NOTES__STATUS_REMARKS:
				return ((InternalEList<?>)getStatusRemarks()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.MAP_NOTES__CITY_NAME:
				return getCityName();
			case MapNotesPackage.MAP_NOTES__LAST_UPDATE:
				return getLastUpdate();
			case MapNotesPackage.MAP_NOTES__STATUS_REMARKS:
				return getStatusRemarks();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.MAP_NOTES__CITY_NAME:
				setCityName((String)newValue);
				return;
			case MapNotesPackage.MAP_NOTES__LAST_UPDATE:
				setLastUpdate((Date)newValue);
				return;
			case MapNotesPackage.MAP_NOTES__STATUS_REMARKS:
				getStatusRemarks().clear();
				getStatusRemarks().addAll((Collection<? extends StatusRemark>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.MAP_NOTES__CITY_NAME:
				setCityName(CITY_NAME_EDEFAULT);
				return;
			case MapNotesPackage.MAP_NOTES__LAST_UPDATE:
				setLastUpdate(LAST_UPDATE_EDEFAULT);
				return;
			case MapNotesPackage.MAP_NOTES__STATUS_REMARKS:
				getStatusRemarks().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.MAP_NOTES__CITY_NAME:
				return CITY_NAME_EDEFAULT == null ? cityName != null : !CITY_NAME_EDEFAULT.equals(cityName);
			case MapNotesPackage.MAP_NOTES__LAST_UPDATE:
				return LAST_UPDATE_EDEFAULT == null ? lastUpdate != null : !LAST_UPDATE_EDEFAULT.equals(lastUpdate);
			case MapNotesPackage.MAP_NOTES__STATUS_REMARKS:
				return statusRemarks != null && !statusRemarks.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (cityName: ");
		result.append(cityName);
		result.append(", lastUpdate: ");
		result.append(lastUpdate);
		result.append(')');
		return result.toString();
	}

} //MapNotesImpl
