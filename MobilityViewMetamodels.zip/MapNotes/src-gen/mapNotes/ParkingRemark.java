/**
 */
package mapNotes;

import mobilityResources.Parking;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parking Remark</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.ParkingRemark#getParkingstatus <em>Parkingstatus</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getParkingRemark()
 * @model
 * @generated
 */
public interface ParkingRemark extends StatusRemark {
	/**
	 * Returns the value of the '<em><b>Parkingstatus</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Parking}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parkingstatus</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parkingstatus</em>' reference list.
	 * @see mapNotes.MapNotesPackage#getParkingRemark_Parkingstatus()
	 * @model
	 * @generated
	 */
	EList<Parking> getParkingstatus();

} // ParkingRemark
