/**
 */
package mapNotes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Cause</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage#getCause()
 * @model
 * @generated
 */
public enum Cause implements Enumerator {
	/**
	 * The '<em><b>UNKNOWN CAUSE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_CAUSE_VALUE
	 * @generated
	 * @ordered
	 */
	UNKNOWN_CAUSE(0, "UNKNOWN_CAUSE", "UNKNOWN_CAUSE"),

	/**
	 * The '<em><b>OTHER CAUSE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #OTHER_CAUSE_VALUE
	 * @generated
	 * @ordered
	 */
	OTHER_CAUSE(1, "OTHER_CAUSE", "OTHER_CAUSE"),

	/**
	 * The '<em><b>TECHNICAL PROBLEM</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TECHNICAL_PROBLEM_VALUE
	 * @generated
	 * @ordered
	 */
	TECHNICAL_PROBLEM(2, "TECHNICAL_PROBLEM", "TECHNICAL_PROBLEM"),

	/**
	 * The '<em><b>STRIKE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STRIKE_VALUE
	 * @generated
	 * @ordered
	 */
	STRIKE(3, "STRIKE", "STRIKE"),

	/**
	 * The '<em><b>DEMONSTRATION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEMONSTRATION_VALUE
	 * @generated
	 * @ordered
	 */
	DEMONSTRATION(4, "DEMONSTRATION", "DEMONSTRATION"),

	/**
	 * The '<em><b>ACCIDENT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ACCIDENT_VALUE
	 * @generated
	 * @ordered
	 */
	ACCIDENT(5, "ACCIDENT", "ACCIDENT"),

	/**
	 * The '<em><b>HOLIDAY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HOLIDAY_VALUE
	 * @generated
	 * @ordered
	 */
	HOLIDAY(6, "HOLIDAY", "HOLIDAY"),

	/**
	 * The '<em><b>WEATHER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WEATHER_VALUE
	 * @generated
	 * @ordered
	 */
	WEATHER(7, "WEATHER", "WEATHER"),

	/**
	 * The '<em><b>MAINTENANCE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MAINTENANCE_VALUE
	 * @generated
	 * @ordered
	 */
	MAINTENANCE(8, "MAINTENANCE", "MAINTENANCE"),

	/**
	 * The '<em><b>CONSTRUCTION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONSTRUCTION_VALUE
	 * @generated
	 * @ordered
	 */
	CONSTRUCTION(9, "CONSTRUCTION", "CONSTRUCTION"),

	/**
	 * The '<em><b>POLICE ACTIVITY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #POLICE_ACTIVITY_VALUE
	 * @generated
	 * @ordered
	 */
	POLICE_ACTIVITY(10, "POLICE_ACTIVITY", "POLICE_ACTIVITY"),

	/**
	 * The '<em><b>MEDICAL EMERGENCY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEDICAL_EMERGENCY_VALUE
	 * @generated
	 * @ordered
	 */
	MEDICAL_EMERGENCY(11, "MEDICAL_EMERGENCY", "MEDICAL_EMERGENCY");

	/**
	 * The '<em><b>UNKNOWN CAUSE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNKNOWN CAUSE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_CAUSE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int UNKNOWN_CAUSE_VALUE = 0;

	/**
	 * The '<em><b>OTHER CAUSE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>OTHER CAUSE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #OTHER_CAUSE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int OTHER_CAUSE_VALUE = 1;

	/**
	 * The '<em><b>TECHNICAL PROBLEM</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>TECHNICAL PROBLEM</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TECHNICAL_PROBLEM
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int TECHNICAL_PROBLEM_VALUE = 2;

	/**
	 * The '<em><b>STRIKE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>STRIKE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STRIKE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int STRIKE_VALUE = 3;

	/**
	 * The '<em><b>DEMONSTRATION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DEMONSTRATION</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEMONSTRATION
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int DEMONSTRATION_VALUE = 4;

	/**
	 * The '<em><b>ACCIDENT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ACCIDENT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ACCIDENT
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ACCIDENT_VALUE = 5;

	/**
	 * The '<em><b>HOLIDAY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>HOLIDAY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #HOLIDAY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int HOLIDAY_VALUE = 6;

	/**
	 * The '<em><b>WEATHER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>WEATHER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #WEATHER
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int WEATHER_VALUE = 7;

	/**
	 * The '<em><b>MAINTENANCE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MAINTENANCE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MAINTENANCE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int MAINTENANCE_VALUE = 8;

	/**
	 * The '<em><b>CONSTRUCTION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CONSTRUCTION</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONSTRUCTION
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CONSTRUCTION_VALUE = 9;

	/**
	 * The '<em><b>POLICE ACTIVITY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>POLICE ACTIVITY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #POLICE_ACTIVITY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int POLICE_ACTIVITY_VALUE = 10;

	/**
	 * The '<em><b>MEDICAL EMERGENCY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MEDICAL EMERGENCY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MEDICAL_EMERGENCY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int MEDICAL_EMERGENCY_VALUE = 11;

	/**
	 * An array of all the '<em><b>Cause</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Cause[] VALUES_ARRAY = new Cause[] { UNKNOWN_CAUSE, OTHER_CAUSE, TECHNICAL_PROBLEM, STRIKE,
			DEMONSTRATION, ACCIDENT, HOLIDAY, WEATHER, MAINTENANCE, CONSTRUCTION, POLICE_ACTIVITY, MEDICAL_EMERGENCY, };

	/**
	 * A public read-only list of all the '<em><b>Cause</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Cause> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Cause</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Cause get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Cause result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Cause</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Cause getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Cause result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Cause</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Cause get(int value) {
		switch (value) {
		case UNKNOWN_CAUSE_VALUE:
			return UNKNOWN_CAUSE;
		case OTHER_CAUSE_VALUE:
			return OTHER_CAUSE;
		case TECHNICAL_PROBLEM_VALUE:
			return TECHNICAL_PROBLEM;
		case STRIKE_VALUE:
			return STRIKE;
		case DEMONSTRATION_VALUE:
			return DEMONSTRATION;
		case ACCIDENT_VALUE:
			return ACCIDENT;
		case HOLIDAY_VALUE:
			return HOLIDAY;
		case WEATHER_VALUE:
			return WEATHER;
		case MAINTENANCE_VALUE:
			return MAINTENANCE;
		case CONSTRUCTION_VALUE:
			return CONSTRUCTION;
		case POLICE_ACTIVITY_VALUE:
			return POLICE_ACTIVITY;
		case MEDICAL_EMERGENCY_VALUE:
			return MEDICAL_EMERGENCY;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Cause(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //Cause
