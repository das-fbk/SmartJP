/**
 */
package mapNotes;

import java.math.BigInteger;

import mobilityResources.Stop;
import mobilityResources.Stop_time;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.Vehicle#getVehicledescriptor <em>Vehicledescriptor</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getTripdescriptor <em>Tripdescriptor</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getCurrent_stop_sequence <em>Current stop sequence</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getCurrent_status <em>Current status</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getTimestamp <em>Timestamp</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getCongestion_level <em>Congestion level</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getOccupancyStatus <em>Occupancy Status</em>}</li>
 *   <li>{@link mapNotes.Vehicle#getPosition <em>Position</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getVehicle()
 * @model
 * @generated
 */
public interface Vehicle extends EObject {
	/**
	 * Returns the value of the '<em><b>Vehicledescriptor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vehicledescriptor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicledescriptor</em>' containment reference.
	 * @see #setVehicledescriptor(VehicleDescriptor)
	 * @see mapNotes.MapNotesPackage#getVehicle_Vehicledescriptor()
	 * @model containment="true"
	 * @generated
	 */
	VehicleDescriptor getVehicledescriptor();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getVehicledescriptor <em>Vehicledescriptor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehicledescriptor</em>' containment reference.
	 * @see #getVehicledescriptor()
	 * @generated
	 */
	void setVehicledescriptor(VehicleDescriptor value);

	/**
	 * Returns the value of the '<em><b>Tripdescriptor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tripdescriptor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tripdescriptor</em>' reference.
	 * @see #setTripdescriptor(TripDescriptor)
	 * @see mapNotes.MapNotesPackage#getVehicle_Tripdescriptor()
	 * @model
	 * @generated
	 */
	TripDescriptor getTripdescriptor();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getTripdescriptor <em>Tripdescriptor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tripdescriptor</em>' reference.
	 * @see #getTripdescriptor()
	 * @generated
	 */
	void setTripdescriptor(TripDescriptor value);

	/**
	 * Returns the value of the '<em><b>Current stop sequence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Current stop sequence</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current stop sequence</em>' reference.
	 * @see #setCurrent_stop_sequence(Stop_time)
	 * @see mapNotes.MapNotesPackage#getVehicle_Current_stop_sequence()
	 * @model
	 * @generated
	 */
	Stop_time getCurrent_stop_sequence();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getCurrent_stop_sequence <em>Current stop sequence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current stop sequence</em>' reference.
	 * @see #getCurrent_stop_sequence()
	 * @generated
	 */
	void setCurrent_stop_sequence(Stop_time value);

	/**
	 * Returns the value of the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop id</em>' reference.
	 * @see #setStop_id(Stop)
	 * @see mapNotes.MapNotesPackage#getVehicle_Stop_id()
	 * @model
	 * @generated
	 */
	Stop getStop_id();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getStop_id <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop id</em>' reference.
	 * @see #getStop_id()
	 * @generated
	 */
	void setStop_id(Stop value);

	/**
	 * Returns the value of the '<em><b>Current status</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.VehicleStopStatus}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Current status</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current status</em>' attribute.
	 * @see mapNotes.VehicleStopStatus
	 * @see #setCurrent_status(VehicleStopStatus)
	 * @see mapNotes.MapNotesPackage#getVehicle_Current_status()
	 * @model
	 * @generated
	 */
	VehicleStopStatus getCurrent_status();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getCurrent_status <em>Current status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current status</em>' attribute.
	 * @see mapNotes.VehicleStopStatus
	 * @see #getCurrent_status()
	 * @generated
	 */
	void setCurrent_status(VehicleStopStatus value);

	/**
	 * Returns the value of the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Timestamp</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Timestamp</em>' attribute.
	 * @see #setTimestamp(BigInteger)
	 * @see mapNotes.MapNotesPackage#getVehicle_Timestamp()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getTimestamp();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getTimestamp <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Timestamp</em>' attribute.
	 * @see #getTimestamp()
	 * @generated
	 */
	void setTimestamp(BigInteger value);

	/**
	 * Returns the value of the '<em><b>Congestion level</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.CongestionLevel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Congestion level</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Congestion level</em>' attribute.
	 * @see mapNotes.CongestionLevel
	 * @see #setCongestion_level(CongestionLevel)
	 * @see mapNotes.MapNotesPackage#getVehicle_Congestion_level()
	 * @model
	 * @generated
	 */
	CongestionLevel getCongestion_level();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getCongestion_level <em>Congestion level</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Congestion level</em>' attribute.
	 * @see mapNotes.CongestionLevel
	 * @see #getCongestion_level()
	 * @generated
	 */
	void setCongestion_level(CongestionLevel value);

	/**
	 * Returns the value of the '<em><b>Occupancy Status</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.OccupancyStatus}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Occupancy Status</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Occupancy Status</em>' attribute.
	 * @see mapNotes.OccupancyStatus
	 * @see #setOccupancyStatus(OccupancyStatus)
	 * @see mapNotes.MapNotesPackage#getVehicle_OccupancyStatus()
	 * @model
	 * @generated
	 */
	OccupancyStatus getOccupancyStatus();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getOccupancyStatus <em>Occupancy Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Occupancy Status</em>' attribute.
	 * @see mapNotes.OccupancyStatus
	 * @see #getOccupancyStatus()
	 * @generated
	 */
	void setOccupancyStatus(OccupancyStatus value);

	/**
	 * Returns the value of the '<em><b>Position</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Position</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Position</em>' containment reference.
	 * @see #setPosition(Position)
	 * @see mapNotes.MapNotesPackage#getVehicle_Position()
	 * @model containment="true"
	 * @generated
	 */
	Position getPosition();

	/**
	 * Sets the value of the '{@link mapNotes.Vehicle#getPosition <em>Position</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Position</em>' containment reference.
	 * @see #getPosition()
	 * @generated
	 */
	void setPosition(Position value);

} // Vehicle
