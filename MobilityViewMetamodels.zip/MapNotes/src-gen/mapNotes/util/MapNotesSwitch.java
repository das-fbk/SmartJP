/**
 */
package mapNotes.util;

import mapNotes.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage
 * @generated
 */
public class MapNotesSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MapNotesPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotesSwitch() {
		if (modelPackage == null) {
			modelPackage = MapNotesPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case MapNotesPackage.MAP_NOTES: {
			MapNotes mapNotes = (MapNotes) theEObject;
			T result = caseMapNotes(mapNotes);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.TRAFFIC_REMARK: {
			TrafficRemark trafficRemark = (TrafficRemark) theEObject;
			T result = caseTrafficRemark(trafficRemark);
			if (result == null)
				result = caseStatusRemark(trafficRemark);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.STATUS_REMARK: {
			StatusRemark statusRemark = (StatusRemark) theEObject;
			T result = caseStatusRemark(statusRemark);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.BIKE_SHARING_REMARK: {
			BikeSharingRemark bikeSharingRemark = (BikeSharingRemark) theEObject;
			T result = caseBikeSharingRemark(bikeSharingRemark);
			if (result == null)
				result = caseStatusRemark(bikeSharingRemark);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.PARKING_REMARK: {
			ParkingRemark parkingRemark = (ParkingRemark) theEObject;
			T result = caseParkingRemark(parkingRemark);
			if (result == null)
				result = caseStatusRemark(parkingRemark);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.TRANSIT_REMARK: {
			TransitRemark transitRemark = (TransitRemark) theEObject;
			T result = caseTransitRemark(transitRemark);
			if (result == null)
				result = caseStatusRemark(transitRemark);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.TRIP_UPDATE: {
			TripUpdate tripUpdate = (TripUpdate) theEObject;
			T result = caseTripUpdate(tripUpdate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.VEHICLE: {
			Vehicle vehicle = (Vehicle) theEObject;
			T result = caseVehicle(vehicle);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.ALERT: {
			Alert alert = (Alert) theEObject;
			T result = caseAlert(alert);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.TRIP_DESCRIPTOR: {
			TripDescriptor tripDescriptor = (TripDescriptor) theEObject;
			T result = caseTripDescriptor(tripDescriptor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.VEHICLE_DESCRIPTOR: {
			VehicleDescriptor vehicleDescriptor = (VehicleDescriptor) theEObject;
			T result = caseVehicleDescriptor(vehicleDescriptor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.STOP_TIME_UPDATE: {
			StopTimeUpdate stopTimeUpdate = (StopTimeUpdate) theEObject;
			T result = caseStopTimeUpdate(stopTimeUpdate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.STOP_TIME_EVENT: {
			StopTimeEvent stopTimeEvent = (StopTimeEvent) theEObject;
			T result = caseStopTimeEvent(stopTimeEvent);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.TIME_RANGE: {
			TimeRange timeRange = (TimeRange) theEObject;
			T result = caseTimeRange(timeRange);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.ENTITY_SELECTOR: {
			EntitySelector entitySelector = (EntitySelector) theEObject;
			T result = caseEntitySelector(entitySelector);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MapNotesPackage.POSITION: {
			Position position = (Position) theEObject;
			T result = casePosition(position);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Map Notes</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Map Notes</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMapNotes(MapNotes object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Traffic Remark</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Traffic Remark</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTrafficRemark(TrafficRemark object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Status Remark</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Status Remark</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStatusRemark(StatusRemark object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bike Sharing Remark</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bike Sharing Remark</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBikeSharingRemark(BikeSharingRemark object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Parking Remark</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Parking Remark</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseParkingRemark(ParkingRemark object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transit Remark</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transit Remark</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransitRemark(TransitRemark object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Trip Update</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Trip Update</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTripUpdate(TripUpdate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vehicle</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vehicle</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVehicle(Vehicle object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Alert</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Alert</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAlert(Alert object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Trip Descriptor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Trip Descriptor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTripDescriptor(TripDescriptor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vehicle Descriptor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vehicle Descriptor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVehicleDescriptor(VehicleDescriptor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Stop Time Update</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Stop Time Update</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStopTimeUpdate(StopTimeUpdate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Stop Time Event</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Stop Time Event</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStopTimeEvent(StopTimeEvent object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Time Range</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Time Range</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTimeRange(TimeRange object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Entity Selector</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Entity Selector</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEntitySelector(EntitySelector object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Position</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Position</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePosition(Position object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //MapNotesSwitch
