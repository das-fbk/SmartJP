/**
 */
package mapNotes;

import java.util.Date;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Map Notes</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.MapNotes#getCityName <em>City Name</em>}</li>
 *   <li>{@link mapNotes.MapNotes#getLastUpdate <em>Last Update</em>}</li>
 *   <li>{@link mapNotes.MapNotes#getStatusRemarks <em>Status Remarks</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getMapNotes()
 * @model
 * @generated
 */
public interface MapNotes extends EObject {
	/**
	 * Returns the value of the '<em><b>City Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>City Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>City Name</em>' attribute.
	 * @see #setCityName(String)
	 * @see mapNotes.MapNotesPackage#getMapNotes_CityName()
	 * @model
	 * @generated
	 */
	String getCityName();

	/**
	 * Sets the value of the '{@link mapNotes.MapNotes#getCityName <em>City Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>City Name</em>' attribute.
	 * @see #getCityName()
	 * @generated
	 */
	void setCityName(String value);

	/**
	 * Returns the value of the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Last Update</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Update</em>' attribute.
	 * @see #setLastUpdate(Date)
	 * @see mapNotes.MapNotesPackage#getMapNotes_LastUpdate()
	 * @model
	 * @generated
	 */
	Date getLastUpdate();

	/**
	 * Sets the value of the '{@link mapNotes.MapNotes#getLastUpdate <em>Last Update</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Update</em>' attribute.
	 * @see #getLastUpdate()
	 * @generated
	 */
	void setLastUpdate(Date value);

	/**
	 * Returns the value of the '<em><b>Status Remarks</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.StatusRemark}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Status Remarks</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status Remarks</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getMapNotes_StatusRemarks()
	 * @model containment="true"
	 * @generated
	 */
	EList<StatusRemark> getStatusRemarks();

} // MapNotes
