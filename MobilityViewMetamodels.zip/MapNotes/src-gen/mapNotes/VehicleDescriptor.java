/**
 */
package mapNotes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle Descriptor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.VehicleDescriptor#getId <em>Id</em>}</li>
 *   <li>{@link mapNotes.VehicleDescriptor#getLabel <em>Label</em>}</li>
 *   <li>{@link mapNotes.VehicleDescriptor#getLicense_plate <em>License plate</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getVehicleDescriptor()
 * @model
 * @generated
 */
public interface VehicleDescriptor extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see mapNotes.MapNotesPackage#getVehicleDescriptor_Id()
	 * @model
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link mapNotes.VehicleDescriptor#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see mapNotes.MapNotesPackage#getVehicleDescriptor_Label()
	 * @model
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link mapNotes.VehicleDescriptor#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>License plate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>License plate</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>License plate</em>' attribute.
	 * @see #setLicense_plate(String)
	 * @see mapNotes.MapNotesPackage#getVehicleDescriptor_License_plate()
	 * @model
	 * @generated
	 */
	String getLicense_plate();

	/**
	 * Sets the value of the '{@link mapNotes.VehicleDescriptor#getLicense_plate <em>License plate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>License plate</em>' attribute.
	 * @see #getLicense_plate()
	 * @generated
	 */
	void setLicense_plate(String value);

} // VehicleDescriptor
