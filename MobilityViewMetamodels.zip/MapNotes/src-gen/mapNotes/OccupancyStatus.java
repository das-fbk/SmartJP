/**
 */
package mapNotes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Occupancy Status</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage#getOccupancyStatus()
 * @model
 * @generated
 */
public enum OccupancyStatus implements Enumerator {
	/**
	 * The '<em><b>EMPTY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EMPTY_VALUE
	 * @generated
	 * @ordered
	 */
	EMPTY(0, "EMPTY", "EMPTY"),

	/**
	 * The '<em><b>MANY SEATS AVAILABLE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MANY_SEATS_AVAILABLE_VALUE
	 * @generated
	 * @ordered
	 */
	MANY_SEATS_AVAILABLE(1, "MANY_SEATS_AVAILABLE", "MANY_SEATS_AVAILABLE"),

	/**
	 * The '<em><b>FEW SEATS AVAILABLE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FEW_SEATS_AVAILABLE_VALUE
	 * @generated
	 * @ordered
	 */
	FEW_SEATS_AVAILABLE(2, "FEW_SEATS_AVAILABLE", "FEW_SEATS_AVAILABLE"),

	/**
	 * The '<em><b>STANDING ROOM ONLY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STANDING_ROOM_ONLY_VALUE
	 * @generated
	 * @ordered
	 */
	STANDING_ROOM_ONLY(3, "STANDING_ROOM_ONLY", "STANDING_ROOM_ONLY"),

	/**
	 * The '<em><b>CRUSHED STANDING ROOM ONLY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CRUSHED_STANDING_ROOM_ONLY_VALUE
	 * @generated
	 * @ordered
	 */
	CRUSHED_STANDING_ROOM_ONLY(4, "CRUSHED_STANDING_ROOM_ONLY", "CRUSHED_STANDING_ROOM_ONLY"),

	/**
	 * The '<em><b>FULL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FULL_VALUE
	 * @generated
	 * @ordered
	 */
	FULL(5, "FULL", "FULL"),

	/**
	 * The '<em><b>NOT ACCEPTING PASSENGERS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NOT_ACCEPTING_PASSENGERS_VALUE
	 * @generated
	 * @ordered
	 */
	NOT_ACCEPTING_PASSENGERS(6, "NOT_ACCEPTING_PASSENGERS", "NOT_ACCEPTING_PASSENGERS");

	/**
	 * The '<em><b>EMPTY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>EMPTY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EMPTY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int EMPTY_VALUE = 0;

	/**
	 * The '<em><b>MANY SEATS AVAILABLE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MANY SEATS AVAILABLE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MANY_SEATS_AVAILABLE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int MANY_SEATS_AVAILABLE_VALUE = 1;

	/**
	 * The '<em><b>FEW SEATS AVAILABLE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>FEW SEATS AVAILABLE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FEW_SEATS_AVAILABLE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int FEW_SEATS_AVAILABLE_VALUE = 2;

	/**
	 * The '<em><b>STANDING ROOM ONLY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>STANDING ROOM ONLY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STANDING_ROOM_ONLY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int STANDING_ROOM_ONLY_VALUE = 3;

	/**
	 * The '<em><b>CRUSHED STANDING ROOM ONLY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CRUSHED STANDING ROOM ONLY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CRUSHED_STANDING_ROOM_ONLY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CRUSHED_STANDING_ROOM_ONLY_VALUE = 4;

	/**
	 * The '<em><b>FULL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>FULL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FULL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int FULL_VALUE = 5;

	/**
	 * The '<em><b>NOT ACCEPTING PASSENGERS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NOT ACCEPTING PASSENGERS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NOT_ACCEPTING_PASSENGERS
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int NOT_ACCEPTING_PASSENGERS_VALUE = 6;

	/**
	 * An array of all the '<em><b>Occupancy Status</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final OccupancyStatus[] VALUES_ARRAY = new OccupancyStatus[] { EMPTY, MANY_SEATS_AVAILABLE,
			FEW_SEATS_AVAILABLE, STANDING_ROOM_ONLY, CRUSHED_STANDING_ROOM_ONLY, FULL, NOT_ACCEPTING_PASSENGERS, };

	/**
	 * A public read-only list of all the '<em><b>Occupancy Status</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<OccupancyStatus> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Occupancy Status</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static OccupancyStatus get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			OccupancyStatus result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Occupancy Status</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static OccupancyStatus getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			OccupancyStatus result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Occupancy Status</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static OccupancyStatus get(int value) {
		switch (value) {
		case EMPTY_VALUE:
			return EMPTY;
		case MANY_SEATS_AVAILABLE_VALUE:
			return MANY_SEATS_AVAILABLE;
		case FEW_SEATS_AVAILABLE_VALUE:
			return FEW_SEATS_AVAILABLE;
		case STANDING_ROOM_ONLY_VALUE:
			return STANDING_ROOM_ONLY;
		case CRUSHED_STANDING_ROOM_ONLY_VALUE:
			return CRUSHED_STANDING_ROOM_ONLY;
		case FULL_VALUE:
			return FULL;
		case NOT_ACCEPTING_PASSENGERS_VALUE:
			return NOT_ACCEPTING_PASSENGERS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private OccupancyStatus(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //OccupancyStatus
