/**
 */
package mapNotes;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transit Remark</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.TransitRemark#getId <em>Id</em>}</li>
 *   <li>{@link mapNotes.TransitRemark#isIsDeleted <em>Is Deleted</em>}</li>
 *   <li>{@link mapNotes.TransitRemark#getTripupdates <em>Tripupdates</em>}</li>
 *   <li>{@link mapNotes.TransitRemark#getVehicles <em>Vehicles</em>}</li>
 *   <li>{@link mapNotes.TransitRemark#getAlerts <em>Alerts</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getTransitRemark()
 * @model
 * @generated
 */
public interface TransitRemark extends StatusRemark {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see mapNotes.MapNotesPackage#getTransitRemark_Id()
	 * @model
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link mapNotes.TransitRemark#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Is Deleted</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Deleted</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Deleted</em>' attribute.
	 * @see #setIsDeleted(boolean)
	 * @see mapNotes.MapNotesPackage#getTransitRemark_IsDeleted()
	 * @model
	 * @generated
	 */
	boolean isIsDeleted();

	/**
	 * Sets the value of the '{@link mapNotes.TransitRemark#isIsDeleted <em>Is Deleted</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Deleted</em>' attribute.
	 * @see #isIsDeleted()
	 * @generated
	 */
	void setIsDeleted(boolean value);

	/**
	 * Returns the value of the '<em><b>Tripupdates</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.TripUpdate}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tripupdates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tripupdates</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getTransitRemark_Tripupdates()
	 * @model containment="true"
	 * @generated
	 */
	EList<TripUpdate> getTripupdates();

	/**
	 * Returns the value of the '<em><b>Vehicles</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.Vehicle}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vehicles</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicles</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getTransitRemark_Vehicles()
	 * @model containment="true"
	 * @generated
	 */
	EList<Vehicle> getVehicles();

	/**
	 * Returns the value of the '<em><b>Alerts</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.Alert}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Alerts</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alerts</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getTransitRemark_Alerts()
	 * @model containment="true"
	 * @generated
	 */
	EList<Alert> getAlerts();

} // TransitRemark
