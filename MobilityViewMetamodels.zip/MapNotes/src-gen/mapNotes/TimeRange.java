/**
 */
package mapNotes;

import java.math.BigInteger;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Time Range</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.TimeRange#getStart <em>Start</em>}</li>
 *   <li>{@link mapNotes.TimeRange#getEnd <em>End</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getTimeRange()
 * @model
 * @generated
 */
public interface TimeRange extends EObject {
	/**
	 * Returns the value of the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start</em>' attribute.
	 * @see #setStart(BigInteger)
	 * @see mapNotes.MapNotesPackage#getTimeRange_Start()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getStart();

	/**
	 * Sets the value of the '{@link mapNotes.TimeRange#getStart <em>Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start</em>' attribute.
	 * @see #getStart()
	 * @generated
	 */
	void setStart(BigInteger value);

	/**
	 * Returns the value of the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End</em>' attribute.
	 * @see #setEnd(BigInteger)
	 * @see mapNotes.MapNotesPackage#getTimeRange_End()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getEnd();

	/**
	 * Sets the value of the '{@link mapNotes.TimeRange#getEnd <em>End</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End</em>' attribute.
	 * @see #getEnd()
	 * @generated
	 */
	void setEnd(BigInteger value);

} // TimeRange
