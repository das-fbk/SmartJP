/**
 */
package mapNotes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Congestion Level</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage#getCongestionLevel()
 * @model
 * @generated
 */
public enum CongestionLevel implements Enumerator {
	/**
	 * The '<em><b>UNKNOWN CONGESTION LEVEL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_CONGESTION_LEVEL_VALUE
	 * @generated
	 * @ordered
	 */
	UNKNOWN_CONGESTION_LEVEL(0, "UNKNOWN_CONGESTION_LEVEL", "UNKNOWN_CONGESTION_LEVEL"),

	/**
	 * The '<em><b>RUNNING SMOOTHLY</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RUNNING_SMOOTHLY_VALUE
	 * @generated
	 * @ordered
	 */
	RUNNING_SMOOTHLY(1, "RUNNING_SMOOTHLY", "RUNNING_SMOOTHLY"),

	/**
	 * The '<em><b>STOP AND GO</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STOP_AND_GO_VALUE
	 * @generated
	 * @ordered
	 */
	STOP_AND_GO(2, "STOP_AND_GO", "STOP_AND_GO"),

	/**
	 * The '<em><b>CONGESTION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONGESTION_VALUE
	 * @generated
	 * @ordered
	 */
	CONGESTION(3, "CONGESTION", "CONGESTION"),

	/**
	 * The '<em><b>SEVERE CONGESTION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SEVERE_CONGESTION_VALUE
	 * @generated
	 * @ordered
	 */
	SEVERE_CONGESTION(4, "SEVERE_CONGESTION", "SEVERE_CONGESTION");

	/**
	 * The '<em><b>UNKNOWN CONGESTION LEVEL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNKNOWN CONGESTION LEVEL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_CONGESTION_LEVEL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int UNKNOWN_CONGESTION_LEVEL_VALUE = 0;

	/**
	 * The '<em><b>RUNNING SMOOTHLY</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RUNNING SMOOTHLY</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RUNNING_SMOOTHLY
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int RUNNING_SMOOTHLY_VALUE = 1;

	/**
	 * The '<em><b>STOP AND GO</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>STOP AND GO</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STOP_AND_GO
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int STOP_AND_GO_VALUE = 2;

	/**
	 * The '<em><b>CONGESTION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CONGESTION</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONGESTION
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CONGESTION_VALUE = 3;

	/**
	 * The '<em><b>SEVERE CONGESTION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SEVERE CONGESTION</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SEVERE_CONGESTION
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SEVERE_CONGESTION_VALUE = 4;

	/**
	 * An array of all the '<em><b>Congestion Level</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final CongestionLevel[] VALUES_ARRAY = new CongestionLevel[] { UNKNOWN_CONGESTION_LEVEL,
			RUNNING_SMOOTHLY, STOP_AND_GO, CONGESTION, SEVERE_CONGESTION, };

	/**
	 * A public read-only list of all the '<em><b>Congestion Level</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<CongestionLevel> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Congestion Level</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CongestionLevel get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CongestionLevel result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Congestion Level</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CongestionLevel getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CongestionLevel result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Congestion Level</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CongestionLevel get(int value) {
		switch (value) {
		case UNKNOWN_CONGESTION_LEVEL_VALUE:
			return UNKNOWN_CONGESTION_LEVEL;
		case RUNNING_SMOOTHLY_VALUE:
			return RUNNING_SMOOTHLY;
		case STOP_AND_GO_VALUE:
			return STOP_AND_GO;
		case CONGESTION_VALUE:
			return CONGESTION;
		case SEVERE_CONGESTION_VALUE:
			return SEVERE_CONGESTION;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private CongestionLevel(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //CongestionLevel
