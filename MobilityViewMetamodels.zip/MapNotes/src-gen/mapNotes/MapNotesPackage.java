/**
 */
package mapNotes;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesFactory
 * @model kind="package"
 * @generated
 */
public interface MapNotesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mapNotes";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mapNotes";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mapNotes";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MapNotesPackage eINSTANCE = mapNotes.impl.MapNotesPackageImpl.init();

	/**
	 * The meta object id for the '{@link mapNotes.impl.MapNotesImpl <em>Map Notes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.MapNotesImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getMapNotes()
	 * @generated
	 */
	int MAP_NOTES = 0;

	/**
	 * The feature id for the '<em><b>City Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAP_NOTES__CITY_NAME = 0;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAP_NOTES__LAST_UPDATE = 1;

	/**
	 * The feature id for the '<em><b>Status Remarks</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAP_NOTES__STATUS_REMARKS = 2;

	/**
	 * The number of structural features of the '<em>Map Notes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAP_NOTES_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Map Notes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAP_NOTES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mapNotes.impl.TrafficRemarkImpl <em>Traffic Remark</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.TrafficRemarkImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getTrafficRemark()
	 * @generated
	 */
	int TRAFFIC_REMARK = 1;

	/**
	 * The meta object id for the '{@link mapNotes.impl.BikeSharingRemarkImpl <em>Bike Sharing Remark</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.BikeSharingRemarkImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getBikeSharingRemark()
	 * @generated
	 */
	int BIKE_SHARING_REMARK = 3;

	/**
	 * The meta object id for the '{@link mapNotes.impl.ParkingRemarkImpl <em>Parking Remark</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.ParkingRemarkImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getParkingRemark()
	 * @generated
	 */
	int PARKING_REMARK = 4;

	/**
	 * The meta object id for the '{@link mapNotes.impl.TransitRemarkImpl <em>Transit Remark</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.TransitRemarkImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getTransitRemark()
	 * @generated
	 */
	int TRANSIT_REMARK = 5;

	/**
	 * The meta object id for the '{@link mapNotes.impl.TripUpdateImpl <em>Trip Update</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.TripUpdateImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getTripUpdate()
	 * @generated
	 */
	int TRIP_UPDATE = 6;

	/**
	 * The meta object id for the '{@link mapNotes.impl.VehicleImpl <em>Vehicle</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.VehicleImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getVehicle()
	 * @generated
	 */
	int VEHICLE = 7;

	/**
	 * The meta object id for the '{@link mapNotes.impl.AlertImpl <em>Alert</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.AlertImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getAlert()
	 * @generated
	 */
	int ALERT = 8;

	/**
	 * The meta object id for the '{@link mapNotes.impl.TripDescriptorImpl <em>Trip Descriptor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.TripDescriptorImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getTripDescriptor()
	 * @generated
	 */
	int TRIP_DESCRIPTOR = 9;

	/**
	 * The meta object id for the '{@link mapNotes.impl.VehicleDescriptorImpl <em>Vehicle Descriptor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.VehicleDescriptorImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getVehicleDescriptor()
	 * @generated
	 */
	int VEHICLE_DESCRIPTOR = 10;

	/**
	 * The meta object id for the '{@link mapNotes.impl.StopTimeUpdateImpl <em>Stop Time Update</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.StopTimeUpdateImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeUpdate()
	 * @generated
	 */
	int STOP_TIME_UPDATE = 11;

	/**
	 * The meta object id for the '{@link mapNotes.impl.StopTimeEventImpl <em>Stop Time Event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.StopTimeEventImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeEvent()
	 * @generated
	 */
	int STOP_TIME_EVENT = 12;

	/**
	 * The meta object id for the '{@link mapNotes.impl.TimeRangeImpl <em>Time Range</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.TimeRangeImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getTimeRange()
	 * @generated
	 */
	int TIME_RANGE = 13;

	/**
	 * The meta object id for the '{@link mapNotes.impl.EntitySelectorImpl <em>Entity Selector</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.EntitySelectorImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getEntitySelector()
	 * @generated
	 */
	int ENTITY_SELECTOR = 14;

	/**
	 * The meta object id for the '{@link mapNotes.impl.PositionImpl <em>Position</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.PositionImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getPosition()
	 * @generated
	 */
	int POSITION = 15;

	/**
	 * The meta object id for the '{@link mapNotes.StopTimeScheduleRelationship <em>Stop Time Schedule Relationship</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.StopTimeScheduleRelationship
	 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeScheduleRelationship()
	 * @generated
	 */
	int STOP_TIME_SCHEDULE_RELATIONSHIP = 16;

	/**
	 * The meta object id for the '{@link mapNotes.VehicleStopStatus <em>Vehicle Stop Status</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.VehicleStopStatus
	 * @see mapNotes.impl.MapNotesPackageImpl#getVehicleStopStatus()
	 * @generated
	 */
	int VEHICLE_STOP_STATUS = 17;

	/**
	 * The meta object id for the '{@link mapNotes.CongestionLevel <em>Congestion Level</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.CongestionLevel
	 * @see mapNotes.impl.MapNotesPackageImpl#getCongestionLevel()
	 * @generated
	 */
	int CONGESTION_LEVEL = 18;

	/**
	 * The meta object id for the '{@link mapNotes.OccupancyStatus <em>Occupancy Status</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.OccupancyStatus
	 * @see mapNotes.impl.MapNotesPackageImpl#getOccupancyStatus()
	 * @generated
	 */
	int OCCUPANCY_STATUS = 19;

	/**
	 * The meta object id for the '{@link mapNotes.Cause <em>Cause</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.Cause
	 * @see mapNotes.impl.MapNotesPackageImpl#getCause()
	 * @generated
	 */
	int CAUSE = 20;

	/**
	 * The meta object id for the '{@link mapNotes.Effect <em>Effect</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.Effect
	 * @see mapNotes.impl.MapNotesPackageImpl#getEffect()
	 * @generated
	 */
	int EFFECT = 21;

	/**
	 * The meta object id for the '{@link mapNotes.TripTimeScheduleRelationship <em>Trip Time Schedule Relationship</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.TripTimeScheduleRelationship
	 * @see mapNotes.impl.MapNotesPackageImpl#getTripTimeScheduleRelationship()
	 * @generated
	 */
	int TRIP_TIME_SCHEDULE_RELATIONSHIP = 22;

	/**
	 * The meta object id for the '{@link mapNotes.impl.StatusRemarkImpl <em>Status Remark</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mapNotes.impl.StatusRemarkImpl
	 * @see mapNotes.impl.MapNotesPackageImpl#getStatusRemark()
	 * @generated
	 */
	int STATUS_REMARK = 2;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS_REMARK__TIMESTAMP = 0;

	/**
	 * The number of structural features of the '<em>Status Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS_REMARK_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Status Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATUS_REMARK_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__TIMESTAMP = STATUS_REMARK__TIMESTAMP;

	/**
	 * The feature id for the '<em><b>Way Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__WAY_ID = STATUS_REMARK_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Start Node Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__START_NODE_ID = STATUS_REMARK_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>End Node Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__END_NODE_ID = STATUS_REMARK_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Lon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__LON = STATUS_REMARK_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Lat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__LAT = STATUS_REMARK_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>When</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__WHEN = STATUS_REMARK_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Applies To</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__APPLIES_TO = STATUS_REMARK_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Next Point</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__NEXT_POINT = STATUS_REMARK_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__NAME = STATUS_REMARK_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Average Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK__AVERAGE_SPEED = STATUS_REMARK_FEATURE_COUNT + 9;

	/**
	 * The number of structural features of the '<em>Traffic Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK_FEATURE_COUNT = STATUS_REMARK_FEATURE_COUNT + 10;

	/**
	 * The number of operations of the '<em>Traffic Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAFFIC_REMARK_OPERATION_COUNT = STATUS_REMARK_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_REMARK__TIMESTAMP = STATUS_REMARK__TIMESTAMP;

	/**
	 * The feature id for the '<em><b>Bikesharingstatus</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_REMARK__BIKESHARINGSTATUS = STATUS_REMARK_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Bike Sharing Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_REMARK_FEATURE_COUNT = STATUS_REMARK_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Bike Sharing Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_REMARK_OPERATION_COUNT = STATUS_REMARK_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_REMARK__TIMESTAMP = STATUS_REMARK__TIMESTAMP;

	/**
	 * The feature id for the '<em><b>Parkingstatus</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_REMARK__PARKINGSTATUS = STATUS_REMARK_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Parking Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_REMARK_FEATURE_COUNT = STATUS_REMARK_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Parking Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_REMARK_OPERATION_COUNT = STATUS_REMARK_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__TIMESTAMP = STATUS_REMARK__TIMESTAMP;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__ID = STATUS_REMARK_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Deleted</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__IS_DELETED = STATUS_REMARK_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Tripupdates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__TRIPUPDATES = STATUS_REMARK_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Vehicles</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__VEHICLES = STATUS_REMARK_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Alerts</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK__ALERTS = STATUS_REMARK_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Transit Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK_FEATURE_COUNT = STATUS_REMARK_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Transit Remark</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_REMARK_OPERATION_COUNT = STATUS_REMARK_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE__TIMESTAMP = 0;

	/**
	 * The feature id for the '<em><b>Delay</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE__DELAY = 1;

	/**
	 * The feature id for the '<em><b>Tripdescriptor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE__TRIPDESCRIPTOR = 2;

	/**
	 * The feature id for the '<em><b>Vehicledescriptor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE__VEHICLEDESCRIPTOR = 3;

	/**
	 * The feature id for the '<em><b>Stop time updates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE__STOP_TIME_UPDATES = 4;

	/**
	 * The number of structural features of the '<em>Trip Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Trip Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_UPDATE_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Vehicledescriptor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__VEHICLEDESCRIPTOR = 0;

	/**
	 * The feature id for the '<em><b>Tripdescriptor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__TRIPDESCRIPTOR = 1;

	/**
	 * The feature id for the '<em><b>Current stop sequence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__CURRENT_STOP_SEQUENCE = 2;

	/**
	 * The feature id for the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__STOP_ID = 3;

	/**
	 * The feature id for the '<em><b>Current status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__CURRENT_STATUS = 4;

	/**
	 * The feature id for the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__TIMESTAMP = 5;

	/**
	 * The feature id for the '<em><b>Congestion level</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__CONGESTION_LEVEL = 6;

	/**
	 * The feature id for the '<em><b>Occupancy Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__OCCUPANCY_STATUS = 7;

	/**
	 * The feature id for the '<em><b>Position</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE__POSITION = 8;

	/**
	 * The number of structural features of the '<em>Vehicle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Vehicle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Active period</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__ACTIVE_PERIOD = 0;

	/**
	 * The feature id for the '<em><b>Informed entity</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__INFORMED_ENTITY = 1;

	/**
	 * The feature id for the '<em><b>Cause</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__CAUSE = 2;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__EFFECT = 3;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__URL = 4;

	/**
	 * The feature id for the '<em><b>Header text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__HEADER_TEXT = 5;

	/**
	 * The feature id for the '<em><b>Description text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT__DESCRIPTION_TEXT = 6;

	/**
	 * The number of structural features of the '<em>Alert</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Alert</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALERT_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Trip id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__TRIP_ID = 0;

	/**
	 * The feature id for the '<em><b>Route id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__ROUTE_ID = 1;

	/**
	 * The feature id for the '<em><b>Direction id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__DIRECTION_ID = 2;

	/**
	 * The feature id for the '<em><b>Start time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__START_TIME = 3;

	/**
	 * The feature id for the '<em><b>Start date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__START_DATE = 4;

	/**
	 * The feature id for the '<em><b>Schedule relationship</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP = 5;

	/**
	 * The number of structural features of the '<em>Trip Descriptor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Trip Descriptor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_DESCRIPTOR_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_DESCRIPTOR__ID = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_DESCRIPTOR__LABEL = 1;

	/**
	 * The feature id for the '<em><b>License plate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_DESCRIPTOR__LICENSE_PLATE = 2;

	/**
	 * The number of structural features of the '<em>Vehicle Descriptor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_DESCRIPTOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Vehicle Descriptor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_DESCRIPTOR_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Stop sequence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__STOP_SEQUENCE = 0;

	/**
	 * The feature id for the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__STOP_ID = 1;

	/**
	 * The feature id for the '<em><b>Arrival</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__ARRIVAL = 2;

	/**
	 * The feature id for the '<em><b>Departure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__DEPARTURE = 3;

	/**
	 * The feature id for the '<em><b>Schedule relationship</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP = 4;

	/**
	 * The feature id for the '<em><b>Stoptimeevent</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE__STOPTIMEEVENT = 5;

	/**
	 * The number of structural features of the '<em>Stop Time Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Stop Time Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_UPDATE_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Delay</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_EVENT__DELAY = 0;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_EVENT__TIME = 1;

	/**
	 * The feature id for the '<em><b>Uncertainty</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_EVENT__UNCERTAINTY = 2;

	/**
	 * The number of structural features of the '<em>Stop Time Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_EVENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Stop Time Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_EVENT_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_RANGE__START = 0;

	/**
	 * The feature id for the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_RANGE__END = 1;

	/**
	 * The number of structural features of the '<em>Time Range</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_RANGE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Time Range</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_RANGE_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Agency id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR__AGENCY_ID = 0;

	/**
	 * The feature id for the '<em><b>Route id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR__ROUTE_ID = 1;

	/**
	 * The feature id for the '<em><b>Route type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR__ROUTE_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Trip</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR__TRIP = 3;

	/**
	 * The feature id for the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR__STOP_ID = 4;

	/**
	 * The number of structural features of the '<em>Entity Selector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Entity Selector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_SELECTOR_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Latitude</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__LATITUDE = 0;

	/**
	 * The feature id for the '<em><b>Longitude</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__LONGITUDE = 1;

	/**
	 * The feature id for the '<em><b>Bearing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__BEARING = 2;

	/**
	 * The feature id for the '<em><b>Odometer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__ODOMETER = 3;

	/**
	 * The feature id for the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION__SPEED = 4;

	/**
	 * The number of structural features of the '<em>Position</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Position</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POSITION_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link mapNotes.MapNotes <em>Map Notes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Map Notes</em>'.
	 * @see mapNotes.MapNotes
	 * @generated
	 */
	EClass getMapNotes();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.MapNotes#getCityName <em>City Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>City Name</em>'.
	 * @see mapNotes.MapNotes#getCityName()
	 * @see #getMapNotes()
	 * @generated
	 */
	EAttribute getMapNotes_CityName();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.MapNotes#getLastUpdate <em>Last Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Update</em>'.
	 * @see mapNotes.MapNotes#getLastUpdate()
	 * @see #getMapNotes()
	 * @generated
	 */
	EAttribute getMapNotes_LastUpdate();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.MapNotes#getStatusRemarks <em>Status Remarks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Status Remarks</em>'.
	 * @see mapNotes.MapNotes#getStatusRemarks()
	 * @see #getMapNotes()
	 * @generated
	 */
	EReference getMapNotes_StatusRemarks();

	/**
	 * Returns the meta object for class '{@link mapNotes.TrafficRemark <em>Traffic Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Traffic Remark</em>'.
	 * @see mapNotes.TrafficRemark
	 * @generated
	 */
	EClass getTrafficRemark();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getWayId <em>Way Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Way Id</em>'.
	 * @see mapNotes.TrafficRemark#getWayId()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_WayId();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getStartNodeId <em>Start Node Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start Node Id</em>'.
	 * @see mapNotes.TrafficRemark#getStartNodeId()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_StartNodeId();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getEndNodeId <em>End Node Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End Node Id</em>'.
	 * @see mapNotes.TrafficRemark#getEndNodeId()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_EndNodeId();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getLon <em>Lon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lon</em>'.
	 * @see mapNotes.TrafficRemark#getLon()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_Lon();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getLat <em>Lat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lat</em>'.
	 * @see mapNotes.TrafficRemark#getLat()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_Lat();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getWhen <em>When</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>When</em>'.
	 * @see mapNotes.TrafficRemark#getWhen()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_When();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getAppliesTo <em>Applies To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Applies To</em>'.
	 * @see mapNotes.TrafficRemark#getAppliesTo()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_AppliesTo();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.TrafficRemark#getNextPoint <em>Next Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Next Point</em>'.
	 * @see mapNotes.TrafficRemark#getNextPoint()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EReference getTrafficRemark_NextPoint();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mapNotes.TrafficRemark#getName()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_Name();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TrafficRemark#getAverageSpeed <em>Average Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Average Speed</em>'.
	 * @see mapNotes.TrafficRemark#getAverageSpeed()
	 * @see #getTrafficRemark()
	 * @generated
	 */
	EAttribute getTrafficRemark_AverageSpeed();

	/**
	 * Returns the meta object for class '{@link mapNotes.StatusRemark <em>Status Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Status Remark</em>'.
	 * @see mapNotes.StatusRemark
	 * @generated
	 */
	EClass getStatusRemark();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.StatusRemark#getTimestamp <em>Timestamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timestamp</em>'.
	 * @see mapNotes.StatusRemark#getTimestamp()
	 * @see #getStatusRemark()
	 * @generated
	 */
	EAttribute getStatusRemark_Timestamp();

	/**
	 * Returns the meta object for class '{@link mapNotes.BikeSharingRemark <em>Bike Sharing Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bike Sharing Remark</em>'.
	 * @see mapNotes.BikeSharingRemark
	 * @generated
	 */
	EClass getBikeSharingRemark();

	/**
	 * Returns the meta object for the reference list '{@link mapNotes.BikeSharingRemark#getBikesharingstatus <em>Bikesharingstatus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Bikesharingstatus</em>'.
	 * @see mapNotes.BikeSharingRemark#getBikesharingstatus()
	 * @see #getBikeSharingRemark()
	 * @generated
	 */
	EReference getBikeSharingRemark_Bikesharingstatus();

	/**
	 * Returns the meta object for class '{@link mapNotes.ParkingRemark <em>Parking Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parking Remark</em>'.
	 * @see mapNotes.ParkingRemark
	 * @generated
	 */
	EClass getParkingRemark();

	/**
	 * Returns the meta object for the reference list '{@link mapNotes.ParkingRemark#getParkingstatus <em>Parkingstatus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Parkingstatus</em>'.
	 * @see mapNotes.ParkingRemark#getParkingstatus()
	 * @see #getParkingRemark()
	 * @generated
	 */
	EReference getParkingRemark_Parkingstatus();

	/**
	 * Returns the meta object for class '{@link mapNotes.TransitRemark <em>Transit Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transit Remark</em>'.
	 * @see mapNotes.TransitRemark
	 * @generated
	 */
	EClass getTransitRemark();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TransitRemark#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see mapNotes.TransitRemark#getId()
	 * @see #getTransitRemark()
	 * @generated
	 */
	EAttribute getTransitRemark_Id();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TransitRemark#isIsDeleted <em>Is Deleted</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Deleted</em>'.
	 * @see mapNotes.TransitRemark#isIsDeleted()
	 * @see #getTransitRemark()
	 * @generated
	 */
	EAttribute getTransitRemark_IsDeleted();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.TransitRemark#getTripupdates <em>Tripupdates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tripupdates</em>'.
	 * @see mapNotes.TransitRemark#getTripupdates()
	 * @see #getTransitRemark()
	 * @generated
	 */
	EReference getTransitRemark_Tripupdates();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.TransitRemark#getVehicles <em>Vehicles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Vehicles</em>'.
	 * @see mapNotes.TransitRemark#getVehicles()
	 * @see #getTransitRemark()
	 * @generated
	 */
	EReference getTransitRemark_Vehicles();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.TransitRemark#getAlerts <em>Alerts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Alerts</em>'.
	 * @see mapNotes.TransitRemark#getAlerts()
	 * @see #getTransitRemark()
	 * @generated
	 */
	EReference getTransitRemark_Alerts();

	/**
	 * Returns the meta object for class '{@link mapNotes.TripUpdate <em>Trip Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trip Update</em>'.
	 * @see mapNotes.TripUpdate
	 * @generated
	 */
	EClass getTripUpdate();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TripUpdate#getTimestamp <em>Timestamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timestamp</em>'.
	 * @see mapNotes.TripUpdate#getTimestamp()
	 * @see #getTripUpdate()
	 * @generated
	 */
	EAttribute getTripUpdate_Timestamp();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TripUpdate#getDelay <em>Delay</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Delay</em>'.
	 * @see mapNotes.TripUpdate#getDelay()
	 * @see #getTripUpdate()
	 * @generated
	 */
	EAttribute getTripUpdate_Delay();

	/**
	 * Returns the meta object for the containment reference '{@link mapNotes.TripUpdate#getTripdescriptor <em>Tripdescriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Tripdescriptor</em>'.
	 * @see mapNotes.TripUpdate#getTripdescriptor()
	 * @see #getTripUpdate()
	 * @generated
	 */
	EReference getTripUpdate_Tripdescriptor();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.TripUpdate#getVehicledescriptor <em>Vehicledescriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Vehicledescriptor</em>'.
	 * @see mapNotes.TripUpdate#getVehicledescriptor()
	 * @see #getTripUpdate()
	 * @generated
	 */
	EReference getTripUpdate_Vehicledescriptor();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.TripUpdate#getStop_time_updates <em>Stop time updates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Stop time updates</em>'.
	 * @see mapNotes.TripUpdate#getStop_time_updates()
	 * @see #getTripUpdate()
	 * @generated
	 */
	EReference getTripUpdate_Stop_time_updates();

	/**
	 * Returns the meta object for class '{@link mapNotes.Vehicle <em>Vehicle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vehicle</em>'.
	 * @see mapNotes.Vehicle
	 * @generated
	 */
	EClass getVehicle();

	/**
	 * Returns the meta object for the containment reference '{@link mapNotes.Vehicle#getVehicledescriptor <em>Vehicledescriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Vehicledescriptor</em>'.
	 * @see mapNotes.Vehicle#getVehicledescriptor()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Vehicledescriptor();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.Vehicle#getTripdescriptor <em>Tripdescriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Tripdescriptor</em>'.
	 * @see mapNotes.Vehicle#getTripdescriptor()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Tripdescriptor();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.Vehicle#getCurrent_stop_sequence <em>Current stop sequence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Current stop sequence</em>'.
	 * @see mapNotes.Vehicle#getCurrent_stop_sequence()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Current_stop_sequence();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.Vehicle#getStop_id <em>Stop id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop id</em>'.
	 * @see mapNotes.Vehicle#getStop_id()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Stop_id();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Vehicle#getCurrent_status <em>Current status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current status</em>'.
	 * @see mapNotes.Vehicle#getCurrent_status()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_Current_status();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Vehicle#getTimestamp <em>Timestamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timestamp</em>'.
	 * @see mapNotes.Vehicle#getTimestamp()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_Timestamp();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Vehicle#getCongestion_level <em>Congestion level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Congestion level</em>'.
	 * @see mapNotes.Vehicle#getCongestion_level()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_Congestion_level();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Vehicle#getOccupancyStatus <em>Occupancy Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Occupancy Status</em>'.
	 * @see mapNotes.Vehicle#getOccupancyStatus()
	 * @see #getVehicle()
	 * @generated
	 */
	EAttribute getVehicle_OccupancyStatus();

	/**
	 * Returns the meta object for the containment reference '{@link mapNotes.Vehicle#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Position</em>'.
	 * @see mapNotes.Vehicle#getPosition()
	 * @see #getVehicle()
	 * @generated
	 */
	EReference getVehicle_Position();

	/**
	 * Returns the meta object for class '{@link mapNotes.Alert <em>Alert</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Alert</em>'.
	 * @see mapNotes.Alert
	 * @generated
	 */
	EClass getAlert();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.Alert#getActive_period <em>Active period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Active period</em>'.
	 * @see mapNotes.Alert#getActive_period()
	 * @see #getAlert()
	 * @generated
	 */
	EReference getAlert_Active_period();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.Alert#getInformed_entity <em>Informed entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Informed entity</em>'.
	 * @see mapNotes.Alert#getInformed_entity()
	 * @see #getAlert()
	 * @generated
	 */
	EReference getAlert_Informed_entity();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Alert#getCause <em>Cause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cause</em>'.
	 * @see mapNotes.Alert#getCause()
	 * @see #getAlert()
	 * @generated
	 */
	EAttribute getAlert_Cause();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Alert#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effect</em>'.
	 * @see mapNotes.Alert#getEffect()
	 * @see #getAlert()
	 * @generated
	 */
	EAttribute getAlert_Effect();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Alert#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see mapNotes.Alert#getUrl()
	 * @see #getAlert()
	 * @generated
	 */
	EAttribute getAlert_Url();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Alert#getHeader_text <em>Header text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Header text</em>'.
	 * @see mapNotes.Alert#getHeader_text()
	 * @see #getAlert()
	 * @generated
	 */
	EAttribute getAlert_Header_text();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Alert#getDescription_text <em>Description text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description text</em>'.
	 * @see mapNotes.Alert#getDescription_text()
	 * @see #getAlert()
	 * @generated
	 */
	EAttribute getAlert_Description_text();

	/**
	 * Returns the meta object for class '{@link mapNotes.TripDescriptor <em>Trip Descriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trip Descriptor</em>'.
	 * @see mapNotes.TripDescriptor
	 * @generated
	 */
	EClass getTripDescriptor();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.TripDescriptor#getTrip_id <em>Trip id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trip id</em>'.
	 * @see mapNotes.TripDescriptor#getTrip_id()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EReference getTripDescriptor_Trip_id();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.TripDescriptor#getRoute_id <em>Route id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route id</em>'.
	 * @see mapNotes.TripDescriptor#getRoute_id()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EReference getTripDescriptor_Route_id();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.TripDescriptor#getDirection_id <em>Direction id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Direction id</em>'.
	 * @see mapNotes.TripDescriptor#getDirection_id()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EReference getTripDescriptor_Direction_id();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TripDescriptor#getStart_time <em>Start time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start time</em>'.
	 * @see mapNotes.TripDescriptor#getStart_time()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EAttribute getTripDescriptor_Start_time();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TripDescriptor#getStart_date <em>Start date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start date</em>'.
	 * @see mapNotes.TripDescriptor#getStart_date()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EAttribute getTripDescriptor_Start_date();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TripDescriptor#getSchedule_relationship <em>Schedule relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schedule relationship</em>'.
	 * @see mapNotes.TripDescriptor#getSchedule_relationship()
	 * @see #getTripDescriptor()
	 * @generated
	 */
	EAttribute getTripDescriptor_Schedule_relationship();

	/**
	 * Returns the meta object for class '{@link mapNotes.VehicleDescriptor <em>Vehicle Descriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vehicle Descriptor</em>'.
	 * @see mapNotes.VehicleDescriptor
	 * @generated
	 */
	EClass getVehicleDescriptor();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.VehicleDescriptor#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see mapNotes.VehicleDescriptor#getId()
	 * @see #getVehicleDescriptor()
	 * @generated
	 */
	EAttribute getVehicleDescriptor_Id();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.VehicleDescriptor#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see mapNotes.VehicleDescriptor#getLabel()
	 * @see #getVehicleDescriptor()
	 * @generated
	 */
	EAttribute getVehicleDescriptor_Label();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.VehicleDescriptor#getLicense_plate <em>License plate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>License plate</em>'.
	 * @see mapNotes.VehicleDescriptor#getLicense_plate()
	 * @see #getVehicleDescriptor()
	 * @generated
	 */
	EAttribute getVehicleDescriptor_License_plate();

	/**
	 * Returns the meta object for class '{@link mapNotes.StopTimeUpdate <em>Stop Time Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stop Time Update</em>'.
	 * @see mapNotes.StopTimeUpdate
	 * @generated
	 */
	EClass getStopTimeUpdate();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.StopTimeUpdate#getStop_sequence <em>Stop sequence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop sequence</em>'.
	 * @see mapNotes.StopTimeUpdate#getStop_sequence()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EReference getStopTimeUpdate_Stop_sequence();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.StopTimeUpdate#getStop_id <em>Stop id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop id</em>'.
	 * @see mapNotes.StopTimeUpdate#getStop_id()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EReference getStopTimeUpdate_Stop_id();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.StopTimeUpdate#getArrival <em>Arrival</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Arrival</em>'.
	 * @see mapNotes.StopTimeUpdate#getArrival()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EReference getStopTimeUpdate_Arrival();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.StopTimeUpdate#getDeparture <em>Departure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Departure</em>'.
	 * @see mapNotes.StopTimeUpdate#getDeparture()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EReference getStopTimeUpdate_Departure();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.StopTimeUpdate#getSchedule_relationship <em>Schedule relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schedule relationship</em>'.
	 * @see mapNotes.StopTimeUpdate#getSchedule_relationship()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EAttribute getStopTimeUpdate_Schedule_relationship();

	/**
	 * Returns the meta object for the containment reference list '{@link mapNotes.StopTimeUpdate#getStoptimeevent <em>Stoptimeevent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Stoptimeevent</em>'.
	 * @see mapNotes.StopTimeUpdate#getStoptimeevent()
	 * @see #getStopTimeUpdate()
	 * @generated
	 */
	EReference getStopTimeUpdate_Stoptimeevent();

	/**
	 * Returns the meta object for class '{@link mapNotes.StopTimeEvent <em>Stop Time Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stop Time Event</em>'.
	 * @see mapNotes.StopTimeEvent
	 * @generated
	 */
	EClass getStopTimeEvent();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.StopTimeEvent#getDelay <em>Delay</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Delay</em>'.
	 * @see mapNotes.StopTimeEvent#getDelay()
	 * @see #getStopTimeEvent()
	 * @generated
	 */
	EAttribute getStopTimeEvent_Delay();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.StopTimeEvent#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see mapNotes.StopTimeEvent#getTime()
	 * @see #getStopTimeEvent()
	 * @generated
	 */
	EAttribute getStopTimeEvent_Time();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.StopTimeEvent#getUncertainty <em>Uncertainty</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Uncertainty</em>'.
	 * @see mapNotes.StopTimeEvent#getUncertainty()
	 * @see #getStopTimeEvent()
	 * @generated
	 */
	EAttribute getStopTimeEvent_Uncertainty();

	/**
	 * Returns the meta object for class '{@link mapNotes.TimeRange <em>Time Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Time Range</em>'.
	 * @see mapNotes.TimeRange
	 * @generated
	 */
	EClass getTimeRange();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TimeRange#getStart <em>Start</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start</em>'.
	 * @see mapNotes.TimeRange#getStart()
	 * @see #getTimeRange()
	 * @generated
	 */
	EAttribute getTimeRange_Start();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.TimeRange#getEnd <em>End</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End</em>'.
	 * @see mapNotes.TimeRange#getEnd()
	 * @see #getTimeRange()
	 * @generated
	 */
	EAttribute getTimeRange_End();

	/**
	 * Returns the meta object for class '{@link mapNotes.EntitySelector <em>Entity Selector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entity Selector</em>'.
	 * @see mapNotes.EntitySelector
	 * @generated
	 */
	EClass getEntitySelector();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.EntitySelector#getAgency_id <em>Agency id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Agency id</em>'.
	 * @see mapNotes.EntitySelector#getAgency_id()
	 * @see #getEntitySelector()
	 * @generated
	 */
	EReference getEntitySelector_Agency_id();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.EntitySelector#getRoute_id <em>Route id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route id</em>'.
	 * @see mapNotes.EntitySelector#getRoute_id()
	 * @see #getEntitySelector()
	 * @generated
	 */
	EReference getEntitySelector_Route_id();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.EntitySelector#getRoute_type <em>Route type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route type</em>'.
	 * @see mapNotes.EntitySelector#getRoute_type()
	 * @see #getEntitySelector()
	 * @generated
	 */
	EReference getEntitySelector_Route_type();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.EntitySelector#getTrip <em>Trip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Trip</em>'.
	 * @see mapNotes.EntitySelector#getTrip()
	 * @see #getEntitySelector()
	 * @generated
	 */
	EReference getEntitySelector_Trip();

	/**
	 * Returns the meta object for the reference '{@link mapNotes.EntitySelector#getStop_id <em>Stop id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop id</em>'.
	 * @see mapNotes.EntitySelector#getStop_id()
	 * @see #getEntitySelector()
	 * @generated
	 */
	EReference getEntitySelector_Stop_id();

	/**
	 * Returns the meta object for class '{@link mapNotes.Position <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Position</em>'.
	 * @see mapNotes.Position
	 * @generated
	 */
	EClass getPosition();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Position#getLatitude <em>Latitude</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Latitude</em>'.
	 * @see mapNotes.Position#getLatitude()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Latitude();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Position#getLongitude <em>Longitude</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Longitude</em>'.
	 * @see mapNotes.Position#getLongitude()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Longitude();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Position#getBearing <em>Bearing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bearing</em>'.
	 * @see mapNotes.Position#getBearing()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Bearing();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Position#getOdometer <em>Odometer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Odometer</em>'.
	 * @see mapNotes.Position#getOdometer()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Odometer();

	/**
	 * Returns the meta object for the attribute '{@link mapNotes.Position#getSpeed <em>Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speed</em>'.
	 * @see mapNotes.Position#getSpeed()
	 * @see #getPosition()
	 * @generated
	 */
	EAttribute getPosition_Speed();

	/**
	 * Returns the meta object for enum '{@link mapNotes.StopTimeScheduleRelationship <em>Stop Time Schedule Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Stop Time Schedule Relationship</em>'.
	 * @see mapNotes.StopTimeScheduleRelationship
	 * @generated
	 */
	EEnum getStopTimeScheduleRelationship();

	/**
	 * Returns the meta object for enum '{@link mapNotes.VehicleStopStatus <em>Vehicle Stop Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Vehicle Stop Status</em>'.
	 * @see mapNotes.VehicleStopStatus
	 * @generated
	 */
	EEnum getVehicleStopStatus();

	/**
	 * Returns the meta object for enum '{@link mapNotes.CongestionLevel <em>Congestion Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Congestion Level</em>'.
	 * @see mapNotes.CongestionLevel
	 * @generated
	 */
	EEnum getCongestionLevel();

	/**
	 * Returns the meta object for enum '{@link mapNotes.OccupancyStatus <em>Occupancy Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Occupancy Status</em>'.
	 * @see mapNotes.OccupancyStatus
	 * @generated
	 */
	EEnum getOccupancyStatus();

	/**
	 * Returns the meta object for enum '{@link mapNotes.Cause <em>Cause</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Cause</em>'.
	 * @see mapNotes.Cause
	 * @generated
	 */
	EEnum getCause();

	/**
	 * Returns the meta object for enum '{@link mapNotes.Effect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Effect</em>'.
	 * @see mapNotes.Effect
	 * @generated
	 */
	EEnum getEffect();

	/**
	 * Returns the meta object for enum '{@link mapNotes.TripTimeScheduleRelationship <em>Trip Time Schedule Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Trip Time Schedule Relationship</em>'.
	 * @see mapNotes.TripTimeScheduleRelationship
	 * @generated
	 */
	EEnum getTripTimeScheduleRelationship();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MapNotesFactory getMapNotesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mapNotes.impl.MapNotesImpl <em>Map Notes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.MapNotesImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getMapNotes()
		 * @generated
		 */
		EClass MAP_NOTES = eINSTANCE.getMapNotes();

		/**
		 * The meta object literal for the '<em><b>City Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAP_NOTES__CITY_NAME = eINSTANCE.getMapNotes_CityName();

		/**
		 * The meta object literal for the '<em><b>Last Update</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAP_NOTES__LAST_UPDATE = eINSTANCE.getMapNotes_LastUpdate();

		/**
		 * The meta object literal for the '<em><b>Status Remarks</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAP_NOTES__STATUS_REMARKS = eINSTANCE.getMapNotes_StatusRemarks();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.TrafficRemarkImpl <em>Traffic Remark</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.TrafficRemarkImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getTrafficRemark()
		 * @generated
		 */
		EClass TRAFFIC_REMARK = eINSTANCE.getTrafficRemark();

		/**
		 * The meta object literal for the '<em><b>Way Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__WAY_ID = eINSTANCE.getTrafficRemark_WayId();

		/**
		 * The meta object literal for the '<em><b>Start Node Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__START_NODE_ID = eINSTANCE.getTrafficRemark_StartNodeId();

		/**
		 * The meta object literal for the '<em><b>End Node Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__END_NODE_ID = eINSTANCE.getTrafficRemark_EndNodeId();

		/**
		 * The meta object literal for the '<em><b>Lon</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__LON = eINSTANCE.getTrafficRemark_Lon();

		/**
		 * The meta object literal for the '<em><b>Lat</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__LAT = eINSTANCE.getTrafficRemark_Lat();

		/**
		 * The meta object literal for the '<em><b>When</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__WHEN = eINSTANCE.getTrafficRemark_When();

		/**
		 * The meta object literal for the '<em><b>Applies To</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__APPLIES_TO = eINSTANCE.getTrafficRemark_AppliesTo();

		/**
		 * The meta object literal for the '<em><b>Next Point</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAFFIC_REMARK__NEXT_POINT = eINSTANCE.getTrafficRemark_NextPoint();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__NAME = eINSTANCE.getTrafficRemark_Name();

		/**
		 * The meta object literal for the '<em><b>Average Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAFFIC_REMARK__AVERAGE_SPEED = eINSTANCE.getTrafficRemark_AverageSpeed();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.StatusRemarkImpl <em>Status Remark</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.StatusRemarkImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getStatusRemark()
		 * @generated
		 */
		EClass STATUS_REMARK = eINSTANCE.getStatusRemark();

		/**
		 * The meta object literal for the '<em><b>Timestamp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATUS_REMARK__TIMESTAMP = eINSTANCE.getStatusRemark_Timestamp();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.BikeSharingRemarkImpl <em>Bike Sharing Remark</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.BikeSharingRemarkImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getBikeSharingRemark()
		 * @generated
		 */
		EClass BIKE_SHARING_REMARK = eINSTANCE.getBikeSharingRemark();

		/**
		 * The meta object literal for the '<em><b>Bikesharingstatus</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BIKE_SHARING_REMARK__BIKESHARINGSTATUS = eINSTANCE.getBikeSharingRemark_Bikesharingstatus();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.ParkingRemarkImpl <em>Parking Remark</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.ParkingRemarkImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getParkingRemark()
		 * @generated
		 */
		EClass PARKING_REMARK = eINSTANCE.getParkingRemark();

		/**
		 * The meta object literal for the '<em><b>Parkingstatus</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARKING_REMARK__PARKINGSTATUS = eINSTANCE.getParkingRemark_Parkingstatus();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.TransitRemarkImpl <em>Transit Remark</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.TransitRemarkImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getTransitRemark()
		 * @generated
		 */
		EClass TRANSIT_REMARK = eINSTANCE.getTransitRemark();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSIT_REMARK__ID = eINSTANCE.getTransitRemark_Id();

		/**
		 * The meta object literal for the '<em><b>Is Deleted</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSIT_REMARK__IS_DELETED = eINSTANCE.getTransitRemark_IsDeleted();

		/**
		 * The meta object literal for the '<em><b>Tripupdates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSIT_REMARK__TRIPUPDATES = eINSTANCE.getTransitRemark_Tripupdates();

		/**
		 * The meta object literal for the '<em><b>Vehicles</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSIT_REMARK__VEHICLES = eINSTANCE.getTransitRemark_Vehicles();

		/**
		 * The meta object literal for the '<em><b>Alerts</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSIT_REMARK__ALERTS = eINSTANCE.getTransitRemark_Alerts();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.TripUpdateImpl <em>Trip Update</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.TripUpdateImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getTripUpdate()
		 * @generated
		 */
		EClass TRIP_UPDATE = eINSTANCE.getTripUpdate();

		/**
		 * The meta object literal for the '<em><b>Timestamp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_UPDATE__TIMESTAMP = eINSTANCE.getTripUpdate_Timestamp();

		/**
		 * The meta object literal for the '<em><b>Delay</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_UPDATE__DELAY = eINSTANCE.getTripUpdate_Delay();

		/**
		 * The meta object literal for the '<em><b>Tripdescriptor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_UPDATE__TRIPDESCRIPTOR = eINSTANCE.getTripUpdate_Tripdescriptor();

		/**
		 * The meta object literal for the '<em><b>Vehicledescriptor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_UPDATE__VEHICLEDESCRIPTOR = eINSTANCE.getTripUpdate_Vehicledescriptor();

		/**
		 * The meta object literal for the '<em><b>Stop time updates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_UPDATE__STOP_TIME_UPDATES = eINSTANCE.getTripUpdate_Stop_time_updates();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.VehicleImpl <em>Vehicle</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.VehicleImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getVehicle()
		 * @generated
		 */
		EClass VEHICLE = eINSTANCE.getVehicle();

		/**
		 * The meta object literal for the '<em><b>Vehicledescriptor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__VEHICLEDESCRIPTOR = eINSTANCE.getVehicle_Vehicledescriptor();

		/**
		 * The meta object literal for the '<em><b>Tripdescriptor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__TRIPDESCRIPTOR = eINSTANCE.getVehicle_Tripdescriptor();

		/**
		 * The meta object literal for the '<em><b>Current stop sequence</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__CURRENT_STOP_SEQUENCE = eINSTANCE.getVehicle_Current_stop_sequence();

		/**
		 * The meta object literal for the '<em><b>Stop id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__STOP_ID = eINSTANCE.getVehicle_Stop_id();

		/**
		 * The meta object literal for the '<em><b>Current status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__CURRENT_STATUS = eINSTANCE.getVehicle_Current_status();

		/**
		 * The meta object literal for the '<em><b>Timestamp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__TIMESTAMP = eINSTANCE.getVehicle_Timestamp();

		/**
		 * The meta object literal for the '<em><b>Congestion level</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__CONGESTION_LEVEL = eINSTANCE.getVehicle_Congestion_level();

		/**
		 * The meta object literal for the '<em><b>Occupancy Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE__OCCUPANCY_STATUS = eINSTANCE.getVehicle_OccupancyStatus();

		/**
		 * The meta object literal for the '<em><b>Position</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE__POSITION = eINSTANCE.getVehicle_Position();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.AlertImpl <em>Alert</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.AlertImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getAlert()
		 * @generated
		 */
		EClass ALERT = eINSTANCE.getAlert();

		/**
		 * The meta object literal for the '<em><b>Active period</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ALERT__ACTIVE_PERIOD = eINSTANCE.getAlert_Active_period();

		/**
		 * The meta object literal for the '<em><b>Informed entity</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ALERT__INFORMED_ENTITY = eINSTANCE.getAlert_Informed_entity();

		/**
		 * The meta object literal for the '<em><b>Cause</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALERT__CAUSE = eINSTANCE.getAlert_Cause();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALERT__EFFECT = eINSTANCE.getAlert_Effect();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALERT__URL = eINSTANCE.getAlert_Url();

		/**
		 * The meta object literal for the '<em><b>Header text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALERT__HEADER_TEXT = eINSTANCE.getAlert_Header_text();

		/**
		 * The meta object literal for the '<em><b>Description text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ALERT__DESCRIPTION_TEXT = eINSTANCE.getAlert_Description_text();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.TripDescriptorImpl <em>Trip Descriptor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.TripDescriptorImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getTripDescriptor()
		 * @generated
		 */
		EClass TRIP_DESCRIPTOR = eINSTANCE.getTripDescriptor();

		/**
		 * The meta object literal for the '<em><b>Trip id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_DESCRIPTOR__TRIP_ID = eINSTANCE.getTripDescriptor_Trip_id();

		/**
		 * The meta object literal for the '<em><b>Route id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_DESCRIPTOR__ROUTE_ID = eINSTANCE.getTripDescriptor_Route_id();

		/**
		 * The meta object literal for the '<em><b>Direction id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_DESCRIPTOR__DIRECTION_ID = eINSTANCE.getTripDescriptor_Direction_id();

		/**
		 * The meta object literal for the '<em><b>Start time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_DESCRIPTOR__START_TIME = eINSTANCE.getTripDescriptor_Start_time();

		/**
		 * The meta object literal for the '<em><b>Start date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_DESCRIPTOR__START_DATE = eINSTANCE.getTripDescriptor_Start_date();

		/**
		 * The meta object literal for the '<em><b>Schedule relationship</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP = eINSTANCE.getTripDescriptor_Schedule_relationship();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.VehicleDescriptorImpl <em>Vehicle Descriptor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.VehicleDescriptorImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getVehicleDescriptor()
		 * @generated
		 */
		EClass VEHICLE_DESCRIPTOR = eINSTANCE.getVehicleDescriptor();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_DESCRIPTOR__ID = eINSTANCE.getVehicleDescriptor_Id();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_DESCRIPTOR__LABEL = eINSTANCE.getVehicleDescriptor_Label();

		/**
		 * The meta object literal for the '<em><b>License plate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_DESCRIPTOR__LICENSE_PLATE = eINSTANCE.getVehicleDescriptor_License_plate();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.StopTimeUpdateImpl <em>Stop Time Update</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.StopTimeUpdateImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeUpdate()
		 * @generated
		 */
		EClass STOP_TIME_UPDATE = eINSTANCE.getStopTimeUpdate();

		/**
		 * The meta object literal for the '<em><b>Stop sequence</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME_UPDATE__STOP_SEQUENCE = eINSTANCE.getStopTimeUpdate_Stop_sequence();

		/**
		 * The meta object literal for the '<em><b>Stop id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME_UPDATE__STOP_ID = eINSTANCE.getStopTimeUpdate_Stop_id();

		/**
		 * The meta object literal for the '<em><b>Arrival</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME_UPDATE__ARRIVAL = eINSTANCE.getStopTimeUpdate_Arrival();

		/**
		 * The meta object literal for the '<em><b>Departure</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME_UPDATE__DEPARTURE = eINSTANCE.getStopTimeUpdate_Departure();

		/**
		 * The meta object literal for the '<em><b>Schedule relationship</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP = eINSTANCE.getStopTimeUpdate_Schedule_relationship();

		/**
		 * The meta object literal for the '<em><b>Stoptimeevent</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME_UPDATE__STOPTIMEEVENT = eINSTANCE.getStopTimeUpdate_Stoptimeevent();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.StopTimeEventImpl <em>Stop Time Event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.StopTimeEventImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeEvent()
		 * @generated
		 */
		EClass STOP_TIME_EVENT = eINSTANCE.getStopTimeEvent();

		/**
		 * The meta object literal for the '<em><b>Delay</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME_EVENT__DELAY = eINSTANCE.getStopTimeEvent_Delay();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME_EVENT__TIME = eINSTANCE.getStopTimeEvent_Time();

		/**
		 * The meta object literal for the '<em><b>Uncertainty</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME_EVENT__UNCERTAINTY = eINSTANCE.getStopTimeEvent_Uncertainty();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.TimeRangeImpl <em>Time Range</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.TimeRangeImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getTimeRange()
		 * @generated
		 */
		EClass TIME_RANGE = eINSTANCE.getTimeRange();

		/**
		 * The meta object literal for the '<em><b>Start</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_RANGE__START = eINSTANCE.getTimeRange_Start();

		/**
		 * The meta object literal for the '<em><b>End</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIME_RANGE__END = eINSTANCE.getTimeRange_End();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.EntitySelectorImpl <em>Entity Selector</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.EntitySelectorImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getEntitySelector()
		 * @generated
		 */
		EClass ENTITY_SELECTOR = eINSTANCE.getEntitySelector();

		/**
		 * The meta object literal for the '<em><b>Agency id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY_SELECTOR__AGENCY_ID = eINSTANCE.getEntitySelector_Agency_id();

		/**
		 * The meta object literal for the '<em><b>Route id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY_SELECTOR__ROUTE_ID = eINSTANCE.getEntitySelector_Route_id();

		/**
		 * The meta object literal for the '<em><b>Route type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY_SELECTOR__ROUTE_TYPE = eINSTANCE.getEntitySelector_Route_type();

		/**
		 * The meta object literal for the '<em><b>Trip</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY_SELECTOR__TRIP = eINSTANCE.getEntitySelector_Trip();

		/**
		 * The meta object literal for the '<em><b>Stop id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY_SELECTOR__STOP_ID = eINSTANCE.getEntitySelector_Stop_id();

		/**
		 * The meta object literal for the '{@link mapNotes.impl.PositionImpl <em>Position</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.impl.PositionImpl
		 * @see mapNotes.impl.MapNotesPackageImpl#getPosition()
		 * @generated
		 */
		EClass POSITION = eINSTANCE.getPosition();

		/**
		 * The meta object literal for the '<em><b>Latitude</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__LATITUDE = eINSTANCE.getPosition_Latitude();

		/**
		 * The meta object literal for the '<em><b>Longitude</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__LONGITUDE = eINSTANCE.getPosition_Longitude();

		/**
		 * The meta object literal for the '<em><b>Bearing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__BEARING = eINSTANCE.getPosition_Bearing();

		/**
		 * The meta object literal for the '<em><b>Odometer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__ODOMETER = eINSTANCE.getPosition_Odometer();

		/**
		 * The meta object literal for the '<em><b>Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POSITION__SPEED = eINSTANCE.getPosition_Speed();

		/**
		 * The meta object literal for the '{@link mapNotes.StopTimeScheduleRelationship <em>Stop Time Schedule Relationship</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.StopTimeScheduleRelationship
		 * @see mapNotes.impl.MapNotesPackageImpl#getStopTimeScheduleRelationship()
		 * @generated
		 */
		EEnum STOP_TIME_SCHEDULE_RELATIONSHIP = eINSTANCE.getStopTimeScheduleRelationship();

		/**
		 * The meta object literal for the '{@link mapNotes.VehicleStopStatus <em>Vehicle Stop Status</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.VehicleStopStatus
		 * @see mapNotes.impl.MapNotesPackageImpl#getVehicleStopStatus()
		 * @generated
		 */
		EEnum VEHICLE_STOP_STATUS = eINSTANCE.getVehicleStopStatus();

		/**
		 * The meta object literal for the '{@link mapNotes.CongestionLevel <em>Congestion Level</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.CongestionLevel
		 * @see mapNotes.impl.MapNotesPackageImpl#getCongestionLevel()
		 * @generated
		 */
		EEnum CONGESTION_LEVEL = eINSTANCE.getCongestionLevel();

		/**
		 * The meta object literal for the '{@link mapNotes.OccupancyStatus <em>Occupancy Status</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.OccupancyStatus
		 * @see mapNotes.impl.MapNotesPackageImpl#getOccupancyStatus()
		 * @generated
		 */
		EEnum OCCUPANCY_STATUS = eINSTANCE.getOccupancyStatus();

		/**
		 * The meta object literal for the '{@link mapNotes.Cause <em>Cause</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.Cause
		 * @see mapNotes.impl.MapNotesPackageImpl#getCause()
		 * @generated
		 */
		EEnum CAUSE = eINSTANCE.getCause();

		/**
		 * The meta object literal for the '{@link mapNotes.Effect <em>Effect</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.Effect
		 * @see mapNotes.impl.MapNotesPackageImpl#getEffect()
		 * @generated
		 */
		EEnum EFFECT = eINSTANCE.getEffect();

		/**
		 * The meta object literal for the '{@link mapNotes.TripTimeScheduleRelationship <em>Trip Time Schedule Relationship</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mapNotes.TripTimeScheduleRelationship
		 * @see mapNotes.impl.MapNotesPackageImpl#getTripTimeScheduleRelationship()
		 * @generated
		 */
		EEnum TRIP_TIME_SCHEDULE_RELATIONSHIP = eINSTANCE.getTripTimeScheduleRelationship();

	}

} //MapNotesPackage
