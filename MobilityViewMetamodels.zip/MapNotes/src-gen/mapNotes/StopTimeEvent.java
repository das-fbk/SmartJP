/**
 */
package mapNotes;

import java.math.BigInteger;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop Time Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.StopTimeEvent#getDelay <em>Delay</em>}</li>
 *   <li>{@link mapNotes.StopTimeEvent#getTime <em>Time</em>}</li>
 *   <li>{@link mapNotes.StopTimeEvent#getUncertainty <em>Uncertainty</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getStopTimeEvent()
 * @model
 * @generated
 */
public interface StopTimeEvent extends EObject {
	/**
	 * Returns the value of the '<em><b>Delay</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delay</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delay</em>' attribute.
	 * @see #setDelay(BigInteger)
	 * @see mapNotes.MapNotesPackage#getStopTimeEvent_Delay()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getDelay();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeEvent#getDelay <em>Delay</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delay</em>' attribute.
	 * @see #getDelay()
	 * @generated
	 */
	void setDelay(BigInteger value);

	/**
	 * Returns the value of the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' attribute.
	 * @see #setTime(BigInteger)
	 * @see mapNotes.MapNotesPackage#getStopTimeEvent_Time()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getTime();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeEvent#getTime <em>Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' attribute.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(BigInteger value);

	/**
	 * Returns the value of the '<em><b>Uncertainty</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Uncertainty</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Uncertainty</em>' attribute.
	 * @see #setUncertainty(BigInteger)
	 * @see mapNotes.MapNotesPackage#getStopTimeEvent_Uncertainty()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getUncertainty();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeEvent#getUncertainty <em>Uncertainty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Uncertainty</em>' attribute.
	 * @see #getUncertainty()
	 * @generated
	 */
	void setUncertainty(BigInteger value);

} // StopTimeEvent
