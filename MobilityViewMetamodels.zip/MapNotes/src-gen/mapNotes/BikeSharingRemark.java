/**
 */
package mapNotes;

import mobilityResources.BikeSharing;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bike Sharing Remark</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.BikeSharingRemark#getBikesharingstatus <em>Bikesharingstatus</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getBikeSharingRemark()
 * @model
 * @generated
 */
public interface BikeSharingRemark extends StatusRemark {
	/**
	 * Returns the value of the '<em><b>Bikesharingstatus</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.BikeSharing}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bikesharingstatus</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bikesharingstatus</em>' reference list.
	 * @see mapNotes.MapNotesPackage#getBikeSharingRemark_Bikesharingstatus()
	 * @model
	 * @generated
	 */
	EList<BikeSharing> getBikesharingstatus();

} // BikeSharingRemark
