/**
 */
package mobilityResources;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fare attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Fare_attribute#getFare_id <em>Fare id</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getPrice <em>Price</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getCurrency_type <em>Currency type</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getPayment_method <em>Payment method</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getTransfers <em>Transfers</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getTransfer_duration <em>Transfer duration</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getAgency_id <em>Agency id</em>}</li>
 *   <li>{@link mobilityResources.Fare_attribute#getFare_rules <em>Fare rules</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute()
 * @model
 * @generated
 */
public interface Fare_attribute extends EObject {
	/**
	 * Returns the value of the '<em><b>Fare id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fare id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fare id</em>' attribute.
	 * @see #setFare_id(String)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Fare_id()
	 * @model
	 * @generated
	 */
	String getFare_id();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getFare_id <em>Fare id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fare id</em>' attribute.
	 * @see #getFare_id()
	 * @generated
	 */
	void setFare_id(String value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Price</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(double)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Price()
	 * @model
	 * @generated
	 */
	double getPrice();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(double value);

	/**
	 * Returns the value of the '<em><b>Currency type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Currency type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Currency type</em>' attribute.
	 * @see #setCurrency_type(String)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Currency_type()
	 * @model
	 * @generated
	 */
	String getCurrency_type();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getCurrency_type <em>Currency type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Currency type</em>' attribute.
	 * @see #getCurrency_type()
	 * @generated
	 */
	void setCurrency_type(String value);

	/**
	 * Returns the value of the '<em><b>Payment method</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Payment_method}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Payment method</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment method</em>' attribute.
	 * @see mobilityResources.Payment_method
	 * @see #setPayment_method(Payment_method)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Payment_method()
	 * @model
	 * @generated
	 */
	Payment_method getPayment_method();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getPayment_method <em>Payment method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment method</em>' attribute.
	 * @see mobilityResources.Payment_method
	 * @see #getPayment_method()
	 * @generated
	 */
	void setPayment_method(Payment_method value);

	/**
	 * Returns the value of the '<em><b>Transfers</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Allowed_transfers}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transfers</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transfers</em>' attribute.
	 * @see mobilityResources.Allowed_transfers
	 * @see #setTransfers(Allowed_transfers)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Transfers()
	 * @model
	 * @generated
	 */
	Allowed_transfers getTransfers();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getTransfers <em>Transfers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transfers</em>' attribute.
	 * @see mobilityResources.Allowed_transfers
	 * @see #getTransfers()
	 * @generated
	 */
	void setTransfers(Allowed_transfers value);

	/**
	 * Returns the value of the '<em><b>Transfer duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transfer duration</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transfer duration</em>' attribute.
	 * @see #setTransfer_duration(int)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Transfer_duration()
	 * @model
	 * @generated
	 */
	int getTransfer_duration();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getTransfer_duration <em>Transfer duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transfer duration</em>' attribute.
	 * @see #getTransfer_duration()
	 * @generated
	 */
	void setTransfer_duration(int value);

	/**
	 * Returns the value of the '<em><b>Agency id</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Agency#getFare_attributes <em>Fare attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agency id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agency id</em>' reference.
	 * @see #setAgency_id(Agency)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Agency_id()
	 * @see mobilityResources.Agency#getFare_attributes
	 * @model opposite="fare_attributes"
	 * @generated
	 */
	Agency getAgency_id();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_attribute#getAgency_id <em>Agency id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agency id</em>' reference.
	 * @see #getAgency_id()
	 * @generated
	 */
	void setAgency_id(Agency value);

	/**
	 * Returns the value of the '<em><b>Fare rules</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Fare_rule}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_rule#getFare <em>Fare</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fare rules</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fare rules</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getFare_attribute_Fare_rules()
	 * @see mobilityResources.Fare_rule#getFare
	 * @model opposite="fare"
	 * @generated
	 */
	EList<Fare_rule> getFare_rules();

} // Fare_attribute
