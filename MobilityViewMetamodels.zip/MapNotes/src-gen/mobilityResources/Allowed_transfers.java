/**
 */
package mobilityResources;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Allowed transfers</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesPackage#getAllowed_transfers()
 * @model
 * @generated
 */
public enum Allowed_transfers implements Enumerator {
	/**
	 * The '<em><b>No transfers</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NO_TRANSFERS_VALUE
	 * @generated
	 * @ordered
	 */
	NO_TRANSFERS(0, "No_transfers", "No_transfers"),

	/**
	 * The '<em><b>Transfer once</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRANSFER_ONCE_VALUE
	 * @generated
	 * @ordered
	 */
	TRANSFER_ONCE(1, "Transfer_once", "Transfer_once"),

	/**
	 * The '<em><b>Transfer Twice</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRANSFER_TWICE_VALUE
	 * @generated
	 * @ordered
	 */
	TRANSFER_TWICE(2, "Transfer_Twice", "Transfer_Twice"),

	/**
	 * The '<em><b>Unlimited</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNLIMITED_VALUE
	 * @generated
	 * @ordered
	 */
	UNLIMITED(-1, "Unlimited", "Unlimited");

	/**
	 * The '<em><b>No transfers</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>No transfers</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NO_TRANSFERS
	 * @model name="No_transfers"
	 * @generated
	 * @ordered
	 */
	public static final int NO_TRANSFERS_VALUE = 0;

	/**
	 * The '<em><b>Transfer once</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Transfer once</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRANSFER_ONCE
	 * @model name="Transfer_once"
	 * @generated
	 * @ordered
	 */
	public static final int TRANSFER_ONCE_VALUE = 1;

	/**
	 * The '<em><b>Transfer Twice</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Transfer Twice</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRANSFER_TWICE
	 * @model name="Transfer_Twice"
	 * @generated
	 * @ordered
	 */
	public static final int TRANSFER_TWICE_VALUE = 2;

	/**
	 * The '<em><b>Unlimited</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Unlimited</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNLIMITED
	 * @model name="Unlimited"
	 * @generated
	 * @ordered
	 */
	public static final int UNLIMITED_VALUE = -1;

	/**
	 * An array of all the '<em><b>Allowed transfers</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Allowed_transfers[] VALUES_ARRAY = new Allowed_transfers[] { NO_TRANSFERS, TRANSFER_ONCE,
			TRANSFER_TWICE, UNLIMITED, };

	/**
	 * A public read-only list of all the '<em><b>Allowed transfers</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Allowed_transfers> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Allowed transfers</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Allowed_transfers get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Allowed_transfers result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Allowed transfers</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Allowed_transfers getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Allowed_transfers result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Allowed transfers</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Allowed_transfers get(int value) {
		switch (value) {
		case NO_TRANSFERS_VALUE:
			return NO_TRANSFERS;
		case TRANSFER_ONCE_VALUE:
			return TRANSFER_ONCE;
		case TRANSFER_TWICE_VALUE:
			return TRANSFER_TWICE;
		case UNLIMITED_VALUE:
			return UNLIMITED;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Allowed_transfers(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //Allowed_transfers
