/**
 */
package mobilityResources;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transit</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Transit#getRoute <em>Route</em>}</li>
 *   <li>{@link mobilityResources.Transit#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getTransit()
 * @model
 * @generated
 */
public interface Transit extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Route</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Route#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route</em>' reference.
	 * @see #setRoute(Route)
	 * @see mobilityResources.MobilityResourcesPackage#getTransit_Route()
	 * @see mobilityResources.Route#getType
	 * @model opposite="type"
	 * @generated
	 */
	Route getRoute();

	/**
	 * Sets the value of the '{@link mobilityResources.Transit#getRoute <em>Route</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route</em>' reference.
	 * @see #getRoute()
	 * @generated
	 */
	void setRoute(Route value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.TransitType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see mobilityResources.TransitType
	 * @see #setType(TransitType)
	 * @see mobilityResources.MobilityResourcesPackage#getTransit_Type()
	 * @model
	 * @generated
	 */
	TransitType getType();

	/**
	 * Sets the value of the '{@link mobilityResources.Transit#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see mobilityResources.TransitType
	 * @see #getType()
	 * @generated
	 */
	void setType(TransitType value);

} // Transit
