/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calendar date</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Calendar_date#getService_id <em>Service id</em>}</li>
 *   <li>{@link mobilityResources.Calendar_date#getDate <em>Date</em>}</li>
 *   <li>{@link mobilityResources.Calendar_date#getException_type <em>Exception type</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getCalendar_date()
 * @model
 * @generated
 */
public interface Calendar_date extends EObject {
	/**
	 * Returns the value of the '<em><b>Service id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service id</em>' attribute.
	 * @see #setService_id(String)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_date_Service_id()
	 * @model
	 * @generated
	 */
	String getService_id();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar_date#getService_id <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service id</em>' attribute.
	 * @see #getService_id()
	 * @generated
	 */
	void setService_id(String value);

	/**
	 * Returns the value of the '<em><b>Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Date</em>' attribute.
	 * @see #setDate(String)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_date_Date()
	 * @model
	 * @generated
	 */
	String getDate();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar_date#getDate <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Date</em>' attribute.
	 * @see #getDate()
	 * @generated
	 */
	void setDate(String value);

	/**
	 * Returns the value of the '<em><b>Exception type</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Exception_type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Exception type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exception type</em>' attribute.
	 * @see mobilityResources.Exception_type
	 * @see #setException_type(Exception_type)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_date_Exception_type()
	 * @model
	 * @generated
	 */
	Exception_type getException_type();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar_date#getException_type <em>Exception type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Exception type</em>' attribute.
	 * @see mobilityResources.Exception_type
	 * @see #getException_type()
	 * @generated
	 */
	void setException_type(Exception_type value);

} // Calendar_date
