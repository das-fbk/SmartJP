/**
 */
package mobilityResources.util;

import mobilityResources.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesPackage
 * @generated
 */
public class MobilityResourcesAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MobilityResourcesPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilityResourcesAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = MobilityResourcesPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MobilityResourcesSwitch<Adapter> modelSwitch = new MobilityResourcesSwitch<Adapter>() {
		@Override
		public Adapter caseMobilitySupport(MobilitySupport object) {
			return createMobilitySupportAdapter();
		}

		@Override
		public Adapter caseMobilityResource(MobilityResource object) {
			return createMobilityResourceAdapter();
		}

		@Override
		public Adapter caseParking(Parking object) {
			return createParkingAdapter();
		}

		@Override
		public Adapter caseBikeSharing(BikeSharing object) {
			return createBikeSharingAdapter();
		}

		@Override
		public Adapter caseGeographicLocation(GeographicLocation object) {
			return createGeographicLocationAdapter();
		}

		@Override
		public Adapter caseAgency(Agency object) {
			return createAgencyAdapter();
		}

		@Override
		public Adapter caseTransit(Transit object) {
			return createTransitAdapter();
		}

		@Override
		public Adapter caseStop(Stop object) {
			return createStopAdapter();
		}

		@Override
		public Adapter caseRoute(Route object) {
			return createRouteAdapter();
		}

		@Override
		public Adapter caseTrip(Trip object) {
			return createTripAdapter();
		}

		@Override
		public Adapter caseCalendar(Calendar object) {
			return createCalendarAdapter();
		}

		@Override
		public Adapter caseBlock(Block object) {
			return createBlockAdapter();
		}

		@Override
		public Adapter caseStop_time(Stop_time object) {
			return createStop_timeAdapter();
		}

		@Override
		public Adapter caseCalendar_date(Calendar_date object) {
			return createCalendar_dateAdapter();
		}

		@Override
		public Adapter caseFare_attribute(Fare_attribute object) {
			return createFare_attributeAdapter();
		}

		@Override
		public Adapter caseFare_rule(Fare_rule object) {
			return createFare_ruleAdapter();
		}

		@Override
		public Adapter caseZone(Zone object) {
			return createZoneAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.MobilitySupport <em>Mobility Support</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.MobilitySupport
	 * @generated
	 */
	public Adapter createMobilitySupportAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.MobilityResource <em>Mobility Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.MobilityResource
	 * @generated
	 */
	public Adapter createMobilityResourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Parking <em>Parking</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Parking
	 * @generated
	 */
	public Adapter createParkingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.BikeSharing <em>Bike Sharing</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.BikeSharing
	 * @generated
	 */
	public Adapter createBikeSharingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.GeographicLocation <em>Geographic Location</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.GeographicLocation
	 * @generated
	 */
	public Adapter createGeographicLocationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Agency <em>Agency</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Agency
	 * @generated
	 */
	public Adapter createAgencyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Transit <em>Transit</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Transit
	 * @generated
	 */
	public Adapter createTransitAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Stop <em>Stop</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Stop
	 * @generated
	 */
	public Adapter createStopAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Route <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Route
	 * @generated
	 */
	public Adapter createRouteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Trip <em>Trip</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Trip
	 * @generated
	 */
	public Adapter createTripAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Calendar <em>Calendar</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Calendar
	 * @generated
	 */
	public Adapter createCalendarAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Block <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Block
	 * @generated
	 */
	public Adapter createBlockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Stop_time <em>Stop time</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Stop_time
	 * @generated
	 */
	public Adapter createStop_timeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Calendar_date <em>Calendar date</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Calendar_date
	 * @generated
	 */
	public Adapter createCalendar_dateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Fare_attribute <em>Fare attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Fare_attribute
	 * @generated
	 */
	public Adapter createFare_attributeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Fare_rule <em>Fare rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Fare_rule
	 * @generated
	 */
	public Adapter createFare_ruleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mobilityResources.Zone <em>Zone</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mobilityResources.Zone
	 * @generated
	 */
	public Adapter createZoneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //MobilityResourcesAdapterFactory
