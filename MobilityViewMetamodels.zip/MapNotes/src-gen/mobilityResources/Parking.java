/**
 */
package mobilityResources;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parking</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Parking#getAddress <em>Address</em>}</li>
 *   <li>{@link mobilityResources.Parking#getSlots <em>Slots</em>}</li>
 *   <li>{@link mobilityResources.Parking#getTotalSlots <em>Total Slots</em>}</li>
 *   <li>{@link mobilityResources.Parking#getPosition <em>Position</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getParking()
 * @model
 * @generated
 */
public interface Parking extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Address</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Address</em>' attribute.
	 * @see #setAddress(String)
	 * @see mobilityResources.MobilityResourcesPackage#getParking_Address()
	 * @model
	 * @generated
	 */
	String getAddress();

	/**
	 * Sets the value of the '{@link mobilityResources.Parking#getAddress <em>Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Address</em>' attribute.
	 * @see #getAddress()
	 * @generated
	 */
	void setAddress(String value);

	/**
	 * Returns the value of the '<em><b>Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Slots</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Slots</em>' attribute.
	 * @see #setSlots(int)
	 * @see mobilityResources.MobilityResourcesPackage#getParking_Slots()
	 * @model
	 * @generated
	 */
	int getSlots();

	/**
	 * Sets the value of the '{@link mobilityResources.Parking#getSlots <em>Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Slots</em>' attribute.
	 * @see #getSlots()
	 * @generated
	 */
	void setSlots(int value);

	/**
	 * Returns the value of the '<em><b>Total Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Total Slots</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Slots</em>' attribute.
	 * @see #setTotalSlots(int)
	 * @see mobilityResources.MobilityResourcesPackage#getParking_TotalSlots()
	 * @model
	 * @generated
	 */
	int getTotalSlots();

	/**
	 * Sets the value of the '{@link mobilityResources.Parking#getTotalSlots <em>Total Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Slots</em>' attribute.
	 * @see #getTotalSlots()
	 * @generated
	 */
	void setTotalSlots(int value);

	/**
	 * Returns the value of the '<em><b>Position</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.GeographicLocation#getParking <em>Parking</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Position</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Position</em>' reference.
	 * @see #setPosition(GeographicLocation)
	 * @see mobilityResources.MobilityResourcesPackage#getParking_Position()
	 * @see mobilityResources.GeographicLocation#getParking
	 * @model opposite="parking"
	 * @generated
	 */
	GeographicLocation getPosition();

	/**
	 * Sets the value of the '{@link mobilityResources.Parking#getPosition <em>Position</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Position</em>' reference.
	 * @see #getPosition()
	 * @generated
	 */
	void setPosition(GeographicLocation value);

} // Parking
