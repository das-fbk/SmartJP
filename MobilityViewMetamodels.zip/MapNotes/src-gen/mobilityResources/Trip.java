/**
 */
package mobilityResources;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trip</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Trip#getRoute <em>Route</em>}</li>
 *   <li>{@link mobilityResources.Trip#getService <em>Service</em>}</li>
 *   <li>{@link mobilityResources.Trip#getHeadsign <em>Headsign</em>}</li>
 *   <li>{@link mobilityResources.Trip#getDirection_id <em>Direction id</em>}</li>
 *   <li>{@link mobilityResources.Trip#getBlock <em>Block</em>}</li>
 *   <li>{@link mobilityResources.Trip#getWheelchair_accessible <em>Wheelchair accessible</em>}</li>
 *   <li>{@link mobilityResources.Trip#getBikes_allowed <em>Bikes allowed</em>}</li>
 *   <li>{@link mobilityResources.Trip#getService_dates <em>Service dates</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getTrip()
 * @model
 * @generated
 */
public interface Trip extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Route</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Route#getTrips <em>Trips</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route</em>' reference.
	 * @see #setRoute(Route)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Route()
	 * @see mobilityResources.Route#getTrips
	 * @model opposite="trips"
	 * @generated
	 */
	Route getRoute();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getRoute <em>Route</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route</em>' reference.
	 * @see #getRoute()
	 * @generated
	 */
	void setRoute(Route value);

	/**
	 * Returns the value of the '<em><b>Service</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' reference.
	 * @see #setService(Calendar)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Service()
	 * @model
	 * @generated
	 */
	Calendar getService();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getService <em>Service</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service</em>' reference.
	 * @see #getService()
	 * @generated
	 */
	void setService(Calendar value);

	/**
	 * Returns the value of the '<em><b>Headsign</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Headsign</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Headsign</em>' attribute.
	 * @see #setHeadsign(String)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Headsign()
	 * @model
	 * @generated
	 */
	String getHeadsign();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getHeadsign <em>Headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Headsign</em>' attribute.
	 * @see #getHeadsign()
	 * @generated
	 */
	void setHeadsign(String value);

	/**
	 * Returns the value of the '<em><b>Direction id</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.TravelDirection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Direction id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Direction id</em>' attribute.
	 * @see mobilityResources.TravelDirection
	 * @see #setDirection_id(TravelDirection)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Direction_id()
	 * @model
	 * @generated
	 */
	TravelDirection getDirection_id();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getDirection_id <em>Direction id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Direction id</em>' attribute.
	 * @see mobilityResources.TravelDirection
	 * @see #getDirection_id()
	 * @generated
	 */
	void setDirection_id(TravelDirection value);

	/**
	 * Returns the value of the '<em><b>Block</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Block#getTrips <em>Trips</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Block</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Block</em>' reference.
	 * @see #setBlock(Block)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Block()
	 * @see mobilityResources.Block#getTrips
	 * @model opposite="trips"
	 * @generated
	 */
	Block getBlock();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getBlock <em>Block</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Block</em>' reference.
	 * @see #getBlock()
	 * @generated
	 */
	void setBlock(Block value);

	/**
	 * Returns the value of the '<em><b>Wheelchair accessible</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Accessibility}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Wheelchair accessible</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wheelchair accessible</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #setWheelchair_accessible(Accessibility)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Wheelchair_accessible()
	 * @model
	 * @generated
	 */
	Accessibility getWheelchair_accessible();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getWheelchair_accessible <em>Wheelchair accessible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wheelchair accessible</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #getWheelchair_accessible()
	 * @generated
	 */
	void setWheelchair_accessible(Accessibility value);

	/**
	 * Returns the value of the '<em><b>Bikes allowed</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Accessibility}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bikes allowed</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bikes allowed</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #setBikes_allowed(Accessibility)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Bikes_allowed()
	 * @model
	 * @generated
	 */
	Accessibility getBikes_allowed();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getBikes_allowed <em>Bikes allowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bikes allowed</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #getBikes_allowed()
	 * @generated
	 */
	void setBikes_allowed(Accessibility value);

	/**
	 * Returns the value of the '<em><b>Service dates</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service dates</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service dates</em>' reference.
	 * @see #setService_dates(Calendar_date)
	 * @see mobilityResources.MobilityResourcesPackage#getTrip_Service_dates()
	 * @model
	 * @generated
	 */
	Calendar_date getService_dates();

	/**
	 * Sets the value of the '{@link mobilityResources.Trip#getService_dates <em>Service dates</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service dates</em>' reference.
	 * @see #getService_dates()
	 * @generated
	 */
	void setService_dates(Calendar_date value);

} // Trip
