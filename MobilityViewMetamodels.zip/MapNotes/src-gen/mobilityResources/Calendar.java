/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Calendar</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Calendar#getService_id <em>Service id</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getMonday <em>Monday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getTuesday <em>Tuesday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getWednesday <em>Wednesday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getThursday <em>Thursday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getFriday <em>Friday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getSaturday <em>Saturday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getSunday <em>Sunday</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getStart_date <em>Start date</em>}</li>
 *   <li>{@link mobilityResources.Calendar#getEnd_date <em>End date</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getCalendar()
 * @model
 * @generated
 */
public interface Calendar extends EObject {
	/**
	 * Returns the value of the '<em><b>Service id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service id</em>' attribute.
	 * @see #setService_id(String)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Service_id()
	 * @model
	 * @generated
	 */
	String getService_id();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getService_id <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service id</em>' attribute.
	 * @see #getService_id()
	 * @generated
	 */
	void setService_id(String value);

	/**
	 * Returns the value of the '<em><b>Monday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Monday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Monday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setMonday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Monday()
	 * @model
	 * @generated
	 */
	Availability getMonday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getMonday <em>Monday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Monday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getMonday()
	 * @generated
	 */
	void setMonday(Availability value);

	/**
	 * Returns the value of the '<em><b>Tuesday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tuesday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tuesday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setTuesday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Tuesday()
	 * @model
	 * @generated
	 */
	Availability getTuesday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getTuesday <em>Tuesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tuesday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getTuesday()
	 * @generated
	 */
	void setTuesday(Availability value);

	/**
	 * Returns the value of the '<em><b>Wednesday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Wednesday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wednesday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setWednesday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Wednesday()
	 * @model
	 * @generated
	 */
	Availability getWednesday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getWednesday <em>Wednesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wednesday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getWednesday()
	 * @generated
	 */
	void setWednesday(Availability value);

	/**
	 * Returns the value of the '<em><b>Thursday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Thursday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thursday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setThursday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Thursday()
	 * @model
	 * @generated
	 */
	Availability getThursday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getThursday <em>Thursday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thursday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getThursday()
	 * @generated
	 */
	void setThursday(Availability value);

	/**
	 * Returns the value of the '<em><b>Friday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Friday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Friday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setFriday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Friday()
	 * @model
	 * @generated
	 */
	Availability getFriday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getFriday <em>Friday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Friday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getFriday()
	 * @generated
	 */
	void setFriday(Availability value);

	/**
	 * Returns the value of the '<em><b>Saturday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Saturday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Saturday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setSaturday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Saturday()
	 * @model
	 * @generated
	 */
	Availability getSaturday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getSaturday <em>Saturday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Saturday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getSaturday()
	 * @generated
	 */
	void setSaturday(Availability value);

	/**
	 * Returns the value of the '<em><b>Sunday</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Availability}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sunday</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sunday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #setSunday(Availability)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Sunday()
	 * @model
	 * @generated
	 */
	Availability getSunday();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getSunday <em>Sunday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sunday</em>' attribute.
	 * @see mobilityResources.Availability
	 * @see #getSunday()
	 * @generated
	 */
	void setSunday(Availability value);

	/**
	 * Returns the value of the '<em><b>Start date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start date</em>' attribute.
	 * @see #setStart_date(String)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_Start_date()
	 * @model
	 * @generated
	 */
	String getStart_date();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getStart_date <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start date</em>' attribute.
	 * @see #getStart_date()
	 * @generated
	 */
	void setStart_date(String value);

	/**
	 * Returns the value of the '<em><b>End date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End date</em>' attribute.
	 * @see #setEnd_date(String)
	 * @see mobilityResources.MobilityResourcesPackage#getCalendar_End_date()
	 * @model
	 * @generated
	 */
	String getEnd_date();

	/**
	 * Sets the value of the '{@link mobilityResources.Calendar#getEnd_date <em>End date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End date</em>' attribute.
	 * @see #getEnd_date()
	 * @generated
	 */
	void setEnd_date(String value);

} // Calendar
