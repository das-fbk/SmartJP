/**
 */
package mobilityResources;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Stop#getCode <em>Code</em>}</li>
 *   <li>{@link mobilityResources.Stop#getDesc <em>Desc</em>}</li>
 *   <li>{@link mobilityResources.Stop#getStop_location <em>Stop location</em>}</li>
 *   <li>{@link mobilityResources.Stop#getUrl <em>Url</em>}</li>
 *   <li>{@link mobilityResources.Stop#getLocation_type <em>Location type</em>}</li>
 *   <li>{@link mobilityResources.Stop#getParent_station <em>Parent station</em>}</li>
 *   <li>{@link mobilityResources.Stop#getWheelchair_boarding <em>Wheelchair boarding</em>}</li>
 *   <li>{@link mobilityResources.Stop#getZone <em>Zone</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getStop()
 * @model
 * @generated
 */
public interface Stop extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Code</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code</em>' attribute.
	 * @see #setCode(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Code()
	 * @model
	 * @generated
	 */
	String getCode();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getCode <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code</em>' attribute.
	 * @see #getCode()
	 * @generated
	 */
	void setCode(String value);

	/**
	 * Returns the value of the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Desc</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Desc</em>' attribute.
	 * @see #setDesc(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Desc()
	 * @model
	 * @generated
	 */
	String getDesc();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getDesc <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Desc</em>' attribute.
	 * @see #getDesc()
	 * @generated
	 */
	void setDesc(String value);

	/**
	 * Returns the value of the '<em><b>Stop location</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.GeographicLocation#getStop <em>Stop</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop location</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop location</em>' reference.
	 * @see #setStop_location(GeographicLocation)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Stop_location()
	 * @see mobilityResources.GeographicLocation#getStop
	 * @model opposite="stop"
	 * @generated
	 */
	GeographicLocation getStop_location();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getStop_location <em>Stop location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop location</em>' reference.
	 * @see #getStop_location()
	 * @generated
	 */
	void setStop_location(GeographicLocation value);

	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

	/**
	 * Returns the value of the '<em><b>Location type</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Location_Type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Location type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location type</em>' attribute.
	 * @see mobilityResources.Location_Type
	 * @see #setLocation_type(Location_Type)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Location_type()
	 * @model
	 * @generated
	 */
	Location_Type getLocation_type();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getLocation_type <em>Location type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location type</em>' attribute.
	 * @see mobilityResources.Location_Type
	 * @see #getLocation_type()
	 * @generated
	 */
	void setLocation_type(Location_Type value);

	/**
	 * Returns the value of the '<em><b>Parent station</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent station</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent station</em>' attribute.
	 * @see #setParent_station(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Parent_station()
	 * @model
	 * @generated
	 */
	String getParent_station();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getParent_station <em>Parent station</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent station</em>' attribute.
	 * @see #getParent_station()
	 * @generated
	 */
	void setParent_station(String value);

	/**
	 * Returns the value of the '<em><b>Wheelchair boarding</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Accessibility}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Wheelchair boarding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wheelchair boarding</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #setWheelchair_boarding(Accessibility)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Wheelchair_boarding()
	 * @model
	 * @generated
	 */
	Accessibility getWheelchair_boarding();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getWheelchair_boarding <em>Wheelchair boarding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wheelchair boarding</em>' attribute.
	 * @see mobilityResources.Accessibility
	 * @see #getWheelchair_boarding()
	 * @generated
	 */
	void setWheelchair_boarding(Accessibility value);

	/**
	 * Returns the value of the '<em><b>Zone</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Zone#getStops <em>Stops</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Zone</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Zone</em>' reference.
	 * @see #setZone(Zone)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_Zone()
	 * @see mobilityResources.Zone#getStops
	 * @model opposite="stops"
	 * @generated
	 */
	Zone getZone();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop#getZone <em>Zone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Zone</em>' reference.
	 * @see #getZone()
	 * @generated
	 */
	void setZone(Zone value);

} // Stop
