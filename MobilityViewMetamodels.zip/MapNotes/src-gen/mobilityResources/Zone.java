/**
 */
package mobilityResources;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Zone</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Zone#getStops <em>Stops</em>}</li>
 *   <li>{@link mobilityResources.Zone#getOrigin_fare_rules <em>Origin fare rules</em>}</li>
 *   <li>{@link mobilityResources.Zone#getDestination_fare_rules <em>Destination fare rules</em>}</li>
 *   <li>{@link mobilityResources.Zone#getContains_fare_rules <em>Contains fare rules</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getZone()
 * @model
 * @generated
 */
public interface Zone extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Stops</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Stop}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Stop#getZone <em>Zone</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stops</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stops</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getZone_Stops()
	 * @see mobilityResources.Stop#getZone
	 * @model opposite="zone"
	 * @generated
	 */
	EList<Stop> getStops();

	/**
	 * Returns the value of the '<em><b>Origin fare rules</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Fare_rule}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_rule#getOrigin <em>Origin</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Origin fare rules</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Origin fare rules</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getZone_Origin_fare_rules()
	 * @see mobilityResources.Fare_rule#getOrigin
	 * @model opposite="origin"
	 * @generated
	 */
	EList<Fare_rule> getOrigin_fare_rules();

	/**
	 * Returns the value of the '<em><b>Destination fare rules</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Fare_rule}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_rule#getDestination <em>Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destination fare rules</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination fare rules</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getZone_Destination_fare_rules()
	 * @see mobilityResources.Fare_rule#getDestination
	 * @model opposite="destination"
	 * @generated
	 */
	EList<Fare_rule> getDestination_fare_rules();

	/**
	 * Returns the value of the '<em><b>Contains fare rules</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_rule#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contains fare rules</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains fare rules</em>' reference.
	 * @see #setContains_fare_rules(Fare_rule)
	 * @see mobilityResources.MobilityResourcesPackage#getZone_Contains_fare_rules()
	 * @see mobilityResources.Fare_rule#getContains
	 * @model opposite="contains"
	 * @generated
	 */
	Fare_rule getContains_fare_rules();

	/**
	 * Sets the value of the '{@link mobilityResources.Zone#getContains_fare_rules <em>Contains fare rules</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contains fare rules</em>' reference.
	 * @see #getContains_fare_rules()
	 * @generated
	 */
	void setContains_fare_rules(Fare_rule value);

} // Zone
