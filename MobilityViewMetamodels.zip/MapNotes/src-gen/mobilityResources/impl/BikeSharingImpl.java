/**
 */
package mobilityResources.impl;

import mobilityResources.BikeSharing;
import mobilityResources.GeographicLocation;
import mobilityResources.MobilityResourcesPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bike Sharing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.BikeSharingImpl#getAddress <em>Address</em>}</li>
 *   <li>{@link mobilityResources.impl.BikeSharingImpl#getBikes <em>Bikes</em>}</li>
 *   <li>{@link mobilityResources.impl.BikeSharingImpl#getSlots <em>Slots</em>}</li>
 *   <li>{@link mobilityResources.impl.BikeSharingImpl#getTotalSlots <em>Total Slots</em>}</li>
 *   <li>{@link mobilityResources.impl.BikeSharingImpl#getPosition <em>Position</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BikeSharingImpl extends MobilityResourceImpl implements BikeSharing {
	/**
	 * The default value of the '{@link #getAddress() <em>Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddress()
	 * @generated
	 * @ordered
	 */
	protected static final String ADDRESS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAddress() <em>Address</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAddress()
	 * @generated
	 * @ordered
	 */
	protected String address = ADDRESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getBikes() <em>Bikes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBikes()
	 * @generated
	 * @ordered
	 */
	protected static final int BIKES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBikes() <em>Bikes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBikes()
	 * @generated
	 * @ordered
	 */
	protected int bikes = BIKES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSlots() <em>Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSlots()
	 * @generated
	 * @ordered
	 */
	protected static final int SLOTS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSlots() <em>Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSlots()
	 * @generated
	 * @ordered
	 */
	protected int slots = SLOTS_EDEFAULT;

	/**
	 * The default value of the '{@link #getTotalSlots() <em>Total Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalSlots()
	 * @generated
	 * @ordered
	 */
	protected static final int TOTAL_SLOTS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTotalSlots() <em>Total Slots</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalSlots()
	 * @generated
	 * @ordered
	 */
	protected int totalSlots = TOTAL_SLOTS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPosition() <em>Position</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPosition()
	 * @generated
	 * @ordered
	 */
	protected GeographicLocation position;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BikeSharingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.BIKE_SHARING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAddress(String newAddress) {
		String oldAddress = address;
		address = newAddress;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.BIKE_SHARING__ADDRESS,
					oldAddress, address));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getBikes() {
		return bikes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBikes(int newBikes) {
		int oldBikes = bikes;
		bikes = newBikes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.BIKE_SHARING__BIKES,
					oldBikes, bikes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSlots() {
		return slots;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSlots(int newSlots) {
		int oldSlots = slots;
		slots = newSlots;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.BIKE_SHARING__SLOTS,
					oldSlots, slots));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalSlots() {
		return totalSlots;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalSlots(int newTotalSlots) {
		int oldTotalSlots = totalSlots;
		totalSlots = newTotalSlots;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.BIKE_SHARING__TOTAL_SLOTS,
					oldTotalSlots, totalSlots));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GeographicLocation getPosition() {
		if (position != null && position.eIsProxy()) {
			InternalEObject oldPosition = (InternalEObject) position;
			position = (GeographicLocation) eResolveProxy(oldPosition);
			if (position != oldPosition) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.BIKE_SHARING__POSITION, oldPosition, position));
			}
		}
		return position;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GeographicLocation basicGetPosition() {
		return position;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPosition(GeographicLocation newPosition, NotificationChain msgs) {
		GeographicLocation oldPosition = position;
		position = newPosition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.BIKE_SHARING__POSITION, oldPosition, newPosition);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPosition(GeographicLocation newPosition) {
		if (newPosition != position) {
			NotificationChain msgs = null;
			if (position != null)
				msgs = ((InternalEObject) position).eInverseRemove(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, GeographicLocation.class, msgs);
			if (newPosition != null)
				msgs = ((InternalEObject) newPosition).eInverseAdd(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, GeographicLocation.class, msgs);
			msgs = basicSetPosition(newPosition, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.BIKE_SHARING__POSITION,
					newPosition, newPosition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			if (position != null)
				msgs = ((InternalEObject) position).eInverseRemove(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__BIKESHARING, GeographicLocation.class, msgs);
			return basicSetPosition((GeographicLocation) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			return basicSetPosition(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__ADDRESS:
			return getAddress();
		case MobilityResourcesPackage.BIKE_SHARING__BIKES:
			return getBikes();
		case MobilityResourcesPackage.BIKE_SHARING__SLOTS:
			return getSlots();
		case MobilityResourcesPackage.BIKE_SHARING__TOTAL_SLOTS:
			return getTotalSlots();
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			if (resolve)
				return getPosition();
			return basicGetPosition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__ADDRESS:
			setAddress((String) newValue);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__BIKES:
			setBikes((Integer) newValue);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__SLOTS:
			setSlots((Integer) newValue);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__TOTAL_SLOTS:
			setTotalSlots((Integer) newValue);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			setPosition((GeographicLocation) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__ADDRESS:
			setAddress(ADDRESS_EDEFAULT);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__BIKES:
			setBikes(BIKES_EDEFAULT);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__SLOTS:
			setSlots(SLOTS_EDEFAULT);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__TOTAL_SLOTS:
			setTotalSlots(TOTAL_SLOTS_EDEFAULT);
			return;
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			setPosition((GeographicLocation) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.BIKE_SHARING__ADDRESS:
			return ADDRESS_EDEFAULT == null ? address != null : !ADDRESS_EDEFAULT.equals(address);
		case MobilityResourcesPackage.BIKE_SHARING__BIKES:
			return bikes != BIKES_EDEFAULT;
		case MobilityResourcesPackage.BIKE_SHARING__SLOTS:
			return slots != SLOTS_EDEFAULT;
		case MobilityResourcesPackage.BIKE_SHARING__TOTAL_SLOTS:
			return totalSlots != TOTAL_SLOTS_EDEFAULT;
		case MobilityResourcesPackage.BIKE_SHARING__POSITION:
			return position != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (address: ");
		result.append(address);
		result.append(", bikes: ");
		result.append(bikes);
		result.append(", slots: ");
		result.append(slots);
		result.append(", totalSlots: ");
		result.append(totalSlots);
		result.append(')');
		return result.toString();
	}

} //BikeSharingImpl
