/**
 */
package mobilityResources.impl;

import java.util.Collection;

import mobilityResources.Fare_rule;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Stop;
import mobilityResources.Zone;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Zone</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.ZoneImpl#getStops <em>Stops</em>}</li>
 *   <li>{@link mobilityResources.impl.ZoneImpl#getOrigin_fare_rules <em>Origin fare rules</em>}</li>
 *   <li>{@link mobilityResources.impl.ZoneImpl#getDestination_fare_rules <em>Destination fare rules</em>}</li>
 *   <li>{@link mobilityResources.impl.ZoneImpl#getContains_fare_rules <em>Contains fare rules</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ZoneImpl extends MobilityResourceImpl implements Zone {
	/**
	 * The cached value of the '{@link #getStops() <em>Stops</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStops()
	 * @generated
	 * @ordered
	 */
	protected EList<Stop> stops;

	/**
	 * The cached value of the '{@link #getOrigin_fare_rules() <em>Origin fare rules</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrigin_fare_rules()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_rule> origin_fare_rules;

	/**
	 * The cached value of the '{@link #getDestination_fare_rules() <em>Destination fare rules</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestination_fare_rules()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_rule> destination_fare_rules;

	/**
	 * The cached value of the '{@link #getContains_fare_rules() <em>Contains fare rules</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains_fare_rules()
	 * @generated
	 * @ordered
	 */
	protected Fare_rule contains_fare_rules;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ZoneImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.ZONE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Stop> getStops() {
		if (stops == null) {
			stops = new EObjectWithInverseResolvingEList<Stop>(Stop.class, this, MobilityResourcesPackage.ZONE__STOPS,
					MobilityResourcesPackage.STOP__ZONE);
		}
		return stops;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_rule> getOrigin_fare_rules() {
		if (origin_fare_rules == null) {
			origin_fare_rules = new EObjectWithInverseResolvingEList<Fare_rule>(Fare_rule.class, this,
					MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES, MobilityResourcesPackage.FARE_RULE__ORIGIN);
		}
		return origin_fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_rule> getDestination_fare_rules() {
		if (destination_fare_rules == null) {
			destination_fare_rules = new EObjectWithInverseResolvingEList<Fare_rule>(Fare_rule.class, this,
					MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES,
					MobilityResourcesPackage.FARE_RULE__DESTINATION);
		}
		return destination_fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_rule getContains_fare_rules() {
		if (contains_fare_rules != null && contains_fare_rules.eIsProxy()) {
			InternalEObject oldContains_fare_rules = (InternalEObject) contains_fare_rules;
			contains_fare_rules = (Fare_rule) eResolveProxy(oldContains_fare_rules);
			if (contains_fare_rules != oldContains_fare_rules) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES, oldContains_fare_rules,
							contains_fare_rules));
			}
		}
		return contains_fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_rule basicGetContains_fare_rules() {
		return contains_fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetContains_fare_rules(Fare_rule newContains_fare_rules, NotificationChain msgs) {
		Fare_rule oldContains_fare_rules = contains_fare_rules;
		contains_fare_rules = newContains_fare_rules;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES, oldContains_fare_rules, newContains_fare_rules);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContains_fare_rules(Fare_rule newContains_fare_rules) {
		if (newContains_fare_rules != contains_fare_rules) {
			NotificationChain msgs = null;
			if (contains_fare_rules != null)
				msgs = ((InternalEObject) contains_fare_rules).eInverseRemove(this,
						MobilityResourcesPackage.FARE_RULE__CONTAINS, Fare_rule.class, msgs);
			if (newContains_fare_rules != null)
				msgs = ((InternalEObject) newContains_fare_rules).eInverseAdd(this,
						MobilityResourcesPackage.FARE_RULE__CONTAINS, Fare_rule.class, msgs);
			msgs = basicSetContains_fare_rules(newContains_fare_rules, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES,
					newContains_fare_rules, newContains_fare_rules));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getStops()).basicAdd(otherEnd, msgs);
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getOrigin_fare_rules()).basicAdd(otherEnd,
					msgs);
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDestination_fare_rules()).basicAdd(otherEnd,
					msgs);
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			if (contains_fare_rules != null)
				msgs = ((InternalEObject) contains_fare_rules).eInverseRemove(this,
						MobilityResourcesPackage.FARE_RULE__CONTAINS, Fare_rule.class, msgs);
			return basicSetContains_fare_rules((Fare_rule) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			return ((InternalEList<?>) getStops()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			return ((InternalEList<?>) getOrigin_fare_rules()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			return ((InternalEList<?>) getDestination_fare_rules()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			return basicSetContains_fare_rules(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			return getStops();
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			return getOrigin_fare_rules();
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			return getDestination_fare_rules();
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			if (resolve)
				return getContains_fare_rules();
			return basicGetContains_fare_rules();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			getStops().clear();
			getStops().addAll((Collection<? extends Stop>) newValue);
			return;
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			getOrigin_fare_rules().clear();
			getOrigin_fare_rules().addAll((Collection<? extends Fare_rule>) newValue);
			return;
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			getDestination_fare_rules().clear();
			getDestination_fare_rules().addAll((Collection<? extends Fare_rule>) newValue);
			return;
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			setContains_fare_rules((Fare_rule) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			getStops().clear();
			return;
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			getOrigin_fare_rules().clear();
			return;
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			getDestination_fare_rules().clear();
			return;
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			setContains_fare_rules((Fare_rule) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.ZONE__STOPS:
			return stops != null && !stops.isEmpty();
		case MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES:
			return origin_fare_rules != null && !origin_fare_rules.isEmpty();
		case MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES:
			return destination_fare_rules != null && !destination_fare_rules.isEmpty();
		case MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES:
			return contains_fare_rules != null;
		}
		return super.eIsSet(featureID);
	}

} //ZoneImpl
