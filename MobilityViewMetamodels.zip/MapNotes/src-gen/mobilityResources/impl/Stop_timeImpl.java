/**
 */
package mobilityResources.impl;

import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Pickup_Drop_off_Type;
import mobilityResources.Stop;
import mobilityResources.Stop_time;
import mobilityResources.TimeAdherence;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stop time</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getArrival_time <em>Arrival time</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getDeparture_time <em>Departure time</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getStop <em>Stop</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getStop_sequence <em>Stop sequence</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getStop_headsign <em>Stop headsign</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getPickup_type <em>Pickup type</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getDrop_off_type <em>Drop off type</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getShape_dist_traveled <em>Shape dist traveled</em>}</li>
 *   <li>{@link mobilityResources.impl.Stop_timeImpl#getTimepoint <em>Timepoint</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Stop_timeImpl extends MinimalEObjectImpl.Container implements Stop_time {
	/**
	 * The default value of the '{@link #getArrival_time() <em>Arrival time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArrival_time()
	 * @generated
	 * @ordered
	 */
	protected static final String ARRIVAL_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArrival_time() <em>Arrival time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArrival_time()
	 * @generated
	 * @ordered
	 */
	protected String arrival_time = ARRIVAL_TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDeparture_time() <em>Departure time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeparture_time()
	 * @generated
	 * @ordered
	 */
	protected static final String DEPARTURE_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDeparture_time() <em>Departure time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeparture_time()
	 * @generated
	 * @ordered
	 */
	protected String departure_time = DEPARTURE_TIME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStop() <em>Stop</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop()
	 * @generated
	 * @ordered
	 */
	protected Stop stop;

	/**
	 * The default value of the '{@link #getStop_sequence() <em>Stop sequence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_sequence()
	 * @generated
	 * @ordered
	 */
	protected static final int STOP_SEQUENCE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getStop_sequence() <em>Stop sequence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_sequence()
	 * @generated
	 * @ordered
	 */
	protected int stop_sequence = STOP_SEQUENCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getStop_headsign() <em>Stop headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_headsign()
	 * @generated
	 * @ordered
	 */
	protected static final String STOP_HEADSIGN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStop_headsign() <em>Stop headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_headsign()
	 * @generated
	 * @ordered
	 */
	protected String stop_headsign = STOP_HEADSIGN_EDEFAULT;

	/**
	 * The default value of the '{@link #getPickup_type() <em>Pickup type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPickup_type()
	 * @generated
	 * @ordered
	 */
	protected static final Pickup_Drop_off_Type PICKUP_TYPE_EDEFAULT = Pickup_Drop_off_Type.REGULARLY_SCHEDULED;

	/**
	 * The cached value of the '{@link #getPickup_type() <em>Pickup type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPickup_type()
	 * @generated
	 * @ordered
	 */
	protected Pickup_Drop_off_Type pickup_type = PICKUP_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDrop_off_type() <em>Drop off type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrop_off_type()
	 * @generated
	 * @ordered
	 */
	protected static final Pickup_Drop_off_Type DROP_OFF_TYPE_EDEFAULT = Pickup_Drop_off_Type.REGULARLY_SCHEDULED;

	/**
	 * The cached value of the '{@link #getDrop_off_type() <em>Drop off type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrop_off_type()
	 * @generated
	 * @ordered
	 */
	protected Pickup_Drop_off_Type drop_off_type = DROP_OFF_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getShape_dist_traveled() <em>Shape dist traveled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShape_dist_traveled()
	 * @generated
	 * @ordered
	 */
	protected static final String SHAPE_DIST_TRAVELED_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getShape_dist_traveled() <em>Shape dist traveled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShape_dist_traveled()
	 * @generated
	 * @ordered
	 */
	protected String shape_dist_traveled = SHAPE_DIST_TRAVELED_EDEFAULT;

	/**
	 * The default value of the '{@link #getTimepoint() <em>Timepoint</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimepoint()
	 * @generated
	 * @ordered
	 */
	protected static final TimeAdherence TIMEPOINT_EDEFAULT = TimeAdherence.APPROXIMATE;

	/**
	 * The cached value of the '{@link #getTimepoint() <em>Timepoint</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimepoint()
	 * @generated
	 * @ordered
	 */
	protected TimeAdherence timepoint = TIMEPOINT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Stop_timeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.STOP_TIME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getArrival_time() {
		return arrival_time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArrival_time(String newArrival_time) {
		String oldArrival_time = arrival_time;
		arrival_time = newArrival_time;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME,
					oldArrival_time, arrival_time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDeparture_time() {
		return departure_time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeparture_time(String newDeparture_time) {
		String oldDeparture_time = departure_time;
		departure_time = newDeparture_time;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME,
					oldDeparture_time, departure_time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop getStop() {
		if (stop != null && stop.eIsProxy()) {
			InternalEObject oldStop = (InternalEObject) stop;
			stop = (Stop) eResolveProxy(oldStop);
			if (stop != oldStop) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.STOP_TIME__STOP,
							oldStop, stop));
			}
		}
		return stop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop basicGetStop() {
		return stop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop(Stop newStop) {
		Stop oldStop = stop;
		stop = newStop;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__STOP, oldStop,
					stop));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getStop_sequence() {
		return stop_sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_sequence(int newStop_sequence) {
		int oldStop_sequence = stop_sequence;
		stop_sequence = newStop_sequence;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE,
					oldStop_sequence, stop_sequence));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStop_headsign() {
		return stop_headsign;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_headsign(String newStop_headsign) {
		String oldStop_headsign = stop_headsign;
		stop_headsign = newStop_headsign;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN,
					oldStop_headsign, stop_headsign));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pickup_Drop_off_Type getPickup_type() {
		return pickup_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPickup_type(Pickup_Drop_off_Type newPickup_type) {
		Pickup_Drop_off_Type oldPickup_type = pickup_type;
		pickup_type = newPickup_type == null ? PICKUP_TYPE_EDEFAULT : newPickup_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE,
					oldPickup_type, pickup_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pickup_Drop_off_Type getDrop_off_type() {
		return drop_off_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDrop_off_type(Pickup_Drop_off_Type newDrop_off_type) {
		Pickup_Drop_off_Type oldDrop_off_type = drop_off_type;
		drop_off_type = newDrop_off_type == null ? DROP_OFF_TYPE_EDEFAULT : newDrop_off_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE,
					oldDrop_off_type, drop_off_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getShape_dist_traveled() {
		return shape_dist_traveled;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setShape_dist_traveled(String newShape_dist_traveled) {
		String oldShape_dist_traveled = shape_dist_traveled;
		shape_dist_traveled = newShape_dist_traveled;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED, oldShape_dist_traveled,
					shape_dist_traveled));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TimeAdherence getTimepoint() {
		return timepoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimepoint(TimeAdherence newTimepoint) {
		TimeAdherence oldTimepoint = timepoint;
		timepoint = newTimepoint == null ? TIMEPOINT_EDEFAULT : newTimepoint;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP_TIME__TIMEPOINT,
					oldTimepoint, timepoint));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME:
			return getArrival_time();
		case MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME:
			return getDeparture_time();
		case MobilityResourcesPackage.STOP_TIME__STOP:
			if (resolve)
				return getStop();
			return basicGetStop();
		case MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE:
			return getStop_sequence();
		case MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN:
			return getStop_headsign();
		case MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE:
			return getPickup_type();
		case MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE:
			return getDrop_off_type();
		case MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED:
			return getShape_dist_traveled();
		case MobilityResourcesPackage.STOP_TIME__TIMEPOINT:
			return getTimepoint();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME:
			setArrival_time((String) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME:
			setDeparture_time((String) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP:
			setStop((Stop) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE:
			setStop_sequence((Integer) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN:
			setStop_headsign((String) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE:
			setPickup_type((Pickup_Drop_off_Type) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE:
			setDrop_off_type((Pickup_Drop_off_Type) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED:
			setShape_dist_traveled((String) newValue);
			return;
		case MobilityResourcesPackage.STOP_TIME__TIMEPOINT:
			setTimepoint((TimeAdherence) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME:
			setArrival_time(ARRIVAL_TIME_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME:
			setDeparture_time(DEPARTURE_TIME_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP:
			setStop((Stop) null);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE:
			setStop_sequence(STOP_SEQUENCE_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN:
			setStop_headsign(STOP_HEADSIGN_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE:
			setPickup_type(PICKUP_TYPE_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE:
			setDrop_off_type(DROP_OFF_TYPE_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED:
			setShape_dist_traveled(SHAPE_DIST_TRAVELED_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP_TIME__TIMEPOINT:
			setTimepoint(TIMEPOINT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP_TIME__ARRIVAL_TIME:
			return ARRIVAL_TIME_EDEFAULT == null ? arrival_time != null : !ARRIVAL_TIME_EDEFAULT.equals(arrival_time);
		case MobilityResourcesPackage.STOP_TIME__DEPARTURE_TIME:
			return DEPARTURE_TIME_EDEFAULT == null ? departure_time != null
					: !DEPARTURE_TIME_EDEFAULT.equals(departure_time);
		case MobilityResourcesPackage.STOP_TIME__STOP:
			return stop != null;
		case MobilityResourcesPackage.STOP_TIME__STOP_SEQUENCE:
			return stop_sequence != STOP_SEQUENCE_EDEFAULT;
		case MobilityResourcesPackage.STOP_TIME__STOP_HEADSIGN:
			return STOP_HEADSIGN_EDEFAULT == null ? stop_headsign != null
					: !STOP_HEADSIGN_EDEFAULT.equals(stop_headsign);
		case MobilityResourcesPackage.STOP_TIME__PICKUP_TYPE:
			return pickup_type != PICKUP_TYPE_EDEFAULT;
		case MobilityResourcesPackage.STOP_TIME__DROP_OFF_TYPE:
			return drop_off_type != DROP_OFF_TYPE_EDEFAULT;
		case MobilityResourcesPackage.STOP_TIME__SHAPE_DIST_TRAVELED:
			return SHAPE_DIST_TRAVELED_EDEFAULT == null ? shape_dist_traveled != null
					: !SHAPE_DIST_TRAVELED_EDEFAULT.equals(shape_dist_traveled);
		case MobilityResourcesPackage.STOP_TIME__TIMEPOINT:
			return timepoint != TIMEPOINT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (arrival_time: ");
		result.append(arrival_time);
		result.append(", departure_time: ");
		result.append(departure_time);
		result.append(", stop_sequence: ");
		result.append(stop_sequence);
		result.append(", stop_headsign: ");
		result.append(stop_headsign);
		result.append(", pickup_type: ");
		result.append(pickup_type);
		result.append(", drop_off_type: ");
		result.append(drop_off_type);
		result.append(", shape_dist_traveled: ");
		result.append(shape_dist_traveled);
		result.append(", timepoint: ");
		result.append(timepoint);
		result.append(')');
		return result.toString();
	}

} //Stop_timeImpl
