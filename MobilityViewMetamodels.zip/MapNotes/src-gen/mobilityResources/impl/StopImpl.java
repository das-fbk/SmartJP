/**
 */
package mobilityResources.impl;

import mobilityResources.Accessibility;
import mobilityResources.GeographicLocation;
import mobilityResources.Location_Type;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Stop;
import mobilityResources.Zone;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stop</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.StopImpl#getCode <em>Code</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getDesc <em>Desc</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getStop_location <em>Stop location</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getUrl <em>Url</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getLocation_type <em>Location type</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getParent_station <em>Parent station</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getWheelchair_boarding <em>Wheelchair boarding</em>}</li>
 *   <li>{@link mobilityResources.impl.StopImpl#getZone <em>Zone</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StopImpl extends MobilityResourceImpl implements Stop {
	/**
	 * The default value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected static final String CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected String code = CODE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDesc() <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDesc()
	 * @generated
	 * @ordered
	 */
	protected static final String DESC_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDesc() <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDesc()
	 * @generated
	 * @ordered
	 */
	protected String desc = DESC_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStop_location() <em>Stop location</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_location()
	 * @generated
	 * @ordered
	 */
	protected GeographicLocation stop_location;

	/**
	 * The default value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected static final String URL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected String url = URL_EDEFAULT;

	/**
	 * The default value of the '{@link #getLocation_type() <em>Location type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation_type()
	 * @generated
	 * @ordered
	 */
	protected static final Location_Type LOCATION_TYPE_EDEFAULT = Location_Type.STOP;

	/**
	 * The cached value of the '{@link #getLocation_type() <em>Location type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation_type()
	 * @generated
	 * @ordered
	 */
	protected Location_Type location_type = LOCATION_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getParent_station() <em>Parent station</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParent_station()
	 * @generated
	 * @ordered
	 */
	protected static final String PARENT_STATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getParent_station() <em>Parent station</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParent_station()
	 * @generated
	 * @ordered
	 */
	protected String parent_station = PARENT_STATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getWheelchair_boarding() <em>Wheelchair boarding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWheelchair_boarding()
	 * @generated
	 * @ordered
	 */
	protected static final Accessibility WHEELCHAIR_BOARDING_EDEFAULT = Accessibility.UNKNOWN;

	/**
	 * The cached value of the '{@link #getWheelchair_boarding() <em>Wheelchair boarding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWheelchair_boarding()
	 * @generated
	 * @ordered
	 */
	protected Accessibility wheelchair_boarding = WHEELCHAIR_BOARDING_EDEFAULT;

	/**
	 * The cached value of the '{@link #getZone() <em>Zone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getZone()
	 * @generated
	 * @ordered
	 */
	protected Zone zone;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.STOP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCode() {
		return code;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCode(String newCode) {
		String oldCode = code;
		code = newCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__CODE, oldCode, code));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDesc(String newDesc) {
		String oldDesc = desc;
		desc = newDesc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__DESC, oldDesc, desc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GeographicLocation getStop_location() {
		if (stop_location != null && stop_location.eIsProxy()) {
			InternalEObject oldStop_location = (InternalEObject) stop_location;
			stop_location = (GeographicLocation) eResolveProxy(oldStop_location);
			if (stop_location != oldStop_location) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.STOP__STOP_LOCATION, oldStop_location, stop_location));
			}
		}
		return stop_location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GeographicLocation basicGetStop_location() {
		return stop_location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStop_location(GeographicLocation newStop_location, NotificationChain msgs) {
		GeographicLocation oldStop_location = stop_location;
		stop_location = newStop_location;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.STOP__STOP_LOCATION, oldStop_location, newStop_location);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_location(GeographicLocation newStop_location) {
		if (newStop_location != stop_location) {
			NotificationChain msgs = null;
			if (stop_location != null)
				msgs = ((InternalEObject) stop_location).eInverseRemove(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP, GeographicLocation.class, msgs);
			if (newStop_location != null)
				msgs = ((InternalEObject) newStop_location).eInverseAdd(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP, GeographicLocation.class, msgs);
			msgs = basicSetStop_location(newStop_location, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__STOP_LOCATION,
					newStop_location, newStop_location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUrl(String newUrl) {
		String oldUrl = url;
		url = newUrl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__URL, oldUrl, url));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location_Type getLocation_type() {
		return location_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation_type(Location_Type newLocation_type) {
		Location_Type oldLocation_type = location_type;
		location_type = newLocation_type == null ? LOCATION_TYPE_EDEFAULT : newLocation_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__LOCATION_TYPE,
					oldLocation_type, location_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getParent_station() {
		return parent_station;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParent_station(String newParent_station) {
		String oldParent_station = parent_station;
		parent_station = newParent_station;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__PARENT_STATION,
					oldParent_station, parent_station));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Accessibility getWheelchair_boarding() {
		return wheelchair_boarding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWheelchair_boarding(Accessibility newWheelchair_boarding) {
		Accessibility oldWheelchair_boarding = wheelchair_boarding;
		wheelchair_boarding = newWheelchair_boarding == null ? WHEELCHAIR_BOARDING_EDEFAULT : newWheelchair_boarding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__WHEELCHAIR_BOARDING,
					oldWheelchair_boarding, wheelchair_boarding));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone getZone() {
		if (zone != null && zone.eIsProxy()) {
			InternalEObject oldZone = (InternalEObject) zone;
			zone = (Zone) eResolveProxy(oldZone);
			if (zone != oldZone) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.STOP__ZONE,
							oldZone, zone));
			}
		}
		return zone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone basicGetZone() {
		return zone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetZone(Zone newZone, NotificationChain msgs) {
		Zone oldZone = zone;
		zone = newZone;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.STOP__ZONE, oldZone, newZone);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setZone(Zone newZone) {
		if (newZone != zone) {
			NotificationChain msgs = null;
			if (zone != null)
				msgs = ((InternalEObject) zone).eInverseRemove(this, MobilityResourcesPackage.ZONE__STOPS, Zone.class,
						msgs);
			if (newZone != null)
				msgs = ((InternalEObject) newZone).eInverseAdd(this, MobilityResourcesPackage.ZONE__STOPS, Zone.class,
						msgs);
			msgs = basicSetZone(newZone, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.STOP__ZONE, newZone,
					newZone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			if (stop_location != null)
				msgs = ((InternalEObject) stop_location).eInverseRemove(this,
						MobilityResourcesPackage.GEOGRAPHIC_LOCATION__STOP, GeographicLocation.class, msgs);
			return basicSetStop_location((GeographicLocation) otherEnd, msgs);
		case MobilityResourcesPackage.STOP__ZONE:
			if (zone != null)
				msgs = ((InternalEObject) zone).eInverseRemove(this, MobilityResourcesPackage.ZONE__STOPS, Zone.class,
						msgs);
			return basicSetZone((Zone) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			return basicSetStop_location(null, msgs);
		case MobilityResourcesPackage.STOP__ZONE:
			return basicSetZone(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__CODE:
			return getCode();
		case MobilityResourcesPackage.STOP__DESC:
			return getDesc();
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			if (resolve)
				return getStop_location();
			return basicGetStop_location();
		case MobilityResourcesPackage.STOP__URL:
			return getUrl();
		case MobilityResourcesPackage.STOP__LOCATION_TYPE:
			return getLocation_type();
		case MobilityResourcesPackage.STOP__PARENT_STATION:
			return getParent_station();
		case MobilityResourcesPackage.STOP__WHEELCHAIR_BOARDING:
			return getWheelchair_boarding();
		case MobilityResourcesPackage.STOP__ZONE:
			if (resolve)
				return getZone();
			return basicGetZone();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__CODE:
			setCode((String) newValue);
			return;
		case MobilityResourcesPackage.STOP__DESC:
			setDesc((String) newValue);
			return;
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			setStop_location((GeographicLocation) newValue);
			return;
		case MobilityResourcesPackage.STOP__URL:
			setUrl((String) newValue);
			return;
		case MobilityResourcesPackage.STOP__LOCATION_TYPE:
			setLocation_type((Location_Type) newValue);
			return;
		case MobilityResourcesPackage.STOP__PARENT_STATION:
			setParent_station((String) newValue);
			return;
		case MobilityResourcesPackage.STOP__WHEELCHAIR_BOARDING:
			setWheelchair_boarding((Accessibility) newValue);
			return;
		case MobilityResourcesPackage.STOP__ZONE:
			setZone((Zone) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__CODE:
			setCode(CODE_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__DESC:
			setDesc(DESC_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			setStop_location((GeographicLocation) null);
			return;
		case MobilityResourcesPackage.STOP__URL:
			setUrl(URL_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__LOCATION_TYPE:
			setLocation_type(LOCATION_TYPE_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__PARENT_STATION:
			setParent_station(PARENT_STATION_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__WHEELCHAIR_BOARDING:
			setWheelchair_boarding(WHEELCHAIR_BOARDING_EDEFAULT);
			return;
		case MobilityResourcesPackage.STOP__ZONE:
			setZone((Zone) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.STOP__CODE:
			return CODE_EDEFAULT == null ? code != null : !CODE_EDEFAULT.equals(code);
		case MobilityResourcesPackage.STOP__DESC:
			return DESC_EDEFAULT == null ? desc != null : !DESC_EDEFAULT.equals(desc);
		case MobilityResourcesPackage.STOP__STOP_LOCATION:
			return stop_location != null;
		case MobilityResourcesPackage.STOP__URL:
			return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
		case MobilityResourcesPackage.STOP__LOCATION_TYPE:
			return location_type != LOCATION_TYPE_EDEFAULT;
		case MobilityResourcesPackage.STOP__PARENT_STATION:
			return PARENT_STATION_EDEFAULT == null ? parent_station != null
					: !PARENT_STATION_EDEFAULT.equals(parent_station);
		case MobilityResourcesPackage.STOP__WHEELCHAIR_BOARDING:
			return wheelchair_boarding != WHEELCHAIR_BOARDING_EDEFAULT;
		case MobilityResourcesPackage.STOP__ZONE:
			return zone != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (code: ");
		result.append(code);
		result.append(", desc: ");
		result.append(desc);
		result.append(", url: ");
		result.append(url);
		result.append(", location_type: ");
		result.append(location_type);
		result.append(", parent_station: ");
		result.append(parent_station);
		result.append(", wheelchair_boarding: ");
		result.append(wheelchair_boarding);
		result.append(')');
		return result.toString();
	}

} //StopImpl
