/**
 */
package mobilityResources.impl;

import mobilityResources.Fare_attribute;
import mobilityResources.Fare_rule;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Route;
import mobilityResources.Zone;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fare rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.Fare_ruleImpl#getFare <em>Fare</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_ruleImpl#getRoute <em>Route</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_ruleImpl#getOrigin <em>Origin</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_ruleImpl#getDestination <em>Destination</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_ruleImpl#getContains <em>Contains</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Fare_ruleImpl extends MinimalEObjectImpl.Container implements Fare_rule {
	/**
	 * The cached value of the '{@link #getFare() <em>Fare</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare()
	 * @generated
	 * @ordered
	 */
	protected Fare_attribute fare;

	/**
	 * The cached value of the '{@link #getRoute() <em>Route</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute()
	 * @generated
	 * @ordered
	 */
	protected Route route;

	/**
	 * The cached value of the '{@link #getOrigin() <em>Origin</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrigin()
	 * @generated
	 * @ordered
	 */
	protected Zone origin;

	/**
	 * The cached value of the '{@link #getDestination() <em>Destination</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestination()
	 * @generated
	 * @ordered
	 */
	protected Zone destination;

	/**
	 * The cached value of the '{@link #getContains() <em>Contains</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains()
	 * @generated
	 * @ordered
	 */
	protected Zone contains;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Fare_ruleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.FARE_RULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_attribute getFare() {
		if (fare != null && fare.eIsProxy()) {
			InternalEObject oldFare = (InternalEObject) fare;
			fare = (Fare_attribute) eResolveProxy(oldFare);
			if (fare != oldFare) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.FARE_RULE__FARE,
							oldFare, fare));
			}
		}
		return fare;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_attribute basicGetFare() {
		return fare;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFare(Fare_attribute newFare, NotificationChain msgs) {
		Fare_attribute oldFare = fare;
		fare = newFare;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_RULE__FARE, oldFare, newFare);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFare(Fare_attribute newFare) {
		if (newFare != fare) {
			NotificationChain msgs = null;
			if (fare != null)
				msgs = ((InternalEObject) fare).eInverseRemove(this,
						MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES, Fare_attribute.class, msgs);
			if (newFare != null)
				msgs = ((InternalEObject) newFare).eInverseAdd(this,
						MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES, Fare_attribute.class, msgs);
			msgs = basicSetFare(newFare, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_RULE__FARE, newFare,
					newFare));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route getRoute() {
		if (route != null && route.eIsProxy()) {
			InternalEObject oldRoute = (InternalEObject) route;
			route = (Route) eResolveProxy(oldRoute);
			if (route != oldRoute) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.FARE_RULE__ROUTE,
							oldRoute, route));
			}
		}
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route basicGetRoute() {
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRoute(Route newRoute, NotificationChain msgs) {
		Route oldRoute = route;
		route = newRoute;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_RULE__ROUTE, oldRoute, newRoute);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute(Route newRoute) {
		if (newRoute != route) {
			NotificationChain msgs = null;
			if (route != null)
				msgs = ((InternalEObject) route).eInverseRemove(this, MobilityResourcesPackage.ROUTE__FARE_RULES,
						Route.class, msgs);
			if (newRoute != null)
				msgs = ((InternalEObject) newRoute).eInverseAdd(this, MobilityResourcesPackage.ROUTE__FARE_RULES,
						Route.class, msgs);
			msgs = basicSetRoute(newRoute, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_RULE__ROUTE, newRoute,
					newRoute));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone getOrigin() {
		if (origin != null && origin.eIsProxy()) {
			InternalEObject oldOrigin = (InternalEObject) origin;
			origin = (Zone) eResolveProxy(oldOrigin);
			if (origin != oldOrigin) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.FARE_RULE__ORIGIN, oldOrigin, origin));
			}
		}
		return origin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone basicGetOrigin() {
		return origin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOrigin(Zone newOrigin, NotificationChain msgs) {
		Zone oldOrigin = origin;
		origin = newOrigin;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_RULE__ORIGIN, oldOrigin, newOrigin);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOrigin(Zone newOrigin) {
		if (newOrigin != origin) {
			NotificationChain msgs = null;
			if (origin != null)
				msgs = ((InternalEObject) origin).eInverseRemove(this, MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES,
						Zone.class, msgs);
			if (newOrigin != null)
				msgs = ((InternalEObject) newOrigin).eInverseAdd(this, MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES,
						Zone.class, msgs);
			msgs = basicSetOrigin(newOrigin, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_RULE__ORIGIN, newOrigin,
					newOrigin));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone getDestination() {
		if (destination != null && destination.eIsProxy()) {
			InternalEObject oldDestination = (InternalEObject) destination;
			destination = (Zone) eResolveProxy(oldDestination);
			if (destination != oldDestination) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.FARE_RULE__DESTINATION, oldDestination, destination));
			}
		}
		return destination;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone basicGetDestination() {
		return destination;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDestination(Zone newDestination, NotificationChain msgs) {
		Zone oldDestination = destination;
		destination = newDestination;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_RULE__DESTINATION, oldDestination, newDestination);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDestination(Zone newDestination) {
		if (newDestination != destination) {
			NotificationChain msgs = null;
			if (destination != null)
				msgs = ((InternalEObject) destination).eInverseRemove(this,
						MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES, Zone.class, msgs);
			if (newDestination != null)
				msgs = ((InternalEObject) newDestination).eInverseAdd(this,
						MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES, Zone.class, msgs);
			msgs = basicSetDestination(newDestination, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_RULE__DESTINATION,
					newDestination, newDestination));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone getContains() {
		if (contains != null && contains.eIsProxy()) {
			InternalEObject oldContains = (InternalEObject) contains;
			contains = (Zone) eResolveProxy(oldContains);
			if (contains != oldContains) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.FARE_RULE__CONTAINS, oldContains, contains));
			}
		}
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone basicGetContains() {
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetContains(Zone newContains, NotificationChain msgs) {
		Zone oldContains = contains;
		contains = newContains;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_RULE__CONTAINS, oldContains, newContains);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContains(Zone newContains) {
		if (newContains != contains) {
			NotificationChain msgs = null;
			if (contains != null)
				msgs = ((InternalEObject) contains).eInverseRemove(this,
						MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES, Zone.class, msgs);
			if (newContains != null)
				msgs = ((InternalEObject) newContains).eInverseAdd(this,
						MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES, Zone.class, msgs);
			msgs = basicSetContains(newContains, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_RULE__CONTAINS,
					newContains, newContains));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			if (fare != null)
				msgs = ((InternalEObject) fare).eInverseRemove(this,
						MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES, Fare_attribute.class, msgs);
			return basicSetFare((Fare_attribute) otherEnd, msgs);
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			if (route != null)
				msgs = ((InternalEObject) route).eInverseRemove(this, MobilityResourcesPackage.ROUTE__FARE_RULES,
						Route.class, msgs);
			return basicSetRoute((Route) otherEnd, msgs);
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			if (origin != null)
				msgs = ((InternalEObject) origin).eInverseRemove(this, MobilityResourcesPackage.ZONE__ORIGIN_FARE_RULES,
						Zone.class, msgs);
			return basicSetOrigin((Zone) otherEnd, msgs);
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			if (destination != null)
				msgs = ((InternalEObject) destination).eInverseRemove(this,
						MobilityResourcesPackage.ZONE__DESTINATION_FARE_RULES, Zone.class, msgs);
			return basicSetDestination((Zone) otherEnd, msgs);
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			if (contains != null)
				msgs = ((InternalEObject) contains).eInverseRemove(this,
						MobilityResourcesPackage.ZONE__CONTAINS_FARE_RULES, Zone.class, msgs);
			return basicSetContains((Zone) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			return basicSetFare(null, msgs);
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			return basicSetRoute(null, msgs);
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			return basicSetOrigin(null, msgs);
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			return basicSetDestination(null, msgs);
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			return basicSetContains(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			if (resolve)
				return getFare();
			return basicGetFare();
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			if (resolve)
				return getRoute();
			return basicGetRoute();
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			if (resolve)
				return getOrigin();
			return basicGetOrigin();
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			if (resolve)
				return getDestination();
			return basicGetDestination();
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			if (resolve)
				return getContains();
			return basicGetContains();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			setFare((Fare_attribute) newValue);
			return;
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			setRoute((Route) newValue);
			return;
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			setOrigin((Zone) newValue);
			return;
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			setDestination((Zone) newValue);
			return;
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			setContains((Zone) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			setFare((Fare_attribute) null);
			return;
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			setRoute((Route) null);
			return;
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			setOrigin((Zone) null);
			return;
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			setDestination((Zone) null);
			return;
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			setContains((Zone) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_RULE__FARE:
			return fare != null;
		case MobilityResourcesPackage.FARE_RULE__ROUTE:
			return route != null;
		case MobilityResourcesPackage.FARE_RULE__ORIGIN:
			return origin != null;
		case MobilityResourcesPackage.FARE_RULE__DESTINATION:
			return destination != null;
		case MobilityResourcesPackage.FARE_RULE__CONTAINS:
			return contains != null;
		}
		return super.eIsSet(featureID);
	}

} //Fare_ruleImpl
