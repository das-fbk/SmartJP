/**
 */
package mobilityResources.impl;

import mobilityResources.Availability;
import mobilityResources.Calendar;
import mobilityResources.MobilityResourcesPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Calendar</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getService_id <em>Service id</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getMonday <em>Monday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getTuesday <em>Tuesday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getWednesday <em>Wednesday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getThursday <em>Thursday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getFriday <em>Friday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getSaturday <em>Saturday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getSunday <em>Sunday</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getStart_date <em>Start date</em>}</li>
 *   <li>{@link mobilityResources.impl.CalendarImpl#getEnd_date <em>End date</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CalendarImpl extends MinimalEObjectImpl.Container implements Calendar {
	/**
	 * The default value of the '{@link #getService_id() <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService_id()
	 * @generated
	 * @ordered
	 */
	protected static final String SERVICE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getService_id() <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService_id()
	 * @generated
	 * @ordered
	 */
	protected String service_id = SERVICE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getMonday() <em>Monday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability MONDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getMonday() <em>Monday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMonday()
	 * @generated
	 * @ordered
	 */
	protected Availability monday = MONDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getTuesday() <em>Tuesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTuesday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability TUESDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getTuesday() <em>Tuesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTuesday()
	 * @generated
	 * @ordered
	 */
	protected Availability tuesday = TUESDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getWednesday() <em>Wednesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWednesday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability WEDNESDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getWednesday() <em>Wednesday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWednesday()
	 * @generated
	 * @ordered
	 */
	protected Availability wednesday = WEDNESDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getThursday() <em>Thursday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThursday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability THURSDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getThursday() <em>Thursday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThursday()
	 * @generated
	 * @ordered
	 */
	protected Availability thursday = THURSDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getFriday() <em>Friday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFriday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability FRIDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getFriday() <em>Friday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFriday()
	 * @generated
	 * @ordered
	 */
	protected Availability friday = FRIDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getSaturday() <em>Saturday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSaturday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability SATURDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getSaturday() <em>Saturday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSaturday()
	 * @generated
	 * @ordered
	 */
	protected Availability saturday = SATURDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getSunday() <em>Sunday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSunday()
	 * @generated
	 * @ordered
	 */
	protected static final Availability SUNDAY_EDEFAULT = Availability.NOT_AVAILABLE;

	/**
	 * The cached value of the '{@link #getSunday() <em>Sunday</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSunday()
	 * @generated
	 * @ordered
	 */
	protected Availability sunday = SUNDAY_EDEFAULT;

	/**
	 * The default value of the '{@link #getStart_date() <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_date()
	 * @generated
	 * @ordered
	 */
	protected static final String START_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStart_date() <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_date()
	 * @generated
	 * @ordered
	 */
	protected String start_date = START_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnd_date() <em>End date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnd_date()
	 * @generated
	 * @ordered
	 */
	protected static final String END_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEnd_date() <em>End date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnd_date()
	 * @generated
	 * @ordered
	 */
	protected String end_date = END_DATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CalendarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.CALENDAR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getService_id() {
		return service_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setService_id(String newService_id) {
		String oldService_id = service_id;
		service_id = newService_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__SERVICE_ID,
					oldService_id, service_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getMonday() {
		return monday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMonday(Availability newMonday) {
		Availability oldMonday = monday;
		monday = newMonday == null ? MONDAY_EDEFAULT : newMonday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__MONDAY, oldMonday,
					monday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getTuesday() {
		return tuesday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTuesday(Availability newTuesday) {
		Availability oldTuesday = tuesday;
		tuesday = newTuesday == null ? TUESDAY_EDEFAULT : newTuesday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__TUESDAY,
					oldTuesday, tuesday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getWednesday() {
		return wednesday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWednesday(Availability newWednesday) {
		Availability oldWednesday = wednesday;
		wednesday = newWednesday == null ? WEDNESDAY_EDEFAULT : newWednesday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__WEDNESDAY,
					oldWednesday, wednesday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getThursday() {
		return thursday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThursday(Availability newThursday) {
		Availability oldThursday = thursday;
		thursday = newThursday == null ? THURSDAY_EDEFAULT : newThursday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__THURSDAY,
					oldThursday, thursday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getFriday() {
		return friday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFriday(Availability newFriday) {
		Availability oldFriday = friday;
		friday = newFriday == null ? FRIDAY_EDEFAULT : newFriday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__FRIDAY, oldFriday,
					friday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getSaturday() {
		return saturday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSaturday(Availability newSaturday) {
		Availability oldSaturday = saturday;
		saturday = newSaturday == null ? SATURDAY_EDEFAULT : newSaturday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__SATURDAY,
					oldSaturday, saturday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability getSunday() {
		return sunday;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSunday(Availability newSunday) {
		Availability oldSunday = sunday;
		sunday = newSunday == null ? SUNDAY_EDEFAULT : newSunday;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__SUNDAY, oldSunday,
					sunday));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStart_date() {
		return start_date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStart_date(String newStart_date) {
		String oldStart_date = start_date;
		start_date = newStart_date;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__START_DATE,
					oldStart_date, start_date));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEnd_date() {
		return end_date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnd_date(String newEnd_date) {
		String oldEnd_date = end_date;
		end_date = newEnd_date;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR__END_DATE,
					oldEnd_date, end_date));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR__SERVICE_ID:
			return getService_id();
		case MobilityResourcesPackage.CALENDAR__MONDAY:
			return getMonday();
		case MobilityResourcesPackage.CALENDAR__TUESDAY:
			return getTuesday();
		case MobilityResourcesPackage.CALENDAR__WEDNESDAY:
			return getWednesday();
		case MobilityResourcesPackage.CALENDAR__THURSDAY:
			return getThursday();
		case MobilityResourcesPackage.CALENDAR__FRIDAY:
			return getFriday();
		case MobilityResourcesPackage.CALENDAR__SATURDAY:
			return getSaturday();
		case MobilityResourcesPackage.CALENDAR__SUNDAY:
			return getSunday();
		case MobilityResourcesPackage.CALENDAR__START_DATE:
			return getStart_date();
		case MobilityResourcesPackage.CALENDAR__END_DATE:
			return getEnd_date();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR__SERVICE_ID:
			setService_id((String) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__MONDAY:
			setMonday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__TUESDAY:
			setTuesday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__WEDNESDAY:
			setWednesday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__THURSDAY:
			setThursday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__FRIDAY:
			setFriday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__SATURDAY:
			setSaturday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__SUNDAY:
			setSunday((Availability) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__START_DATE:
			setStart_date((String) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR__END_DATE:
			setEnd_date((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR__SERVICE_ID:
			setService_id(SERVICE_ID_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__MONDAY:
			setMonday(MONDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__TUESDAY:
			setTuesday(TUESDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__WEDNESDAY:
			setWednesday(WEDNESDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__THURSDAY:
			setThursday(THURSDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__FRIDAY:
			setFriday(FRIDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__SATURDAY:
			setSaturday(SATURDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__SUNDAY:
			setSunday(SUNDAY_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__START_DATE:
			setStart_date(START_DATE_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR__END_DATE:
			setEnd_date(END_DATE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR__SERVICE_ID:
			return SERVICE_ID_EDEFAULT == null ? service_id != null : !SERVICE_ID_EDEFAULT.equals(service_id);
		case MobilityResourcesPackage.CALENDAR__MONDAY:
			return monday != MONDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__TUESDAY:
			return tuesday != TUESDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__WEDNESDAY:
			return wednesday != WEDNESDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__THURSDAY:
			return thursday != THURSDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__FRIDAY:
			return friday != FRIDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__SATURDAY:
			return saturday != SATURDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__SUNDAY:
			return sunday != SUNDAY_EDEFAULT;
		case MobilityResourcesPackage.CALENDAR__START_DATE:
			return START_DATE_EDEFAULT == null ? start_date != null : !START_DATE_EDEFAULT.equals(start_date);
		case MobilityResourcesPackage.CALENDAR__END_DATE:
			return END_DATE_EDEFAULT == null ? end_date != null : !END_DATE_EDEFAULT.equals(end_date);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (service_id: ");
		result.append(service_id);
		result.append(", monday: ");
		result.append(monday);
		result.append(", tuesday: ");
		result.append(tuesday);
		result.append(", wednesday: ");
		result.append(wednesday);
		result.append(", thursday: ");
		result.append(thursday);
		result.append(", friday: ");
		result.append(friday);
		result.append(", saturday: ");
		result.append(saturday);
		result.append(", sunday: ");
		result.append(sunday);
		result.append(", start_date: ");
		result.append(start_date);
		result.append(", end_date: ");
		result.append(end_date);
		result.append(')');
		return result.toString();
	}

} //CalendarImpl
