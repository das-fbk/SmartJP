/**
 */
package mobilityResources.impl;

import mapNotes.MapNotesPackage;

import mapNotes.impl.MapNotesPackageImpl;

import mobilityResources.Accessibility;
import mobilityResources.Agency;
import mobilityResources.Allowed_transfers;
import mobilityResources.Availability;
import mobilityResources.BikeSharing;
import mobilityResources.Block;
import mobilityResources.Calendar;
import mobilityResources.Calendar_date;
import mobilityResources.Exception_type;
import mobilityResources.Fare_attribute;
import mobilityResources.Fare_rule;
import mobilityResources.GeographicLocation;
import mobilityResources.Location_Type;
import mobilityResources.MobilityResource;
import mobilityResources.MobilityResourcesFactory;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.MobilitySupport;
import mobilityResources.Parking;
import mobilityResources.Payment_method;
import mobilityResources.Pickup_Drop_off_Type;
import mobilityResources.Route;
import mobilityResources.Stop;
import mobilityResources.Stop_time;
import mobilityResources.TimeAdherence;
import mobilityResources.Transit;
import mobilityResources.TransitType;
import mobilityResources.TravelDirection;
import mobilityResources.Trip;
import mobilityResources.Zone;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MobilityResourcesPackageImpl extends EPackageImpl implements MobilityResourcesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mobilitySupportEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mobilityResourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parkingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bikeSharingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geographicLocationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass agencyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stopEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass routeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tripEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass calendarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stop_timeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass calendar_dateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fare_attributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fare_ruleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass zoneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum location_TypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum accessibilityEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum travelDirectionEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum pickup_Drop_off_TypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum timeAdherenceEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum availabilityEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum exception_typeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum payment_methodEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum allowed_transfersEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum transitTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mobilityResources.MobilityResourcesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MobilityResourcesPackageImpl() {
		super(eNS_URI, MobilityResourcesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link MobilityResourcesPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MobilityResourcesPackage init() {
		if (isInited)
			return (MobilityResourcesPackage) EPackage.Registry.INSTANCE.getEPackage(MobilityResourcesPackage.eNS_URI);

		// Obtain or create and register package
		MobilityResourcesPackageImpl theMobilityResourcesPackage = (MobilityResourcesPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof MobilityResourcesPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new MobilityResourcesPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		MapNotesPackageImpl theMapNotesPackage = (MapNotesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(MapNotesPackage.eNS_URI) instanceof MapNotesPackageImpl
						? EPackage.Registry.INSTANCE.getEPackage(MapNotesPackage.eNS_URI)
						: MapNotesPackage.eINSTANCE);

		// Create package meta-data objects
		theMobilityResourcesPackage.createPackageContents();
		theMapNotesPackage.createPackageContents();

		// Initialize created meta-data
		theMobilityResourcesPackage.initializePackageContents();
		theMapNotesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMobilityResourcesPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MobilityResourcesPackage.eNS_URI, theMobilityResourcesPackage);
		return theMobilityResourcesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMobilitySupport() {
		return mobilitySupportEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMobilitySupport_City() {
		return (EAttribute) mobilitySupportEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Mobilityresources() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_GeographicLocations() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Agency() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Stop_times() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Calendar() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Calendar_dates() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Fares() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMobilitySupport_Fare_zones() {
		return (EReference) mobilitySupportEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMobilityResource() {
		return mobilityResourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMobilityResource_Name() {
		return (EAttribute) mobilityResourceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMobilityResource_LastUpdate() {
		return (EAttribute) mobilityResourceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMobilityResource_Id() {
		return (EAttribute) mobilityResourceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getParking() {
		return parkingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParking_Address() {
		return (EAttribute) parkingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParking_Slots() {
		return (EAttribute) parkingEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getParking_TotalSlots() {
		return (EAttribute) parkingEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getParking_Position() {
		return (EReference) parkingEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBikeSharing() {
		return bikeSharingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBikeSharing_Address() {
		return (EAttribute) bikeSharingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBikeSharing_Bikes() {
		return (EAttribute) bikeSharingEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBikeSharing_Slots() {
		return (EAttribute) bikeSharingEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBikeSharing_TotalSlots() {
		return (EAttribute) bikeSharingEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBikeSharing_Position() {
		return (EReference) bikeSharingEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGeographicLocation() {
		return geographicLocationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGeographicLocation_Lon() {
		return (EAttribute) geographicLocationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGeographicLocation_Lat() {
		return (EAttribute) geographicLocationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGeographicLocation_Bikesharing() {
		return (EReference) geographicLocationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGeographicLocation_Parking() {
		return (EReference) geographicLocationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGeographicLocation_Stop() {
		return (EReference) geographicLocationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAgency() {
		return agencyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAgency_Id() {
		return (EAttribute) agencyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAgency_Name() {
		return (EAttribute) agencyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAgency_Url() {
		return (EAttribute) agencyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAgency_Timezone() {
		return (EAttribute) agencyEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAgency_Routes() {
		return (EReference) agencyEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAgency_Fare_attributes() {
		return (EReference) agencyEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransit() {
		return transitEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransit_Route() {
		return (EReference) transitEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransit_Type() {
		return (EAttribute) transitEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStop() {
		return stopEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Code() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Desc() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStop_Stop_location() {
		return (EReference) stopEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Url() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Location_type() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Parent_station() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_Wheelchair_boarding() {
		return (EAttribute) stopEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStop_Zone() {
		return (EReference) stopEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRoute() {
		return routeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRoute_Long_name() {
		return (EAttribute) routeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoute_Agency() {
		return (EReference) routeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRoute_Desc() {
		return (EAttribute) routeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoute_Type() {
		return (EReference) routeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRoute_Url() {
		return (EAttribute) routeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoute_Trips() {
		return (EReference) routeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoute_Fare_rules() {
		return (EReference) routeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTrip() {
		return tripEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrip_Route() {
		return (EReference) tripEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrip_Service() {
		return (EReference) tripEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrip_Headsign() {
		return (EAttribute) tripEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrip_Direction_id() {
		return (EAttribute) tripEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrip_Block() {
		return (EReference) tripEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrip_Wheelchair_accessible() {
		return (EAttribute) tripEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrip_Bikes_allowed() {
		return (EAttribute) tripEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrip_Service_dates() {
		return (EReference) tripEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCalendar() {
		return calendarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Service_id() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Monday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Tuesday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Wednesday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Thursday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Friday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Saturday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Sunday() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_Start_date() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_End_date() {
		return (EAttribute) calendarEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBlock() {
		return blockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBlock_Trips() {
		return (EReference) blockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStop_time() {
		return stop_timeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Arrival_time() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Departure_time() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStop_time_Stop() {
		return (EReference) stop_timeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Stop_sequence() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Stop_headsign() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Pickup_type() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Drop_off_type() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Shape_dist_traveled() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStop_time_Timepoint() {
		return (EAttribute) stop_timeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCalendar_date() {
		return calendar_dateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_date_Service_id() {
		return (EAttribute) calendar_dateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_date_Date() {
		return (EAttribute) calendar_dateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCalendar_date_Exception_type() {
		return (EAttribute) calendar_dateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFare_attribute() {
		return fare_attributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Fare_id() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Price() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Currency_type() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Payment_method() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Transfers() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFare_attribute_Transfer_duration() {
		return (EAttribute) fare_attributeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_attribute_Agency_id() {
		return (EReference) fare_attributeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_attribute_Fare_rules() {
		return (EReference) fare_attributeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFare_rule() {
		return fare_ruleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_rule_Fare() {
		return (EReference) fare_ruleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_rule_Route() {
		return (EReference) fare_ruleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_rule_Origin() {
		return (EReference) fare_ruleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_rule_Destination() {
		return (EReference) fare_ruleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFare_rule_Contains() {
		return (EReference) fare_ruleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getZone() {
		return zoneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getZone_Stops() {
		return (EReference) zoneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getZone_Origin_fare_rules() {
		return (EReference) zoneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getZone_Destination_fare_rules() {
		return (EReference) zoneEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getZone_Contains_fare_rules() {
		return (EReference) zoneEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLocation_Type() {
		return location_TypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAccessibility() {
		return accessibilityEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTravelDirection() {
		return travelDirectionEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPickup_Drop_off_Type() {
		return pickup_Drop_off_TypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTimeAdherence() {
		return timeAdherenceEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAvailability() {
		return availabilityEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getException_type() {
		return exception_typeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPayment_method() {
		return payment_methodEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAllowed_transfers() {
		return allowed_transfersEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTransitType() {
		return transitTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilityResourcesFactory getMobilityResourcesFactory() {
		return (MobilityResourcesFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		mobilitySupportEClass = createEClass(MOBILITY_SUPPORT);
		createEAttribute(mobilitySupportEClass, MOBILITY_SUPPORT__CITY);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__MOBILITYRESOURCES);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__AGENCY);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__STOP_TIMES);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__CALENDAR);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__CALENDAR_DATES);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__FARES);
		createEReference(mobilitySupportEClass, MOBILITY_SUPPORT__FARE_ZONES);

		mobilityResourceEClass = createEClass(MOBILITY_RESOURCE);
		createEAttribute(mobilityResourceEClass, MOBILITY_RESOURCE__NAME);
		createEAttribute(mobilityResourceEClass, MOBILITY_RESOURCE__LAST_UPDATE);
		createEAttribute(mobilityResourceEClass, MOBILITY_RESOURCE__ID);

		parkingEClass = createEClass(PARKING);
		createEAttribute(parkingEClass, PARKING__ADDRESS);
		createEAttribute(parkingEClass, PARKING__SLOTS);
		createEAttribute(parkingEClass, PARKING__TOTAL_SLOTS);
		createEReference(parkingEClass, PARKING__POSITION);

		bikeSharingEClass = createEClass(BIKE_SHARING);
		createEAttribute(bikeSharingEClass, BIKE_SHARING__ADDRESS);
		createEAttribute(bikeSharingEClass, BIKE_SHARING__BIKES);
		createEAttribute(bikeSharingEClass, BIKE_SHARING__SLOTS);
		createEAttribute(bikeSharingEClass, BIKE_SHARING__TOTAL_SLOTS);
		createEReference(bikeSharingEClass, BIKE_SHARING__POSITION);

		geographicLocationEClass = createEClass(GEOGRAPHIC_LOCATION);
		createEAttribute(geographicLocationEClass, GEOGRAPHIC_LOCATION__LON);
		createEAttribute(geographicLocationEClass, GEOGRAPHIC_LOCATION__LAT);
		createEReference(geographicLocationEClass, GEOGRAPHIC_LOCATION__BIKESHARING);
		createEReference(geographicLocationEClass, GEOGRAPHIC_LOCATION__PARKING);
		createEReference(geographicLocationEClass, GEOGRAPHIC_LOCATION__STOP);

		agencyEClass = createEClass(AGENCY);
		createEAttribute(agencyEClass, AGENCY__ID);
		createEAttribute(agencyEClass, AGENCY__NAME);
		createEAttribute(agencyEClass, AGENCY__URL);
		createEAttribute(agencyEClass, AGENCY__TIMEZONE);
		createEReference(agencyEClass, AGENCY__ROUTES);
		createEReference(agencyEClass, AGENCY__FARE_ATTRIBUTES);

		transitEClass = createEClass(TRANSIT);
		createEReference(transitEClass, TRANSIT__ROUTE);
		createEAttribute(transitEClass, TRANSIT__TYPE);

		stopEClass = createEClass(STOP);
		createEAttribute(stopEClass, STOP__CODE);
		createEAttribute(stopEClass, STOP__DESC);
		createEReference(stopEClass, STOP__STOP_LOCATION);
		createEAttribute(stopEClass, STOP__URL);
		createEAttribute(stopEClass, STOP__LOCATION_TYPE);
		createEAttribute(stopEClass, STOP__PARENT_STATION);
		createEAttribute(stopEClass, STOP__WHEELCHAIR_BOARDING);
		createEReference(stopEClass, STOP__ZONE);

		routeEClass = createEClass(ROUTE);
		createEAttribute(routeEClass, ROUTE__LONG_NAME);
		createEReference(routeEClass, ROUTE__AGENCY);
		createEAttribute(routeEClass, ROUTE__DESC);
		createEReference(routeEClass, ROUTE__TYPE);
		createEAttribute(routeEClass, ROUTE__URL);
		createEReference(routeEClass, ROUTE__TRIPS);
		createEReference(routeEClass, ROUTE__FARE_RULES);

		tripEClass = createEClass(TRIP);
		createEReference(tripEClass, TRIP__ROUTE);
		createEReference(tripEClass, TRIP__SERVICE);
		createEAttribute(tripEClass, TRIP__HEADSIGN);
		createEAttribute(tripEClass, TRIP__DIRECTION_ID);
		createEReference(tripEClass, TRIP__BLOCK);
		createEAttribute(tripEClass, TRIP__WHEELCHAIR_ACCESSIBLE);
		createEAttribute(tripEClass, TRIP__BIKES_ALLOWED);
		createEReference(tripEClass, TRIP__SERVICE_DATES);

		calendarEClass = createEClass(CALENDAR);
		createEAttribute(calendarEClass, CALENDAR__SERVICE_ID);
		createEAttribute(calendarEClass, CALENDAR__MONDAY);
		createEAttribute(calendarEClass, CALENDAR__TUESDAY);
		createEAttribute(calendarEClass, CALENDAR__WEDNESDAY);
		createEAttribute(calendarEClass, CALENDAR__THURSDAY);
		createEAttribute(calendarEClass, CALENDAR__FRIDAY);
		createEAttribute(calendarEClass, CALENDAR__SATURDAY);
		createEAttribute(calendarEClass, CALENDAR__SUNDAY);
		createEAttribute(calendarEClass, CALENDAR__START_DATE);
		createEAttribute(calendarEClass, CALENDAR__END_DATE);

		blockEClass = createEClass(BLOCK);
		createEReference(blockEClass, BLOCK__TRIPS);

		stop_timeEClass = createEClass(STOP_TIME);
		createEAttribute(stop_timeEClass, STOP_TIME__ARRIVAL_TIME);
		createEAttribute(stop_timeEClass, STOP_TIME__DEPARTURE_TIME);
		createEReference(stop_timeEClass, STOP_TIME__STOP);
		createEAttribute(stop_timeEClass, STOP_TIME__STOP_SEQUENCE);
		createEAttribute(stop_timeEClass, STOP_TIME__STOP_HEADSIGN);
		createEAttribute(stop_timeEClass, STOP_TIME__PICKUP_TYPE);
		createEAttribute(stop_timeEClass, STOP_TIME__DROP_OFF_TYPE);
		createEAttribute(stop_timeEClass, STOP_TIME__SHAPE_DIST_TRAVELED);
		createEAttribute(stop_timeEClass, STOP_TIME__TIMEPOINT);

		calendar_dateEClass = createEClass(CALENDAR_DATE);
		createEAttribute(calendar_dateEClass, CALENDAR_DATE__SERVICE_ID);
		createEAttribute(calendar_dateEClass, CALENDAR_DATE__DATE);
		createEAttribute(calendar_dateEClass, CALENDAR_DATE__EXCEPTION_TYPE);

		fare_attributeEClass = createEClass(FARE_ATTRIBUTE);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__FARE_ID);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__PRICE);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__CURRENCY_TYPE);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__PAYMENT_METHOD);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__TRANSFERS);
		createEAttribute(fare_attributeEClass, FARE_ATTRIBUTE__TRANSFER_DURATION);
		createEReference(fare_attributeEClass, FARE_ATTRIBUTE__AGENCY_ID);
		createEReference(fare_attributeEClass, FARE_ATTRIBUTE__FARE_RULES);

		fare_ruleEClass = createEClass(FARE_RULE);
		createEReference(fare_ruleEClass, FARE_RULE__FARE);
		createEReference(fare_ruleEClass, FARE_RULE__ROUTE);
		createEReference(fare_ruleEClass, FARE_RULE__ORIGIN);
		createEReference(fare_ruleEClass, FARE_RULE__DESTINATION);
		createEReference(fare_ruleEClass, FARE_RULE__CONTAINS);

		zoneEClass = createEClass(ZONE);
		createEReference(zoneEClass, ZONE__STOPS);
		createEReference(zoneEClass, ZONE__ORIGIN_FARE_RULES);
		createEReference(zoneEClass, ZONE__DESTINATION_FARE_RULES);
		createEReference(zoneEClass, ZONE__CONTAINS_FARE_RULES);

		// Create enums
		location_TypeEEnum = createEEnum(LOCATION_TYPE);
		accessibilityEEnum = createEEnum(ACCESSIBILITY);
		travelDirectionEEnum = createEEnum(TRAVEL_DIRECTION);
		pickup_Drop_off_TypeEEnum = createEEnum(PICKUP_DROP_OFF_TYPE);
		timeAdherenceEEnum = createEEnum(TIME_ADHERENCE);
		availabilityEEnum = createEEnum(AVAILABILITY);
		exception_typeEEnum = createEEnum(EXCEPTION_TYPE);
		payment_methodEEnum = createEEnum(PAYMENT_METHOD);
		allowed_transfersEEnum = createEEnum(ALLOWED_TRANSFERS);
		transitTypeEEnum = createEEnum(TRANSIT_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		parkingEClass.getESuperTypes().add(this.getMobilityResource());
		bikeSharingEClass.getESuperTypes().add(this.getMobilityResource());
		transitEClass.getESuperTypes().add(this.getMobilityResource());
		stopEClass.getESuperTypes().add(this.getMobilityResource());
		routeEClass.getESuperTypes().add(this.getMobilityResource());
		tripEClass.getESuperTypes().add(this.getMobilityResource());
		blockEClass.getESuperTypes().add(this.getMobilityResource());
		zoneEClass.getESuperTypes().add(this.getMobilityResource());

		// Initialize classes, features, and operations; add parameters
		initEClass(mobilitySupportEClass, MobilitySupport.class, "MobilitySupport", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMobilitySupport_City(), ecorePackage.getEString(), "city", null, 0, 1, MobilitySupport.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Mobilityresources(), this.getMobilityResource(), null, "mobilityresources",
				null, 0, -1, MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_GeographicLocations(), this.getGeographicLocation(), null,
				"geographicLocations", null, 0, -1, MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Agency(), this.getAgency(), null, "agency", null, 0, -1,
				MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Stop_times(), this.getStop_time(), null, "stop_times", null, 0, -1,
				MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Calendar(), this.getCalendar(), null, "calendar", null, 0, -1,
				MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Calendar_dates(), this.getCalendar_date(), null, "calendar_dates", null, 0,
				-1, MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Fares(), this.getFare_attribute(), null, "fares", null, 0, -1,
				MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobilitySupport_Fare_zones(), this.getFare_rule(), null, "fare_zones", null, 0, -1,
				MobilitySupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(mobilityResourceEClass, MobilityResource.class, "MobilityResource", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMobilityResource_Name(), ecorePackage.getEString(), "name", null, 0, 1,
				MobilityResource.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getMobilityResource_LastUpdate(), ecorePackage.getEDate(), "lastUpdate", null, 0, 1,
				MobilityResource.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getMobilityResource_Id(), ecorePackage.getEString(), "id", null, 0, 1, MobilityResource.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(parkingEClass, Parking.class, "Parking", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getParking_Address(), ecorePackage.getEString(), "address", null, 0, 1, Parking.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getParking_Slots(), ecorePackage.getEInt(), "slots", null, 0, 1, Parking.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getParking_TotalSlots(), ecorePackage.getEInt(), "totalSlots", null, 0, 1, Parking.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParking_Position(), this.getGeographicLocation(), this.getGeographicLocation_Parking(),
				"position", null, 0, 1, Parking.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(bikeSharingEClass, BikeSharing.class, "BikeSharing", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBikeSharing_Address(), ecorePackage.getEString(), "address", null, 0, 1, BikeSharing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBikeSharing_Bikes(), ecorePackage.getEInt(), "bikes", null, 0, 1, BikeSharing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBikeSharing_Slots(), ecorePackage.getEInt(), "slots", null, 0, 1, BikeSharing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBikeSharing_TotalSlots(), ecorePackage.getEInt(), "totalSlots", null, 0, 1, BikeSharing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBikeSharing_Position(), this.getGeographicLocation(),
				this.getGeographicLocation_Bikesharing(), "position", null, 0, 1, BikeSharing.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(geographicLocationEClass, GeographicLocation.class, "GeographicLocation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGeographicLocation_Lon(), ecorePackage.getEString(), "lon", null, 0, 1,
				GeographicLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGeographicLocation_Lat(), ecorePackage.getEString(), "lat", null, 0, 1,
				GeographicLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getGeographicLocation_Bikesharing(), this.getBikeSharing(), this.getBikeSharing_Position(),
				"bikesharing", null, 0, 1, GeographicLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGeographicLocation_Parking(), this.getParking(), this.getParking_Position(), "parking", null,
				0, 1, GeographicLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGeographicLocation_Stop(), this.getStop(), this.getStop_Stop_location(), "stop", null, 0, 1,
				GeographicLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(agencyEClass, Agency.class, "Agency", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAgency_Id(), ecorePackage.getEString(), "id", null, 0, 1, Agency.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAgency_Name(), ecorePackage.getEString(), "name", null, 0, 1, Agency.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAgency_Url(), ecorePackage.getEString(), "url", null, 0, 1, Agency.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAgency_Timezone(), ecorePackage.getEString(), "timezone", null, 0, 1, Agency.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAgency_Routes(), this.getRoute(), this.getRoute_Agency(), "routes", null, 0, -1, Agency.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAgency_Fare_attributes(), this.getFare_attribute(), this.getFare_attribute_Agency_id(),
				"fare_attributes", null, 0, -1, Agency.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transitEClass, Transit.class, "Transit", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTransit_Route(), this.getRoute(), this.getRoute_Type(), "route", null, 0, 1, Transit.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransit_Type(), this.getTransitType(), "type", null, 0, 1, Transit.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stopEClass, Stop.class, "Stop", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStop_Code(), ecorePackage.getEString(), "code", null, 0, 1, Stop.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_Desc(), ecorePackage.getEString(), "desc", null, 0, 1, Stop.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStop_Stop_location(), this.getGeographicLocation(), this.getGeographicLocation_Stop(),
				"stop_location", null, 0, 1, Stop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_Url(), ecorePackage.getEString(), "url", null, 0, 1, Stop.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_Location_type(), this.getLocation_Type(), "location_type", null, 0, 1, Stop.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_Parent_station(), ecorePackage.getEString(), "parent_station", null, 0, 1, Stop.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_Wheelchair_boarding(), this.getAccessibility(), "wheelchair_boarding", null, 0, 1,
				Stop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getStop_Zone(), this.getZone(), this.getZone_Stops(), "zone", null, 0, 1, Stop.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(routeEClass, Route.class, "Route", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRoute_Long_name(), ecorePackage.getEString(), "long_name", null, 0, 1, Route.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_Agency(), this.getAgency(), this.getAgency_Routes(), "agency", null, 0, -1, Route.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRoute_Desc(), ecorePackage.getEString(), "desc", null, 0, 1, Route.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_Type(), this.getTransit(), this.getTransit_Route(), "type", null, 0, 1, Route.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRoute_Url(), ecorePackage.getEString(), "url", null, 0, 1, Route.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_Trips(), this.getTrip(), this.getTrip_Route(), "trips", null, 0, -1, Route.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoute_Fare_rules(), this.getFare_rule(), this.getFare_rule_Route(), "fare_rules", null, 0, -1,
				Route.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tripEClass, Trip.class, "Trip", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTrip_Route(), this.getRoute(), this.getRoute_Trips(), "route", null, 0, 1, Trip.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrip_Service(), this.getCalendar(), null, "service", null, 0, 1, Trip.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getTrip_Headsign(), ecorePackage.getEString(), "headsign", null, 0, 1, Trip.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrip_Direction_id(), this.getTravelDirection(), "direction_id", null, 0, 1, Trip.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrip_Block(), this.getBlock(), this.getBlock_Trips(), "block", null, 0, 1, Trip.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrip_Wheelchair_accessible(), this.getAccessibility(), "wheelchair_accessible", null, 0, 1,
				Trip.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getTrip_Bikes_allowed(), this.getAccessibility(), "bikes_allowed", null, 0, 1, Trip.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrip_Service_dates(), this.getCalendar_date(), null, "service_dates", null, 0, 1, Trip.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(calendarEClass, Calendar.class, "Calendar", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCalendar_Service_id(), ecorePackage.getEString(), "service_id", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Monday(), this.getAvailability(), "monday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Tuesday(), this.getAvailability(), "tuesday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Wednesday(), this.getAvailability(), "wednesday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Thursday(), this.getAvailability(), "thursday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Friday(), this.getAvailability(), "friday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Saturday(), this.getAvailability(), "saturday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Sunday(), this.getAvailability(), "sunday", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_Start_date(), ecorePackage.getEString(), "start_date", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_End_date(), ecorePackage.getEString(), "end_date", null, 0, 1, Calendar.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(blockEClass, Block.class, "Block", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBlock_Trips(), this.getTrip(), this.getTrip_Block(), "trips", null, 0, -1, Block.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stop_timeEClass, Stop_time.class, "Stop_time", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStop_time_Arrival_time(), ecorePackage.getEString(), "arrival_time", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Departure_time(), ecorePackage.getEString(), "departure_time", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getStop_time_Stop(), this.getStop(), null, "stop", null, 0, 1, Stop_time.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getStop_time_Stop_sequence(), ecorePackage.getEInt(), "stop_sequence", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Stop_headsign(), ecorePackage.getEString(), "stop_headsign", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Pickup_type(), this.getPickup_Drop_off_Type(), "pickup_type", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Drop_off_type(), this.getPickup_Drop_off_Type(), "drop_off_type", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Shape_dist_traveled(), ecorePackage.getEString(), "shape_dist_traveled", null, 0, 1,
				Stop_time.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getStop_time_Timepoint(), this.getTimeAdherence(), "timepoint", null, 0, 1, Stop_time.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(calendar_dateEClass, Calendar_date.class, "Calendar_date", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCalendar_date_Service_id(), ecorePackage.getEString(), "service_id", null, 0, 1,
				Calendar_date.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_date_Date(), ecorePackage.getEString(), "date", null, 0, 1, Calendar_date.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCalendar_date_Exception_type(), this.getException_type(), "exception_type", null, 0, 1,
				Calendar_date.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(fare_attributeEClass, Fare_attribute.class, "Fare_attribute", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFare_attribute_Fare_id(), ecorePackage.getEString(), "fare_id", null, 0, 1,
				Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getFare_attribute_Price(), ecorePackage.getEDouble(), "price", null, 0, 1, Fare_attribute.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFare_attribute_Currency_type(), ecorePackage.getEString(), "currency_type", null, 0, 1,
				Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getFare_attribute_Payment_method(), this.getPayment_method(), "payment_method", null, 0, 1,
				Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getFare_attribute_Transfers(), this.getAllowed_transfers(), "transfers", null, 0, 1,
				Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getFare_attribute_Transfer_duration(), ecorePackage.getEInt(), "transfer_duration", null, 0, 1,
				Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getFare_attribute_Agency_id(), this.getAgency(), this.getAgency_Fare_attributes(), "agency_id",
				null, 0, 1, Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFare_attribute_Fare_rules(), this.getFare_rule(), this.getFare_rule_Fare(), "fare_rules",
				null, 0, -1, Fare_attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(fare_ruleEClass, Fare_rule.class, "Fare_rule", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFare_rule_Fare(), this.getFare_attribute(), this.getFare_attribute_Fare_rules(), "fare", null,
				0, 1, Fare_rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFare_rule_Route(), this.getRoute(), this.getRoute_Fare_rules(), "route", null, 0, 1,
				Fare_rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFare_rule_Origin(), this.getZone(), this.getZone_Origin_fare_rules(), "origin", null, 0, 1,
				Fare_rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFare_rule_Destination(), this.getZone(), this.getZone_Destination_fare_rules(), "destination",
				null, 0, 1, Fare_rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFare_rule_Contains(), this.getZone(), this.getZone_Contains_fare_rules(), "contains", null, 0,
				1, Fare_rule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(zoneEClass, Zone.class, "Zone", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getZone_Stops(), this.getStop(), this.getStop_Zone(), "stops", null, 0, -1, Zone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getZone_Origin_fare_rules(), this.getFare_rule(), this.getFare_rule_Origin(),
				"origin_fare_rules", null, 0, -1, Zone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getZone_Destination_fare_rules(), this.getFare_rule(), this.getFare_rule_Destination(),
				"destination_fare_rules", null, 0, -1, Zone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getZone_Contains_fare_rules(), this.getFare_rule(), this.getFare_rule_Contains(),
				"contains_fare_rules", null, 0, 1, Zone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(location_TypeEEnum, Location_Type.class, "Location_Type");
		addEEnumLiteral(location_TypeEEnum, Location_Type.STOP);
		addEEnumLiteral(location_TypeEEnum, Location_Type.STATION);
		addEEnumLiteral(location_TypeEEnum, Location_Type.STATION_ENTRANCE_EXIT);

		initEEnum(accessibilityEEnum, Accessibility.class, "Accessibility");
		addEEnumLiteral(accessibilityEEnum, Accessibility.UNKNOWN);
		addEEnumLiteral(accessibilityEEnum, Accessibility.ACCESSIBLE);
		addEEnumLiteral(accessibilityEEnum, Accessibility.NON_ACCESSIBLE);

		initEEnum(travelDirectionEEnum, TravelDirection.class, "TravelDirection");
		addEEnumLiteral(travelDirectionEEnum, TravelDirection.OUTBOUND);
		addEEnumLiteral(travelDirectionEEnum, TravelDirection.INBOUND);

		initEEnum(pickup_Drop_off_TypeEEnum, Pickup_Drop_off_Type.class, "Pickup_Drop_off_Type");
		addEEnumLiteral(pickup_Drop_off_TypeEEnum, Pickup_Drop_off_Type.REGULARLY_SCHEDULED);
		addEEnumLiteral(pickup_Drop_off_TypeEEnum, Pickup_Drop_off_Type.NOT_AVAILABLE);
		addEEnumLiteral(pickup_Drop_off_TypeEEnum, Pickup_Drop_off_Type.PHONE_AGENCY);
		addEEnumLiteral(pickup_Drop_off_TypeEEnum, Pickup_Drop_off_Type.COORDINATE_WITH_DRIVER);

		initEEnum(timeAdherenceEEnum, TimeAdherence.class, "TimeAdherence");
		addEEnumLiteral(timeAdherenceEEnum, TimeAdherence.APPROXIMATE);
		addEEnumLiteral(timeAdherenceEEnum, TimeAdherence.EXACT);

		initEEnum(availabilityEEnum, Availability.class, "Availability");
		addEEnumLiteral(availabilityEEnum, Availability.NOT_AVAILABLE);
		addEEnumLiteral(availabilityEEnum, Availability.AVAILABLE);

		initEEnum(exception_typeEEnum, Exception_type.class, "Exception_type");
		addEEnumLiteral(exception_typeEEnum, Exception_type.SERVICE_ADDED);
		addEEnumLiteral(exception_typeEEnum, Exception_type.SERVICE_REMOVED);

		initEEnum(payment_methodEEnum, Payment_method.class, "Payment_method");
		addEEnumLiteral(payment_methodEEnum, Payment_method.ON_BOARD);
		addEEnumLiteral(payment_methodEEnum, Payment_method.BEFORE_BOARDING);

		initEEnum(allowed_transfersEEnum, Allowed_transfers.class, "Allowed_transfers");
		addEEnumLiteral(allowed_transfersEEnum, Allowed_transfers.NO_TRANSFERS);
		addEEnumLiteral(allowed_transfersEEnum, Allowed_transfers.TRANSFER_ONCE);
		addEEnumLiteral(allowed_transfersEEnum, Allowed_transfers.TRANSFER_TWICE);
		addEEnumLiteral(allowed_transfersEEnum, Allowed_transfers.UNLIMITED);

		initEEnum(transitTypeEEnum, TransitType.class, "TransitType");
		addEEnumLiteral(transitTypeEEnum, TransitType.LIGHT_RAIL);
		addEEnumLiteral(transitTypeEEnum, TransitType.SUBWAY);
		addEEnumLiteral(transitTypeEEnum, TransitType.RAIL);
		addEEnumLiteral(transitTypeEEnum, TransitType.BUS);
		addEEnumLiteral(transitTypeEEnum, TransitType.FERRY);
		addEEnumLiteral(transitTypeEEnum, TransitType.CABLE_CAR);
		addEEnumLiteral(transitTypeEEnum, TransitType.SUSPENDED_CABLE_CAR);
		addEEnumLiteral(transitTypeEEnum, TransitType.FUNICOLAR);

		// Create resource
		createResource(eNS_URI);
	}

} //MobilityResourcesPackageImpl
