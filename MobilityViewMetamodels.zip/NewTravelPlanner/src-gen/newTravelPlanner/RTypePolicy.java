/**
 */
package newTravelPlanner;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>RType Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.RTypePolicy#getIncludedRTypes <em>Included RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.RTypePolicy#getExcludedRTypes <em>Excluded RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.RTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getRTypePolicy()
 * @model
 * @generated
 */
public interface RTypePolicy extends PreCallPolicy {
	/**
	 * Returns the value of the '<em><b>Included RTypes</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.RouteType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Included RTypes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Included RTypes</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getRTypePolicy_IncludedRTypes()
	 * @model
	 * @generated
	 */
	EList<RouteType> getIncludedRTypes();

	/**
	 * Returns the value of the '<em><b>Excluded RTypes</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.RouteType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Excluded RTypes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Excluded RTypes</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getRTypePolicy_ExcludedRTypes()
	 * @model
	 * @generated
	 */
	EList<RouteType> getExcludedRTypes();

	/**
	 * Returns the value of the '<em><b>Smartplannerparameters</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Smartplannerparameters</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartplannerparameters</em>' reference.
	 * @see #setSmartplannerparameters(SmartPlannerParameters)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getRTypePolicy_Smartplannerparameters()
	 * @model
	 * @generated
	 */
	SmartPlannerParameters getSmartplannerparameters();

	/**
	 * Sets the value of the '{@link newTravelPlanner.RTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Smartplannerparameters</em>' reference.
	 * @see #getSmartplannerparameters()
	 * @generated
	 */
	void setSmartplannerparameters(SmartPlannerParameters value);

} // RTypePolicy
