/**
 */
package newTravelPlanner;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pre Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getPreCallPolicy()
 * @model
 * @generated
 */
public interface PreCallPolicy extends Policy {
} // PreCallPolicy
