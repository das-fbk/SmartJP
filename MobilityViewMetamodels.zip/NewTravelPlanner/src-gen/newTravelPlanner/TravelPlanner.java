/**
 */
package newTravelPlanner;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Travel Planner</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.TravelPlanner#getPlace <em>Place</em>}</li>
 *   <li>{@link newTravelPlanner.TravelPlanner#getPrecallpolicies <em>Precallpolicies</em>}</li>
 *   <li>{@link newTravelPlanner.TravelPlanner#getTTypes <em>TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.TravelPlanner#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 *   <li>{@link newTravelPlanner.TravelPlanner#getRTypes <em>RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.TravelPlanner#getPostcallpolicies <em>Postcallpolicies</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner()
 * @model
 * @generated
 */
public interface TravelPlanner extends EObject {
	/**
	 * Returns the value of the '<em><b>Place</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Place</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Place</em>' attribute.
	 * @see #setPlace(String)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_Place()
	 * @model required="true"
	 * @generated
	 */
	String getPlace();

	/**
	 * Sets the value of the '{@link newTravelPlanner.TravelPlanner#getPlace <em>Place</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Place</em>' attribute.
	 * @see #getPlace()
	 * @generated
	 */
	void setPlace(String value);

	/**
	 * Returns the value of the '<em><b>Precallpolicies</b></em>' containment reference list.
	 * The list contents are of type {@link newTravelPlanner.PreCallPolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Precallpolicies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Precallpolicies</em>' containment reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_Precallpolicies()
	 * @model containment="true"
	 * @generated
	 */
	EList<PreCallPolicy> getPrecallpolicies();

	/**
	 * Returns the value of the '<em><b>TTypes</b></em>' containment reference list.
	 * The list contents are of type {@link newTravelPlanner.TransportType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>TTypes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>TTypes</em>' containment reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_TTypes()
	 * @model containment="true"
	 * @generated
	 */
	EList<TransportType> getTTypes();

	/**
	 * Returns the value of the '<em><b>Smartplannerparameters</b></em>' containment reference list.
	 * The list contents are of type {@link newTravelPlanner.SmartPlannerParameters}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Smartplannerparameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartplannerparameters</em>' containment reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_Smartplannerparameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<SmartPlannerParameters> getSmartplannerparameters();

	/**
	 * Returns the value of the '<em><b>RTypes</b></em>' containment reference list.
	 * The list contents are of type {@link newTravelPlanner.RouteType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>RTypes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>RTypes</em>' containment reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_RTypes()
	 * @model containment="true"
	 * @generated
	 */
	EList<RouteType> getRTypes();

	/**
	 * Returns the value of the '<em><b>Postcallpolicies</b></em>' containment reference list.
	 * The list contents are of type {@link newTravelPlanner.PostCallPolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Postcallpolicies</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Postcallpolicies</em>' containment reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTravelPlanner_Postcallpolicies()
	 * @model containment="true"
	 * @generated
	 */
	EList<PostCallPolicy> getPostcallpolicies();

} // TravelPlanner
