/**
 */
package newTravelPlanner;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Route Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.RouteType#getTypeName <em>Type Name</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getRouteType()
 * @model
 * @generated
 */
public interface RouteType extends EObject {
	/**
	 * Returns the value of the '<em><b>Type Name</b></em>' attribute.
	 * The literals are from the enumeration {@link newTravelPlanner.RType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Name</em>' attribute.
	 * @see newTravelPlanner.RType
	 * @see #setTypeName(RType)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getRouteType_TypeName()
	 * @model
	 * @generated
	 */
	RType getTypeName();

	/**
	 * Sets the value of the '{@link newTravelPlanner.RouteType#getTypeName <em>Type Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Name</em>' attribute.
	 * @see newTravelPlanner.RType
	 * @see #getTypeName()
	 * @generated
	 */
	void setTypeName(RType value);

} // RouteType
