/**
 */
package newTravelPlanner;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Post Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getPostCallPolicy()
 * @model
 * @generated
 */
public interface PostCallPolicy extends Policy {
} // PostCallPolicy
