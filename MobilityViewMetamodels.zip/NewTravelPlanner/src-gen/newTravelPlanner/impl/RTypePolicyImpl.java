/**
 */
package newTravelPlanner.impl;

import java.util.Collection;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.RTypePolicy;
import newTravelPlanner.RouteType;
import newTravelPlanner.SmartPlannerParameters;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>RType Policy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.RTypePolicyImpl#getIncludedRTypes <em>Included RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.RTypePolicyImpl#getExcludedRTypes <em>Excluded RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.RTypePolicyImpl#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RTypePolicyImpl extends PreCallPolicyImpl implements RTypePolicy {
	/**
	 * The cached value of the '{@link #getIncludedRTypes() <em>Included RTypes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludedRTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<RouteType> includedRTypes;

	/**
	 * The cached value of the '{@link #getExcludedRTypes() <em>Excluded RTypes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExcludedRTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<RouteType> excludedRTypes;

	/**
	 * The cached value of the '{@link #getSmartplannerparameters() <em>Smartplannerparameters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartplannerparameters()
	 * @generated
	 * @ordered
	 */
	protected SmartPlannerParameters smartplannerparameters;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RTypePolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.RTYPE_POLICY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RouteType> getIncludedRTypes() {
		if (includedRTypes == null) {
			includedRTypes = new EObjectResolvingEList<RouteType>(RouteType.class, this,
					NewTravelPlannerPackage.RTYPE_POLICY__INCLUDED_RTYPES);
		}
		return includedRTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RouteType> getExcludedRTypes() {
		if (excludedRTypes == null) {
			excludedRTypes = new EObjectResolvingEList<RouteType>(RouteType.class, this,
					NewTravelPlannerPackage.RTYPE_POLICY__EXCLUDED_RTYPES);
		}
		return excludedRTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParameters getSmartplannerparameters() {
		if (smartplannerparameters != null && smartplannerparameters.eIsProxy()) {
			InternalEObject oldSmartplannerparameters = (InternalEObject) smartplannerparameters;
			smartplannerparameters = (SmartPlannerParameters) eResolveProxy(oldSmartplannerparameters);
			if (smartplannerparameters != oldSmartplannerparameters) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS, oldSmartplannerparameters,
							smartplannerparameters));
			}
		}
		return smartplannerparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParameters basicGetSmartplannerparameters() {
		return smartplannerparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSmartplannerparameters(SmartPlannerParameters newSmartplannerparameters) {
		SmartPlannerParameters oldSmartplannerparameters = smartplannerparameters;
		smartplannerparameters = newSmartplannerparameters;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS, oldSmartplannerparameters,
					smartplannerparameters));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.RTYPE_POLICY__INCLUDED_RTYPES:
			return getIncludedRTypes();
		case NewTravelPlannerPackage.RTYPE_POLICY__EXCLUDED_RTYPES:
			return getExcludedRTypes();
		case NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS:
			if (resolve)
				return getSmartplannerparameters();
			return basicGetSmartplannerparameters();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.RTYPE_POLICY__INCLUDED_RTYPES:
			getIncludedRTypes().clear();
			getIncludedRTypes().addAll((Collection<? extends RouteType>) newValue);
			return;
		case NewTravelPlannerPackage.RTYPE_POLICY__EXCLUDED_RTYPES:
			getExcludedRTypes().clear();
			getExcludedRTypes().addAll((Collection<? extends RouteType>) newValue);
			return;
		case NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS:
			setSmartplannerparameters((SmartPlannerParameters) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.RTYPE_POLICY__INCLUDED_RTYPES:
			getIncludedRTypes().clear();
			return;
		case NewTravelPlannerPackage.RTYPE_POLICY__EXCLUDED_RTYPES:
			getExcludedRTypes().clear();
			return;
		case NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS:
			setSmartplannerparameters((SmartPlannerParameters) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.RTYPE_POLICY__INCLUDED_RTYPES:
			return includedRTypes != null && !includedRTypes.isEmpty();
		case NewTravelPlannerPackage.RTYPE_POLICY__EXCLUDED_RTYPES:
			return excludedRTypes != null && !excludedRTypes.isEmpty();
		case NewTravelPlannerPackage.RTYPE_POLICY__SMARTPLANNERPARAMETERS:
			return smartplannerparameters != null;
		}
		return super.eIsSet(featureID);
	}

} //RTypePolicyImpl
