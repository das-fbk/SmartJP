/**
 */
package newTravelPlanner.impl;

import newTravelPlanner.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NewTravelPlannerFactoryImpl extends EFactoryImpl implements NewTravelPlannerFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static NewTravelPlannerFactory init() {
		try {
			NewTravelPlannerFactory theNewTravelPlannerFactory = (NewTravelPlannerFactory) EPackage.Registry.INSTANCE
					.getEFactory(NewTravelPlannerPackage.eNS_URI);
			if (theNewTravelPlannerFactory != null) {
				return theNewTravelPlannerFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new NewTravelPlannerFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewTravelPlannerFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER:
			return createTravelPlanner();
		case NewTravelPlannerPackage.PRE_CALL_POLICY:
			return createPreCallPolicy();
		case NewTravelPlannerPackage.TRANSPORT_TYPE:
			return createTransportType();
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS:
			return createSmartPlannerParameters();
		case NewTravelPlannerPackage.TTYPE_POLICY:
			return createTTypePolicy();
		case NewTravelPlannerPackage.RTYPE_POLICY:
			return createRTypePolicy();
		case NewTravelPlannerPackage.ROUTE_TYPE:
			return createRouteType();
		case NewTravelPlannerPackage.POST_CALL_POLICY:
			return createPostCallPolicy();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case NewTravelPlannerPackage.TTYPE:
			return createTTypeFromString(eDataType, initialValue);
		case NewTravelPlannerPackage.RTYPE:
			return createRTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case NewTravelPlannerPackage.TTYPE:
			return convertTTypeToString(eDataType, instanceValue);
		case NewTravelPlannerPackage.RTYPE:
			return convertRTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TravelPlanner createTravelPlanner() {
		TravelPlannerImpl travelPlanner = new TravelPlannerImpl();
		return travelPlanner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreCallPolicy createPreCallPolicy() {
		PreCallPolicyImpl preCallPolicy = new PreCallPolicyImpl();
		return preCallPolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransportType createTransportType() {
		TransportTypeImpl transportType = new TransportTypeImpl();
		return transportType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParameters createSmartPlannerParameters() {
		SmartPlannerParametersImpl smartPlannerParameters = new SmartPlannerParametersImpl();
		return smartPlannerParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TTypePolicy createTTypePolicy() {
		TTypePolicyImpl tTypePolicy = new TTypePolicyImpl();
		return tTypePolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RTypePolicy createRTypePolicy() {
		RTypePolicyImpl rTypePolicy = new RTypePolicyImpl();
		return rTypePolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RouteType createRouteType() {
		RouteTypeImpl routeType = new RouteTypeImpl();
		return routeType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PostCallPolicy createPostCallPolicy() {
		PostCallPolicyImpl postCallPolicy = new PostCallPolicyImpl();
		return postCallPolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TType createTTypeFromString(EDataType eDataType, String initialValue) {
		TType result = TType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RType createRTypeFromString(EDataType eDataType, String initialValue) {
		RType result = RType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewTravelPlannerPackage getNewTravelPlannerPackage() {
		return (NewTravelPlannerPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static NewTravelPlannerPackage getPackage() {
		return NewTravelPlannerPackage.eINSTANCE;
	}

} //NewTravelPlannerFactoryImpl
