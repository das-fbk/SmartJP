/**
 */
package newTravelPlanner.impl;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.PostCallPolicy;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Post Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PostCallPolicyImpl extends PolicyImpl implements PostCallPolicy {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PostCallPolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.POST_CALL_POLICY;
	}

} //PostCallPolicyImpl
