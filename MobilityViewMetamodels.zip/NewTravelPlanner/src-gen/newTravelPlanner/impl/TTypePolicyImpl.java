/**
 */
package newTravelPlanner.impl;

import java.util.Collection;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.RTypePolicy;
import newTravelPlanner.SmartPlannerParameters;
import newTravelPlanner.TTypePolicy;
import newTravelPlanner.TransportType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>TType Policy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.TTypePolicyImpl#getIncludedTTypes <em>Included TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TTypePolicyImpl#getExcludedTTypes <em>Excluded TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TTypePolicyImpl#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TTypePolicyImpl#getIncludedRTPolicies <em>Included RT Policies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TTypePolicyImpl extends PreCallPolicyImpl implements TTypePolicy {
	/**
	 * The cached value of the '{@link #getIncludedTTypes() <em>Included TTypes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludedTTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<TransportType> includedTTypes;

	/**
	 * The cached value of the '{@link #getExcludedTTypes() <em>Excluded TTypes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExcludedTTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<TransportType> excludedTTypes;

	/**
	 * The cached value of the '{@link #getSmartplannerparameters() <em>Smartplannerparameters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartplannerparameters()
	 * @generated
	 * @ordered
	 */
	protected SmartPlannerParameters smartplannerparameters;

	/**
	 * The cached value of the '{@link #getIncludedRTPolicies() <em>Included RT Policies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludedRTPolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<RTypePolicy> includedRTPolicies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TTypePolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.TTYPE_POLICY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TransportType> getIncludedTTypes() {
		if (includedTTypes == null) {
			includedTTypes = new EObjectResolvingEList<TransportType>(TransportType.class, this,
					NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_TTYPES);
		}
		return includedTTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TransportType> getExcludedTTypes() {
		if (excludedTTypes == null) {
			excludedTTypes = new EObjectResolvingEList<TransportType>(TransportType.class, this,
					NewTravelPlannerPackage.TTYPE_POLICY__EXCLUDED_TTYPES);
		}
		return excludedTTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParameters getSmartplannerparameters() {
		if (smartplannerparameters != null && smartplannerparameters.eIsProxy()) {
			InternalEObject oldSmartplannerparameters = (InternalEObject) smartplannerparameters;
			smartplannerparameters = (SmartPlannerParameters) eResolveProxy(oldSmartplannerparameters);
			if (smartplannerparameters != oldSmartplannerparameters) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS, oldSmartplannerparameters,
							smartplannerparameters));
			}
		}
		return smartplannerparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPlannerParameters basicGetSmartplannerparameters() {
		return smartplannerparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSmartplannerparameters(SmartPlannerParameters newSmartplannerparameters) {
		SmartPlannerParameters oldSmartplannerparameters = smartplannerparameters;
		smartplannerparameters = newSmartplannerparameters;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS, oldSmartplannerparameters,
					smartplannerparameters));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RTypePolicy> getIncludedRTPolicies() {
		if (includedRTPolicies == null) {
			includedRTPolicies = new EObjectResolvingEList<RTypePolicy>(RTypePolicy.class, this,
					NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_RT_POLICIES);
		}
		return includedRTPolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_TTYPES:
			return getIncludedTTypes();
		case NewTravelPlannerPackage.TTYPE_POLICY__EXCLUDED_TTYPES:
			return getExcludedTTypes();
		case NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS:
			if (resolve)
				return getSmartplannerparameters();
			return basicGetSmartplannerparameters();
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_RT_POLICIES:
			return getIncludedRTPolicies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_TTYPES:
			getIncludedTTypes().clear();
			getIncludedTTypes().addAll((Collection<? extends TransportType>) newValue);
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__EXCLUDED_TTYPES:
			getExcludedTTypes().clear();
			getExcludedTTypes().addAll((Collection<? extends TransportType>) newValue);
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS:
			setSmartplannerparameters((SmartPlannerParameters) newValue);
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_RT_POLICIES:
			getIncludedRTPolicies().clear();
			getIncludedRTPolicies().addAll((Collection<? extends RTypePolicy>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_TTYPES:
			getIncludedTTypes().clear();
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__EXCLUDED_TTYPES:
			getExcludedTTypes().clear();
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS:
			setSmartplannerparameters((SmartPlannerParameters) null);
			return;
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_RT_POLICIES:
			getIncludedRTPolicies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_TTYPES:
			return includedTTypes != null && !includedTTypes.isEmpty();
		case NewTravelPlannerPackage.TTYPE_POLICY__EXCLUDED_TTYPES:
			return excludedTTypes != null && !excludedTTypes.isEmpty();
		case NewTravelPlannerPackage.TTYPE_POLICY__SMARTPLANNERPARAMETERS:
			return smartplannerparameters != null;
		case NewTravelPlannerPackage.TTYPE_POLICY__INCLUDED_RT_POLICIES:
			return includedRTPolicies != null && !includedRTPolicies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //TTypePolicyImpl
