/**
 */
package newTravelPlanner.impl;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.PreCallPolicy;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pre Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PreCallPolicyImpl extends PolicyImpl implements PreCallPolicy {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreCallPolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.PRE_CALL_POLICY;
	}

} //PreCallPolicyImpl
